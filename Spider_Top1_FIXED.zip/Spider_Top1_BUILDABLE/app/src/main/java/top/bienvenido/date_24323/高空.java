/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.ProxyInfo
 *  android.os.Parcelable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.URI
 *  java.util.Collections
 *  java.util.List
 *  kotlin.Result
 *  kotlin.ResultKt
 *  kotlin.collections.CollectionsKt
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.net.ProxyInfo;
import android.os.Parcelable;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.CollectionsKt;
import top.bienvenido.date_24323.\u5408\u529b;

public abstract class \u9ad8\u7a7a {
    public static void \u8d4b\u80fd(String string2, String string3, String string4) {
        Object object;
        try {
            ProxyInfo proxyInfo;
            if (string2.length() == 0) {
                proxyInfo = ProxyInfo.buildDirectProxy((String)"", (int)0, (List)Collections.EMPTY_LIST);
            } else {
                URI uRI = URI.create((String)string2);
                proxyInfo = ProxyInfo.buildDirectProxy((String)uRI.getHost(), (int)uRI.getPort(), (List)CollectionsKt.listOf((Object[])new String[]{"*.cn", "localhost", "127.*", "[::1]", "0.0.0.0", "[::0]"}));
            }
            Intent intent = new Intent("android.intent.action.PROXY_CHANGE").addFlags(603979776).putExtra("android.intent.extra.PROXY_INFO", (Parcelable)proxyInfo).setPackage(string3);
            object = Result.constructor-impl((Object)\u5408\u529b.\u6293\u624b.\u6293\u624b(intent, string4));
        }
        catch (Throwable throwable) {
            object = Result.constructor-impl((Object)ResultKt.createFailure((Throwable)throwable));
        }
        Result.exceptionOrNull-impl((Object)object);
    }
}

