/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u57fa\u56e0;
import top.bienvenido.date_24323.\u5e03\u5c40;

public final class \u57fa\u56e0$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;

    public /* synthetic */ \u57fa\u56e0$$ExternalSyntheticLambda0(Object[] arrobject) {
        this.f$0 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u57fa\u56e0.\u8d4b\u80fd(this.f$0, (\u5e03\u5c40)object);
    }
}

