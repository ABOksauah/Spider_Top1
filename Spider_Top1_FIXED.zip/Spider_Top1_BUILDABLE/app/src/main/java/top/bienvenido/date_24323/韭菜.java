/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u97ed\u83dc
extends MutablePropertyReference1Impl {
    public static final \u97ed\u83dc \u8d4b\u80fd = new \u97ed\u83dc();

    public \u97ed\u83dc() {
        super(ResolveInfo.class, "providerInfo", "getProviderInfo()Landroid/content/pm/ProviderInfo;", 0);
    }

    public final Object get(Object object) {
        return ((ResolveInfo)object).providerInfo;
    }

    public final void set(Object object, Object object2) {
        ((ResolveInfo)object).providerInfo = (ProviderInfo)object2;
    }
}

