/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.collections.ArraysKt
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.collections.ArraysKt;
import top.bienvenido.date_24323.\u6536\u53e3;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u8d5b\u9053
extends \u89e6\u53d1 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object[] arrobject2 = method.getParameterTypes();
        int n = ArraysKt.lastIndexOf((Object[])arrobject2, IBinder.class);
        if (n < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        int n2 = ArraysKt.indexOf((Object[])arrobject2, Intent.class);
        if (n2 < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            Intent intent = (Intent)arrobject[n2];
            arrobject[n2] = \u6536\u53e3.\u8d4b\u80fd((IBinder)arrobject[n], intent);
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

