/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  kotlin.Pair
 *  kotlin.jvm.functions.Function1
 *  sun.misc.Unsafe
 *  top.bienvenido.date_24323.\u5782\u76f4
 *  top.bienvenido.date_24323.\u672c\u5206
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 *  top.bienvenido.date_24323.\u91cd\u78c5
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u5782\u76f4;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u672c\u5206;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u91cd\u78c5;

public final class \u771f\u9999 {
    public static Object \u4e2d\u53f0(Class class_, String string2) {
        try {
            Object object = \u771f\u9999.\u8d4b\u80fd(class_, string2).\u8d4b\u80fd(null);
            return object;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static /* synthetic */ \u81ea\u6d3d \u6293\u624b(Class class_, String string2) {
        return \u771f\u9999.\u8d4b\u80fd(class_, string2, \u4e0b\u6c89.\u6293\u624b);
    }

    public static \u81ea\u6d3d \u8d4b\u80fd(Class class_, String string2) {
        try {
            Field field = class_.getDeclaredField(string2);
            field.setAccessible(true);
            \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(field);
            return \u81ea\u6d3d2;
        }
        catch (Exception exception) {
            return \u81ea\u6d3d.\u8d4b\u80fd;
        }
    }

    public static \u81ea\u6d3d \u8d4b\u80fd(Class class_, String string2, Class[] arrclass) {
        try {
            Method method = class_.getDeclaredMethod(string2, arrclass);
            method.setAccessible(true);
            \u76ae\u5b9e \u76ae\u5b9e2 = new \u76ae\u5b9e(method);
            return \u76ae\u5b9e2;
        }
        catch (Exception exception) {
            return \u81ea\u6d3d.\u8d4b\u80fd;
        }
    }

    public static \u81ea\u6d3d \u8d4b\u80fd(String string2, String string3) {
        try {
            \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(Class.forName((String)string2), string3);
            return \u81ea\u6d3d2;
        }
        catch (Exception exception) {
            return \u81ea\u6d3d.\u8d4b\u80fd;
        }
    }

    public static \u81ea\u6d3d \u8d4b\u80fd(Field field) {
        if ((8 & field.getModifiers()) != 0 || field.getType().isPrimitive()) {
            Function1 function1 = \u62a4\u57ce\u6cb3.\u4e2d\u53f0;
            if (function1 != null && (24 & field.getModifiers()) == 24) {
                if (field.getType().isPrimitive()) {
                    return \u81ea\u6d3d.\u8d4b\u80fd;
                }
                return new \u672c\u5206((Pair)function1.invoke((Object)field));
            }
            return new \u91cd\u78c5(field);
        }
        return new \u5782\u76f4(\u62a4\u57ce\u6cb3.\u6293\u624b.objectFieldOffset(field));
    }

    public static void \u8d4b\u80fd(Class class_, String string2, Object object) {
        try {
            \u771f\u9999.\u8d4b\u80fd(class_, string2).\u8d4b\u80fd((Object)null, object);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

