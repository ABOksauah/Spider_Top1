/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u592f\u5b9e;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda18
implements Runnable {
    public final /* synthetic */ \u592f\u5b9e f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda18(\u592f\u5b9e \u592f\u5b9e2) {
        this.f$0 = \u592f\u5b9e2;
    }

    public final void run() {
        this.f$0.\u8d4b\u80fd();
    }
}

