/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$ComponentEnabledSetting
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Binder
 *  android.os.ConditionVariable
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.ConditionVariable;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import kotlin.collections.CollectionsKt;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u63a5\u5165;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u94f8\u9020;

public abstract class \u6388\u6743
extends Binder
implements \u94f8\u9020 {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u6388\u6743() {
        this.attachInterface((IInterface)this, "MundoPackageManagerService");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        if (n >= 1 && n <= 16777215) {
            parcel.enforceInterface("MundoPackageManagerService");
        }
        if (n == 1598968902) {
            parcel2.writeString("MundoPackageManagerService");
            return true;
        }
        switch (n) {
            default: {
                return super.onTransact(n, parcel, parcel2, n2);
            }
            case 37: {
                ComponentName componentName = (ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR);
                int n3 = ((\u8fb9\u754c)this).\u8d4b\u80fd(componentName);
                parcel2.writeNoException();
                parcel2.writeInt(n3);
                return true;
            }
            case 36: {
                ComponentName componentName = (ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR);
                int n4 = parcel.readInt();
                ((\u8fb9\u754c)this).\u8d4b\u80fd(componentName, n4);
                parcel2.writeNoException();
                return true;
            }
            case 35: {
                ArrayList arrayList = parcel.createTypedArrayList(PackageManager.ComponentEnabledSetting.CREATOR);
                ((\u8fb9\u754c)this).\u8d4b\u80fd((List)arrayList);
                parcel2.writeNoException();
                return true;
            }
            case 34: {
                String string = parcel.readString();
                int n5 = ((\u8fb9\u754c)this).\u843d\u5730(string);
                parcel2.writeNoException();
                parcel2.writeInt(n5);
                return true;
            }
            case 33: {
                int n6 = parcel.readInt();
                ((\u8fb9\u754c)this).\u6293\u624b(n6);
                return true;
            }
            case 32: {
                ArrayList arrayList = ((\u8fb9\u754c)this).\u6293\u624b();
                parcel2.writeNoException();
                parcel2.writeStringList((List)arrayList);
                return true;
            }
            case 31: {
                String string = parcel.readString();
                int n7 = ((\u8fb9\u754c)this).\u6293\u624b(string);
                parcel2.writeNoException();
                parcel2.writeInt(n7);
                return true;
            }
            case 30: {
                \u8fb9\u754c.\u843d\u5730.block(10000L);
                parcel2.writeNoException();
                return true;
            }
            case 29: {
                String string = parcel.readString();
                String[] arrstring = ((\u8fb9\u754c)this).\u6c89\u6dc0(string);
                parcel2.writeNoException();
                parcel2.writeStringArray(arrstring);
                return true;
            }
            case 28: {
                String string = parcel.readString();
                String string2 = parcel.readString();
                ((\u8fb9\u754c)this).\u4e2d\u53f0(string, string2);
                return true;
            }
            case 27: {
                String string = parcel.readString();
                String string3 = parcel.readString();
                ((\u8fb9\u754c)this).\u7ed9\u5230(string, string3);
                return true;
            }
            case 26: {
                String string = parcel.readString();
                int n8 = parcel.readInt();
                int n9 = ((\u8fb9\u754c)this).\u8d4b\u80fd(string, n8);
                parcel2.writeNoException();
                parcel2.writeInt(n9);
                return true;
            }
            case 25: {
                String string = parcel.readString();
                int n10 = ((\u8fb9\u754c)this).\u6f0f\u6597(string);
                parcel2.writeNoException();
                parcel2.writeInt(n10);
                return true;
            }
            case 24: {
                int[] arrn = parcel.createIntArray();
                String[] arrstring = ((\u8fb9\u754c)this).\u8d4b\u80fd(arrn);
                parcel2.writeNoException();
                parcel2.writeStringArray(arrstring);
                return true;
            }
            case 23: {
                int n11 = parcel.readInt();
                String string = ((\u8fb9\u754c)this).\u8d4b\u80fd(n11);
                parcel2.writeNoException();
                parcel2.writeString(string);
                return true;
            }
            case 22: {
                int n12 = parcel.readInt();
                String[] arrstring = ((\u8fb9\u754c)this).\u6c89\u6dc0(n12);
                parcel2.writeNoException();
                parcel2.writeStringArray(arrstring);
                return true;
            }
            case 21: {
                String string = parcel.readString();
                int n13 = ((\u8fb9\u754c)this).\u4f18\u5316(string);
                parcel2.writeNoException();
                parcel2.writeInt(n13);
                return true;
            }
            case 20: {
                String string = parcel.readString();
                ((\u8fb9\u754c)this).\u540c\u6b65(string);
                return true;
            }
            case 19: {
                String string = parcel.readString();
                String string4 = ((\u8fb9\u754c)this).\u8fed\u4ee3(string);
                parcel2.writeNoException();
                parcel2.writeString(string4);
                return true;
            }
            case 18: {
                String string = parcel.readString();
                String string5 = parcel.readString();
                ArrayList arrayList = ((\u8fb9\u754c)this).\u5e73\u53f0(string, string5);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (List)arrayList, 1);
                return true;
            }
            case 17: {
                String string = parcel.readString();
                ProviderInfo providerInfo = ((\u8fb9\u754c)this).\u7ed9\u5230(string);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)providerInfo, 1);
                return true;
            }
            case 16: {
                int n14 = parcel.readInt();
                ArrayList arrayList = ((\u8fb9\u754c)this).\u843d\u5730(n14);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (List)arrayList, 1);
                return true;
            }
            case 15: {
                int n15 = parcel.readInt();
                ArrayList arrayList = ((\u8fb9\u754c)this).\u4e2d\u53f0(n15);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (List)arrayList, 1);
                return true;
            }
            case 14: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n16 = parcel.readInt();
                List list = ((\u8fb9\u754c)this).\u6f0f\u6597(intent, string, n16);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, list, 1);
                return true;
            }
            case 13: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n17 = parcel.readInt();
                List list = ((\u8fb9\u754c)this).\u6293\u624b(intent, string, n17);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, list, 1);
                return true;
            }
            case 12: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n18 = parcel.readInt();
                ResolveInfo resolveInfo = (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(((\u8fb9\u754c)this).\u4e2d\u53f0(intent, string, n18)));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)resolveInfo, 1);
                return true;
            }
            case 11: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n19 = parcel.readInt();
                ResolveInfo resolveInfo = (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(((\u8fb9\u754c)this).\u6293\u624b(intent, string, n19)));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)resolveInfo, 1);
                return true;
            }
            case 10: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n20 = parcel.readInt();
                List list = ((\u8fb9\u754c)this).\u8d4b\u80fd(intent, string, n20);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, list, 1);
                return true;
            }
            case 9: {
                Intent intent = (Intent)\u63a5\u5165.\u8d4b\u80fd(parcel, Intent.CREATOR);
                String string = parcel.readString();
                int n21 = parcel.readInt();
                List list = ((\u8fb9\u754c)this).\u4e2d\u53f0(intent, string, n21);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, list, 1);
                return true;
            }
            case 8: {
                ProviderInfo providerInfo = (ProviderInfo)\u8fb9\u754c.\u6f0f\u6597((ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)providerInfo, 1);
                return true;
            }
            case 7: {
                ServiceInfo serviceInfo = (ServiceInfo)\u8fb9\u754c.\u6f0f\u6597((ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)serviceInfo, 1);
                return true;
            }
            case 6: {
                ActivityInfo activityInfo = (ActivityInfo)\u8fb9\u754c.\u6f0f\u6597((ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)activityInfo, 1);
                return true;
            }
            case 5: {
                ActivityInfo activityInfo = (ActivityInfo)\u8fb9\u754c.\u6f0f\u6597((ComponentName)\u63a5\u5165.\u8d4b\u80fd(parcel, ComponentName.CREATOR));
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)activityInfo, 1);
                return true;
            }
            case 4: {
                String string = parcel.readString();
                int n22 = parcel.readInt();
                ApplicationInfo applicationInfo = ((\u8fb9\u754c)this).\u6293\u624b(string, n22);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)applicationInfo, 1);
                return true;
            }
            case 3: {
                String string = parcel.readString();
                int n23 = parcel.readInt();
                PackageInfo packageInfo = ((\u8fb9\u754c)this).\u4e2d\u53f0(string, n23);
                parcel2.writeNoException();
                \u63a5\u5165.\u8d4b\u80fd(parcel2, (Parcelable)packageInfo, 1);
                return true;
            }
            case 2: {
                String string = parcel.readString();
                int n24 = \u8fb9\u754c.\u4e2d\u53f0.containsKey(string);
                parcel2.writeNoException();
                parcel2.writeInt(n24);
                return true;
            }
            case 1: 
        }
        String string = parcel.readString();
        int n25 = ((\u8fb9\u754c)this).\u5bf9\u6807(string);
        parcel2.writeNoException();
        parcel2.writeInt(n25);
        return true;
    }
}

