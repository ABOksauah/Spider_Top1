/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ServiceInfo
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.content.pm.ServiceInfo;
import top.bienvenido.date_24323.\u53d8\u9769;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u54c1\u724c;

public final class \u5408\u529b$$ExternalSyntheticLambda17
implements Runnable {
    public final /* synthetic */ \u54c1\u724c f$0;
    public final /* synthetic */ \u53d8\u9769 f$1;
    public final /* synthetic */ ServiceInfo f$2;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda17(\u54c1\u724c \u54c1\u724c2, \u53d8\u9769 \u53d8\u97692, ServiceInfo serviceInfo) {
        this.f$0 = \u54c1\u724c2;
        this.f$1 = \u53d8\u97692;
        this.f$2 = serviceInfo;
    }

    public final void run() {
        \u5408\u529b.\u8d4b\u80fd((\u54c1\u724c)this.f$0, (\u53d8\u9769)this.f$1, (ServiceInfo)this.f$2);
    }
}

