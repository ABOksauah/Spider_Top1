/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u62a2\u54c1\u7c7b$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u62a2\u54c1\u7c7b f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object[] f$2;

    public /* synthetic */ \u62a2\u54c1\u7c7b$$ExternalSyntheticLambda0(\u62a2\u54c1\u7c7b \u62a2\u54c1\u7c7b2, Object object, Object[] arrobject) {
        this.f$0 = \u62a2\u54c1\u7c7b2;
        this.f$1 = object;
        this.f$2 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u62a2\u54c1\u7c7b.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (\u94f8\u9020)object);
    }
}

