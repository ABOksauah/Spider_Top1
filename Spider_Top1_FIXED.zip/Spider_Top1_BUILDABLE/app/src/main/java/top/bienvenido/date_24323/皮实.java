/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u76ae\u5b9e
extends \u81ea\u6d3d {
    public final /* synthetic */ Method \u6293\u624b;

    public \u76ae\u5b9e(Method method) {
        this.\u6293\u624b = method;
    }

    @Override
    public final /* varargs */ Object \u8d4b\u80fd(Object object, Object ... arrobject) {
        return this.\u6293\u624b.invoke(object, arrobject);
    }
}

