/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.net.InetSocketAddress
 *  java.net.Proxy
 *  java.net.Proxy$Type
 *  java.net.ProxySelector
 *  java.net.SocketAddress
 *  java.net.URI
 *  java.util.Collections
 *  java.util.List
 */
package top.bienvenido.date_24323;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.Collections;
import java.util.List;

public final class \u94f6\u5f39
extends ProxySelector {
    public final List \u6293\u624b;
    public final List \u8d4b\u80fd = Collections.singletonList((Object)Proxy.NO_PROXY);

    public \u94f6\u5f39(Proxy proxy) {
        this.\u6293\u624b = Collections.singletonList((Object)proxy);
    }

    public static void \u8d4b\u80fd(String string2, String string3) {
        if (string2 != null) {
            System.setProperty((String)"http.proxyHost", (String)string2);
            System.setProperty((String)"https.proxyHost", (String)string2);
            System.setProperty((String)"http.nonProxyHosts", (String)"localhost|127.*|[::1]|0.0.0.0|[::0]");
            System.setProperty((String)"https.nonProxyHosts", (String)"localhost|127.*|[::1]|0.0.0.0|[::0]");
            System.setProperty((String)"http.proxyPort", (String)string3);
            System.setProperty((String)"https.proxyPort", (String)string3);
            return;
        }
        System.clearProperty((String)"http.proxyHost");
        System.clearProperty((String)"https.proxyHost");
        System.clearProperty((String)"http.nonProxyHosts");
        System.clearProperty((String)"https.nonProxyHosts");
        System.clearProperty((String)"http.proxyPort");
        System.clearProperty((String)"https.proxyPort");
    }

    public final void connectFailed(URI uRI, SocketAddress socketAddress, IOException iOException) {
    }

    public final List select(URI uRI) {
        block22 : {
            String string2;
            int n;
            String string3;
            block27 : {
                block26 : {
                    block23 : {
                        block24 : {
                            block25 : {
                                if (uRI == null) {
                                    return this.\u8d4b\u80fd;
                                }
                                string2 = uRI.getHost();
                                if (string2 == null) {
                                    return this.\u8d4b\u80fd;
                                }
                                if (string2.equalsIgnoreCase("localhost")) break block22;
                                n = 0;
                                char c = string2.charAt(0);
                                if (c == '0') break block23;
                                if (c == '1') break block24;
                                if (c == ':') break block25;
                                if (c != '[') break block26;
                                if (!string2.equals((Object)"[::1]") && !string2.equals((Object)"[::0]")) break block27;
                                break block22;
                            }
                            if (!string2.equals((Object)"::1") && !string2.equals((Object)"::0")) break block27;
                            break block22;
                        }
                        if (!string2.startsWith("27.", 1) && !string2.startsWith("0.", 1) && !string2.startsWith("92.168.", 1) && !string2.startsWith("69.254.", 1)) break block26;
                        char c = string2.charAt(string2.length() - 1);
                        if (c < '0' || c > '9') break block27;
                        break block22;
                    }
                    if (string2.equals((Object)"0.0.0.0")) break block22;
                }
                if (string2.endsWith(".local") || string2.endsWith(".internal") || string2.endsWith(".lan") || string2.indexOf(46) == -1 && string2.indexOf(58) == -1) break block22;
            }
            if ((string3 = uRI.getScheme()) == null) {
                return this.\u8d4b\u80fd;
            }
            if (!"https".equalsIgnoreCase(string3) && !"http".equalsIgnoreCase(string3)) {
                if ("ftp".equalsIgnoreCase(string3)) {
                    Proxy proxy;
                    boolean bl;
                    String string4 = System.getProperty((String)"ftp.nonProxyHosts");
                    if (string4 == null) {
                        bl = false;
                    } else {
                        StringBuilder stringBuilder = new StringBuilder();
                        while (n < string4.length()) {
                            char c = string4.charAt(n);
                            if (c != '*') {
                                if (c != '.') {
                                    stringBuilder.append(c);
                                } else {
                                    stringBuilder.append("\\.");
                                }
                            } else {
                                stringBuilder.append(".*");
                            }
                            ++n;
                        }
                        bl = string2.matches(stringBuilder.toString());
                    }
                    if (bl) {
                        return this.\u8d4b\u80fd;
                    }
                    int n2 = 80;
                    String string5 = System.getProperty((String)"ftp.proxyHost");
                    if (string5 != null && !string5.isEmpty()) {
                        String string6 = System.getProperty((String)"ftp.proxyPort");
                        if (string6 != null) {
                            try {
                                n2 = Integer.parseInt((String)string6);
                            }
                            catch (NumberFormatException numberFormatException) {
                                // empty catch block
                            }
                        }
                        proxy = new Proxy(Proxy.Type.HTTP, (SocketAddress)InetSocketAddress.createUnresolved((String)string5, (int)n2));
                    } else {
                        proxy = null;
                    }
                    return Collections.singletonList(proxy);
                }
                if ("socket".equalsIgnoreCase(string3)) {
                    if (!((Proxy)this.\u6293\u624b.get(0)).type().equals((Object)Proxy.Type.SOCKS)) {
                        return this.\u8d4b\u80fd;
                    }
                    return this.\u6293\u624b;
                }
                return this.\u8d4b\u80fd;
            }
            return this.\u6293\u624b;
        }
        return this.\u8d4b\u80fd;
    }
}

