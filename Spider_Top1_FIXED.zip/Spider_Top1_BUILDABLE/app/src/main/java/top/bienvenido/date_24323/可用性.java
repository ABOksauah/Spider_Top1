/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.android.internal.net.VpnConfig
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import com.android.internal.net.VpnConfig;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u53ef\u7528\u6027
extends MutablePropertyReference1Impl {
    public static final \u53ef\u7528\u6027 \u8d4b\u80fd = new \u53ef\u7528\u6027();

    public \u53ef\u7528\u6027() {
        super(VpnConfig.class, "user", "getUser()Ljava/lang/String;", 0);
    }

    public final Object get(Object object) {
        return ((VpnConfig)object).user;
    }

    public final void set(Object object, Object object2) {
        ((VpnConfig)object).user = (String)object2;
    }
}

