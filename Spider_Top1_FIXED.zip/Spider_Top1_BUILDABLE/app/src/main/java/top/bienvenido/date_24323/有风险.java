/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.Exception
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u6709\u98ce\u9669
extends \u5f00\u573a\u5b50 {
    public final Account \u540c\u6b65;
    public final String[] \u5bf9\u9f50;

    public \u6709\u98ce\u9669(IAccountManagerResponse iAccountManagerResponse, Account account, String[] arrstring) {
        super(iAccountManagerResponse, account.type, false, true, account.name, false, false);
        this.\u540c\u6b65 = account;
        this.\u5bf9\u9f50 = arrstring;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void onResult(Bundle var1_1) {
        var2_2 = this.\u540c\u6b65();
        if (var2_2 == null) return;
        if (var1_1 != null) ** GOTO lbl7
        try {
            var2_2.onError(5, "null bundle");
            return;
lbl7: // 1 sources:
            var3_3 = new Bundle();
            var3_3.putBoolean("booleanResult", var1_1.getBoolean("booleanResult", false));
            var2_2.onResult(var3_3);
            return;
        }
        catch (Exception var4_4) {
            // empty catch block
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator;
        try {
            iAccountAuthenticator = this.\u7ed9\u5230;
            if (iAccountAuthenticator == null) return;
        }
        catch (Exception exception) {
            this.onError(1, "remote exception");
            return;
        }
        iAccountAuthenticator.hasFeatures((IAccountAuthenticatorResponse)this, this.\u540c\u6b65, this.\u5bf9\u9f50);
    }
}

