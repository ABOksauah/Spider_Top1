/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.ConnectivityManager
 *  android.net.Network
 *  android.net.ProxyInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.net.URI
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.ProxyInfo;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u6811\u7acb
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Network network;
            String string = \u6c34\u4f4d.\u7ed9\u5230;
            if (string.length() > 0 && Intrinsics.areEqual((Object)arrobject[0], (Object)(network = ConnectivityManager.getProcessDefaultNetwork()))) {
                URI uRI = URI.create((String)string);
                ProxyInfo proxyInfo = ProxyInfo.buildDirectProxy((String)uRI.getHost(), (int)uRI.getPort(), (List)CollectionsKt.listOf((Object[])new String[]{"*.cn", "localhost", "127.*", "[::1]", "0.0.0.0", "[::0]"}));
                return proxyInfo;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

