/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u6253\u78e8;

public final class \u6293\u624b
extends FunctionReferenceImpl
implements Function1 {
    public \u6293\u624b() {
        super(1, (Object)Boolean.FALSE, \u6253\u78e8.class, "returnThisFunction", "returnThisFunction(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;", 1);
    }

    public final Object invoke(Object object) {
        (Object[])object;
        return (Boolean)this.receiver;
    }
}

