/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Process
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.text.StringsKt
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.os.Process;
import java.io.File;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d44\u6e90\u4f4d;
import top.bienvenido.date_24323.\u8f6c\u5316;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u89e6\u53ca {
    public static final File \u6293\u624b;
    public static final boolean \u8d4b\u80fd;

    static {
        boolean bl;
        try {
            bl = \u62bd\u8c61.\u6293\u624b ? Process.is64Bit() : (Boolean)\u8d44\u6e90\u4f4d.\u843d\u5730.\u8d4b\u80fd(\u8d44\u6e90\u4f4d.\u8d4b\u80fd, new Object[0]);
        }
        catch (Throwable throwable) {
            bl = true;
        }
        \u8d4b\u80fd = bl;
        \u6293\u624b = \u98ce\u53e3.\u8d4b\u80fd.getDir("interior", 0);
    }

    public static File \u6293\u624b(String string2) {
        File file = \u6253\u78e8.\u8d4b\u80fd(\u6293\u624b, string2, "lib");
        file.mkdirs();
        String string3 = \u8d4b\u80fd ? "arm64" : "arm";
        File file2 = new File(file, string3);
        if (!file2.exists()) {
            if (\u8f6c\u5316.\u8d4b\u80fd(file.getAbsolutePath(), file2.getAbsolutePath())) {
                return file2;
            }
            return file;
        }
        return file2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static File \u8d4b\u80fd(String string2) {
        File[] arrfile;
        File file = new File(\u98ce\u53e3.\u8d4b\u80fd.getCodeCacheDir(), string2);
        if (!file.exists()) {
            file.mkdir();
        }
        if ((arrfile = new File(\u6293\u624b, string2).listFiles()) == null) return file;
        int n = arrfile.length;
        for (int i = 0; i < n; ++i) {
            try {
                File file2 = arrfile[i];
                if (!file2.isFile() || !StringsKt.endsWith$default((String)file2.getName(), (String)".apk", (boolean)false, (int)2, null)) continue;
                file2.renameTo(new File(file, file2.getName()));
            }
            catch (Exception exception) {
                // empty catch block
                return file;
            }
        }
        return file;
    }

    public static File \u8d4b\u80fd(boolean bl) {
        File file = new File(\u98ce\u53e3.\u8d4b\u80fd.getCodeCacheDir(), "apks");
        if (bl) {
            file.mkdirs();
        }
        return file;
    }
}

