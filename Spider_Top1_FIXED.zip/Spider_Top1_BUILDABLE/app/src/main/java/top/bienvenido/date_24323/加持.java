/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.servertransaction.ClientTransaction
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.app.servertransaction.ClientTransaction;
import java.util.List;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

public final class \u52a0\u6301
extends FunctionReferenceImpl
implements Function1 {
    public static final \u52a0\u6301 \u8d4b\u80fd = new \u52a0\u6301();

    public \u52a0\u6301() {
        super(1, ClientTransaction.class, "getCallbacks", "getCallbacks()Ljava/util/List;", 0);
    }

    public final Object invoke(Object object) {
        return ((ClientTransaction)object).getCallbacks();
    }
}

