/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityThread
 *  android.app.ActivityThread$ApplicationThread
 *  android.app.AppComponentFactory
 *  android.app.Application
 *  android.app.Instrumentation
 *  android.app.LoadedApk
 *  android.content.BroadcastReceiver
 *  android.content.BroadcastReceiver$PendingResult
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.IIntentReceiver
 *  android.content.IIntentReceiver$Stub
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.util.concurrent.ExecutorService
 *  kotlin.jvm.functions.Function0
 *  sun.misc.Unsafe
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.app.ActivityThread;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Instrumentation;
import android.app.LoadedApk;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.IIntentReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import java.lang.reflect.Constructor;
import java.util.concurrent.ExecutorService;
import kotlin.jvm.functions.Function0;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6a2a\u5411$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6a2a\u5411$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u6a2a\u5411$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u6a2a\u5411 {
    public static final Object \u6293\u624b;
    public static final \u81ea\u6d3d \u8d4b\u80fd;

    static {
        Object object;
        \u8d4b\u80fd = \u771f\u9999.\u8d4b\u80fd(BroadcastReceiver.class, "mPendingResult");
        try {
            object = \u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(BroadcastReceiver.PendingResult.class);
            Boolean bl = Boolean.TRUE;
            new \u8d77\u98de((String)"mInitialStickyHint").\u6293\u624b.\u8d4b\u80fd(object, (Object)bl);
        }
        catch (Exception exception) {
            object = null;
        }
        \u6293\u624b = object;
    }

    public static final void \u6293\u624b(Intent intent, String string2) {
        try {
            if (!\u6c34\u4f4d.\u8d4b\u80fd) {
                return;
            }
            if (intent.getComponent() == null) {
                intent.setComponent(new ComponentName(\u6c34\u4f4d.\u6293\u624b, string2));
            }
            \u6bb5\u4f4d.\u6293\u624b.getClass();
            LoadedApk loadedApk = (LoadedApk)\u6bb5\u4f4d.\u5347\u7ea7.invoke();
            \u6bb5\u4f4d.\u95ed\u73af.post((Runnable)new \u6a2a\u5411$$ExternalSyntheticLambda2(loadedApk, intent, string2));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final void \u6293\u624b(IBinder iBinder, Intent intent) {
        try {
            if (\u62bd\u8c61.\u540c\u6b65) {
                \u6bb5\u4f4d.\u6293\u624b.getClass();
                ActivityThread.ApplicationThread applicationThread = \u6bb5\u4f4d.\u4e2d\u53f0.getApplicationThread();
                IIntentReceiver iIntentReceiver = IIntentReceiver.Stub.asInterface((IBinder)iBinder);
                Bundle bundle = Bundle.EMPTY;
                applicationThread.scheduleRegisteredReceiver(iIntentReceiver, intent, -1, null, bundle, false, false, true, \u98ce\u53e3.\u95ed\u73af, 20, -1, null);
                return;
            }
            IIntentReceiver iIntentReceiver = IIntentReceiver.Stub.asInterface((IBinder)iBinder);
            Bundle bundle = Bundle.EMPTY;
            iIntentReceiver.performReceive(intent, -1, null, bundle, false, false, \u98ce\u53e3.\u4e2d\u53f0);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static final void \u8d4b\u80fd(LoadedApk loadedApk, Intent intent, String string2) {
        try {
            BroadcastReceiver broadcastReceiver;
            \u6bb5\u4f4d.\u6293\u624b.getClass();
            \u81ea\u6d3d \u81ea\u6d3d2 = \u6bb5\u4f4d.\u5bf9\u9f50;
            Instrumentation instrumentation = \u6bb5\u4f4d.\u4e2d\u53f0.getInstrumentation();
            Object[] arrobject = new Object[]{Boolean.FALSE, instrumentation};
            Application application = (Application)\u81ea\u6d3d2.\u8d4b\u80fd((Object)loadedApk, arrobject);
            ClassLoader classLoader = loadedApk.getClassLoader();
            intent.setExtrasClassLoader(classLoader);
            Context context = application.getBaseContext();
            if (\u62bd\u8c61.\u6f0f\u6597) {
                broadcastReceiver = loadedApk.getAppFactory().instantiateReceiver(classLoader, string2, intent);
            } else {
                Constructor constructor = classLoader.loadClass(string2).getDeclaredConstructor(\u4e0b\u6c89.\u6293\u624b);
                constructor.setAccessible(true);
                broadcastReceiver = (BroadcastReceiver)constructor.newInstance(\u4e0b\u6c89.\u4e2d\u53f0);
            }
            \u8d4b\u80fd.\u8d4b\u80fd((Object)broadcastReceiver, \u6293\u624b);
            broadcastReceiver.onReceive(context, intent);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static void \u8d4b\u80fd(Intent intent, String string2) {
        \u6a2a\u5411$$ExternalSyntheticLambda1 \u6a2a\u5411$$ExternalSyntheticLambda1 = new \u6a2a\u5411$$ExternalSyntheticLambda1(intent, string2);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u6a2a\u5411$$ExternalSyntheticLambda1);
    }

    public static void \u8d4b\u80fd(IBinder iBinder, Intent intent) {
        \u6a2a\u5411$$ExternalSyntheticLambda0 \u6a2a\u5411$$ExternalSyntheticLambda0 = new \u6a2a\u5411$$ExternalSyntheticLambda0(iBinder, intent);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u6a2a\u5411$$ExternalSyntheticLambda0);
    }
}

