/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda10
implements Runnable {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda10(String string2) {
        this.f$0 = string2;
    }

    public final void run() {
        \u8fb9\u754c.\u805a\u7126((String)this.f$0);
    }
}

