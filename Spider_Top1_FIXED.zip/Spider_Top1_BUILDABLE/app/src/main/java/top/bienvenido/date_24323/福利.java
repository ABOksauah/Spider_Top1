/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u7f8a\u6bdb
 *  top.bienvenido.date_24323.\u97ed\u83dc
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b;
import top.bienvenido.date_24323.\u7f8a\u6bdb;
import top.bienvenido.date_24323.\u97ed\u83dc;

public final class \u798f\u5229
extends \u62a2\u54c1\u7c7b {
    public final \u97ed\u83dc \u6293\u624b = \u97ed\u83dc.\u8d4b\u80fd;
    public final \u7f8a\u6bdb \u8d4b\u80fd = \u7f8a\u6bdb.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

