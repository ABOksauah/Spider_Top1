/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u611f\u77e5;

public final class \u611f\u77e5$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ IBinder f$1;

    public /* synthetic */ \u611f\u77e5$$ExternalSyntheticLambda1(IBinder iBinder, IBinder iBinder2) {
        this.f$0 = iBinder;
        this.f$1 = iBinder2;
    }

    public final Object invoke(Object object) {
        return \u611f\u77e5.\u8d4b\u80fd(this.f$0, this.f$1, (\u5e03\u5c40)object);
    }
}

