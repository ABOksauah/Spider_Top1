/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.util.List;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

public final class \u8bc1\u8a00
extends FunctionReferenceImpl
implements Function1 {
    public static final \u8bc1\u8a00 \u8d4b\u80fd = new \u8bc1\u8a00();

    public \u8bc1\u8a00() {
        super(1, ParceledListSlice.class, "getList", "getList()Ljava/util/List;", 0);
    }

    public final Object invoke(Object object) {
        return ((ParceledListSlice)object).getList();
    }
}

