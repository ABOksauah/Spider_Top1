/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u6e20\u9053
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ String \u540c\u6b65;

    public \u6e20\u9053(String string, String string2, IAccountManagerResponse iAccountManagerResponse) {
        this.\u540c\u6b65 = string2;
        super(iAccountManagerResponse, string, false, false, null, false, false);
    }

    @Override
    public final void onResult(Bundle bundle) {
        if (bundle != null) {
            String string = bundle.getString("authTokenLabelKey");
            Bundle bundle2 = new Bundle();
            bundle2.putString("authTokenLabelKey", string);
            super.onResult(bundle2);
            return;
        }
        super.onResult(bundle);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.getAuthTokenLabel((IAccountAuthenticatorResponse)this, this.\u540c\u6b65);
        }
    }
}

