/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ResolveInfo
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ResolveInfo;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5361\u8ba4\u77e5$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public abstract class \u5361\u8ba4\u77e5
extends \u89e6\u8fbe {
    public static final ResolveInfo \u8d4b\u80fd(\u5361\u8ba4\u77e5 \u5361\u8ba4\u77e52, Object object, Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Function4 function4 = \u5361\u8ba4\u77e52.\u6293\u624b();
        Object object2 = arrobject[1];
        String string = object2 != null ? object2.toString() : null;
        Object object3 = arrobject[2];
        int n = object3 instanceof Number ? ((Number)object3).intValue() : 0;
        return (ResolveInfo)function4.invoke((Object)\u94f8\u90202, object, (Object)string, (Object)n);
    }

    public abstract Function4 \u6293\u624b();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        ResolveInfo resolveInfo;
        try {
            Object object2 = arrobject[0];
            resolveInfo = object2 instanceof Intent ? (ResolveInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u5361\u8ba4\u77e5$$ExternalSyntheticLambda0(this, object2, arrobject)) : null;
        }
        catch (Exception exception) {
            return null;
        }
        if (resolveInfo == null) {
            \u89e6\u8fbe.\u8d4b\u80fd(arrobject, 2);
            resolveInfo = (ResolveInfo)method.invoke(object, arrobject);
        }
        if (resolveInfo != null) {
            \u6269\u5c55.\u8d4b\u80fd(((ComponentInfo)this.\u8d4b\u80fd().invoke((Object)resolveInfo)).applicationInfo);
            return resolveInfo;
        }
        return null;
    }

    public abstract Function1 \u8d4b\u80fd();
}

