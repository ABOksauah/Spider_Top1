/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5fc3\u667a;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5fc3\u667a$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Intent f$0;

    public /* synthetic */ \u5fc3\u667a$$ExternalSyntheticLambda0(Intent intent) {
        this.f$0 = intent;
    }

    public final Object invoke(Object object) {
        return \u5fc3\u667a.\u8d4b\u80fd(this.f$0, (\u94f8\u9020)object);
    }
}

