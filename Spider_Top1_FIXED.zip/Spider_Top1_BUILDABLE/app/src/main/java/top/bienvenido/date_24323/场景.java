/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.System
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import top.bienvenido.date_24323.\u5165\u53e3;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;
import top.bienvenido.date_24323.\u5f15\u7206\u70b9;
import top.bienvenido.date_24323.\u611f\u77e5\u5ea6;
import top.bienvenido.date_24323.\u65b9\u6cd5\u8bba;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u7ec4\u5408\u62f3;

public final class \u573a\u666f
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ boolean \u4f18\u5316;
    public final /* synthetic */ Account \u540c\u6b65;
    public final /* synthetic */ Bundle \u5bf9\u6807;
    public final /* synthetic */ String \u5bf9\u9f50;
    public final /* synthetic */ boolean \u8fed\u4ee3;

    public \u573a\u666f(IAccountManagerResponse iAccountManagerResponse, boolean bl, Account account, String string, Bundle bundle, boolean bl2, boolean bl3, String string2, String string3) {
        this.\u540c\u6b65 = account;
        this.\u5bf9\u9f50 = string;
        this.\u5bf9\u6807 = bundle;
        this.\u8fed\u4ee3 = bl2;
        this.\u4f18\u5316 = bl3;
        super(iAccountManagerResponse, string2, bl, false, string3, false, false);
    }

    @Override
    public final void onResult(Bundle bundle) {
        if (bundle != null) {
            String string = bundle.getString("authtoken");
            if (string != null) {
                String string2 = bundle.getString("authAccount");
                String string3 = bundle.getString("accountType");
                if (string3 != null && string3.length() != 0 && string2 != null && string2.length() != 0) {
                    if (!this.\u8fed\u4ee3) {
                        \u683c\u5c40.\u6293\u624b.\u6293\u624b(new Account(string2, string3), this.\u5bf9\u9f50, string);
                    }
                    long l = bundle.getLong("android.accounts.expiry", 0L);
                    if (this.\u8fed\u4ee3 && l > System.currentTimeMillis()) {
                        \u683c\u5c40 \u683c\u5c402 = \u683c\u5c40.\u6293\u624b;
                        Account account = this.\u540c\u6b65;
                        String string4 = this.\u5bf9\u9f50;
                        \u683c\u5c402.getClass();
                        if (account != null && string4 != null) {
                            \u5f15\u7206\u70b9 \u5f15\u7206\u70b92 = \u683c\u5c40.\u4e2d\u53f0.\u4e2d\u53f0;
                            \u5f15\u7206\u70b92.getClass();
                            if (System.currentTimeMillis() <= l) {
                                \u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62 = new \u611f\u77e5\u5ea6(account, string4);
                                \u7ec4\u5408\u62f3 \u7ec4\u5408\u62f32 = new \u7ec4\u5408\u62f3(string, l);
                                \u5f15\u7206\u70b92.\u8d4b\u80fd.\u8d4b\u80fd(\u611f\u77e5\u5ea62, \u7ec4\u5408\u62f32);
                            }
                        }
                    }
                } else {
                    this.onError(5, "the type and name should not be empty");
                    return;
                }
            }
            if ((Intent)bundle.getParcelable("intent") != null && this.\u4f18\u5316 && !this.\u8fed\u4ee3) {
                \u5f00\u573a\u5b50.\u8d4b\u80fd(bundle);
            }
        }
        super.onResult(bundle);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator;
        try {
            iAccountAuthenticator = this.\u7ed9\u5230;
            if (iAccountAuthenticator == null) return;
        }
        catch (Exception exception) {
            return;
        }
        iAccountAuthenticator.getAuthToken((IAccountAuthenticatorResponse)this, this.\u540c\u6b65, this.\u5bf9\u9f50, this.\u5bf9\u6807);
    }
}

