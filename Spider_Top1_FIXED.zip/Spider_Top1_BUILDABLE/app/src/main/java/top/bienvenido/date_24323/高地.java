/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.ConditionVariable
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.IInterface
 *  android.os.Process
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.util.concurrent.ExecutorService
 *  kotlin.Triple
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u516c\u5173
 *  top.bienvenido.date_24323.\u52a9\u529b
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u683c\u5c40
 *  top.bienvenido.date_24323.\u8fb9\u754c
 *  top.bienvenido.date_24323.\u9ad8\u5730$
 *  top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda5
 *  top.bienvenido.mundo.manifest.MundoService
 *  top.bienvenido.mundo.manifest.MundoService$Companion
 *  top.bienvenido.mundo.manifest.MundoService$Companion$STUB
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Process;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.concurrent.ExecutorService;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u52a9\u529b;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5934\u90e8;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u6fc0\u6d3b;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u84dd\u6d77;
import top.bienvenido.date_24323.\u8f6c\u578b;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u9635\u5730;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u9ad8\u5730$;
import top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u9ad8\u5730$$ExternalSyntheticLambda4;
import top.bienvenido.mundo.common.initialize.MNative;
import top.bienvenido.mundo.manifest.MundoService;

public abstract class \u9ad8\u5730 {
    public static final \u78b0\u4e00\u4e0b \u4e2d\u53f0;
    public static final \u78b0\u4e00\u4e0b \u6293\u624b;
    public static int \u6f0f\u6597;
    public static String \u843d\u5730;
    public static Triple \u8d4b\u80fd;
    public static final \u78b0\u4e00\u4e0b \u95ed\u73af;

    static {
        \u6293\u624b = new \u78b0\u4e00\u4e0b();
        \u4e2d\u53f0 = new \u78b0\u4e00\u4e0b();
        \u95ed\u73af = new \u78b0\u4e00\u4e0b();
        \u843d\u5730 = "";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u4e2d\u53f0(int n) {
        try {
            Triple triple = \u8d4b\u80fd;
            if (triple == null) return;
            if (((Number)triple.getFirst()).intValue() != n) return;
            IBinder iBinder = ((\u6fc0\u6d3b)triple.getSecond()).asBinder();
            if (iBinder.isBinderAlive() && iBinder.pingBinder()) {
                return;
            }
            boolean bl = false;
            if (bl) return;
            \u8d4b\u80fd = null;
            \u9ad8\u5730.\u8d4b\u80fd(n);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static final void \u4e2d\u53f0(int n, \u54c1\u724c \u54c1\u724c2) {
        \u9ad8\u5730.\u8d4b\u80fd(n, true, (Function2)new $ExternalSyntheticLambda0(\u54c1\u724c2));
    }

    public static \u54c1\u724c \u6293\u624b(String string2, String string3, String string4) {
        \u54c1\u724c \u54c1\u724c2 = \u9ad8\u5730.\u8d4b\u80fd(string3, string4);
        if (\u54c1\u724c2 == null) {
            \u54c1\u724c \u54c1\u724c3 = \u9ad8\u5730.\u8d4b\u80fd(string2, string3, string4);
            if (\u54c1\u724c3 != null) {
                \u54c1\u724c3.\u54cd\u5e94.block(10000L);
                if (\u54c1\u724c3.\u6c89\u6dc0) {
                    return \u54c1\u724c3;
                }
            }
            return null;
        }
        return \u54c1\u724c2;
    }

    public static final void \u6293\u624b(int n) {
        try {
            \u9ad8\u5730.\u8d4b\u80fd(n, false, (Function2)new $ExternalSyntheticLambda5(n));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u6293\u624b(int n, \u54c1\u724c \u54c1\u724c2) {
        "Using cache stub -> " + n;
        \u9ad8\u5730.\u8d4b\u80fd(\u54c1\u724c2);
        if (\u6f0f\u6597 == 0) {
            int n2;
            block5 : {
                for (n2 = 1; n2 < 25; ++n2) {
                    try {
                        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd;
                        int n3 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n2);
                        if (n3 >= 0) {
                            continue;
                        }
                        break block5;
                    }
                    catch (Exception exception) {
                        // empty catch block
                        break;
                    }
                }
                n2 = 0;
            }
            \u9ad8\u5730.\u8d4b\u80fd(n2);
            \u6f0f\u6597 = n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void \u6293\u624b(\u54c1\u724c \u54c1\u724c2) {
        int n;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        try {
            \u5408\u529b.\u6293\u624b.\u8d4b\u80fd(\u54c1\u724c2);
            \u78b0\u4e00\u4e0b2 = \u6293\u624b;
            n = \u54c1\u724c2.\u843d\u5730;
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return;
        }
        \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u6293\u624b(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u4e2d\u53f0.\u6293\u624b(\u54c1\u724c2.\u5e73\u53f0);
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b4 = \u95ed\u73af;
        String string2 = \u54c1\u724c2.\u6293\u624b;
        String string3 = \u54c1\u724c2.\u4e2d\u53f0;
        \u78b0\u4e00\u4e0b4.\u6293\u624b(string2.hashCode() + string3.hashCode());
        \u516c\u5173.\u6293\u624b.getClass();
        \u516c\u5173.\u8d4b\u80fd((\u54c1\u724c)\u54c1\u724c2);
    }

    public static final Unit \u8d4b\u80fd(int n, \u6fc0\u6d3b \u6fc0\u6d3b2, int n2) {
        if (\u6fc0\u6d3b2 == null) {
            return Unit.INSTANCE;
        }
        "Cache stub success -> " + n2;
        \u8d4b\u80fd = new Triple((Object)n, (Object)\u6fc0\u6d3b2, (Object)n2);
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final Unit \u8d4b\u80fd(\u54c1\u724c \u54c1\u724c2, \u6fc0\u6d3b \u6fc0\u6d3b2, int n) {
        \u54c1\u724c2.\u7ed9\u5230 = \u6fc0\u6d3b2;
        \u54c1\u724c2.\u5e73\u53f0 = n;
        \u9ad8\u5730.\u8d4b\u80fd(\u54c1\u724c2);
        if (\u6f0f\u6597 == 0) {
            int n2;
            block5 : {
                for (n2 = 1; n2 < 25; ++n2) {
                    try {
                        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd;
                        int n3 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n2);
                        if (n3 >= 0) {
                            continue;
                        }
                        break block5;
                    }
                    catch (Exception exception) {
                        // empty catch block
                        break;
                    }
                }
                n2 = 0;
            }
            \u9ad8\u5730.\u8d4b\u80fd(n2);
            \u6f0f\u6597 = n2;
        }
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static \u54c1\u724c \u8d4b\u80fd(String string2, String string3) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        int n;
        try {
            \u78b0\u4e00\u4e0b2 = \u95ed\u73af;
            n = string2.hashCode() + string3.hashCode();
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return null;
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        return (\u54c1\u724c)object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static \u54c1\u724c \u8d4b\u80fd(String string2, String string3, String string4) {
        \u54c1\u724c \u54c1\u724c2;
        ApplicationInfo applicationInfo;
        String string5;
        String string6;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        int n;
        block23 : {
            int n2;
            block22 : {
                boolean bl;
                Object object;
                block21 : {
                    n = 0;
                    try {
                        Object object2 = MNative.\u8d4b\u80fd(61181, null);
                        if (object2 == null) return null;
                        bl = Boolean.parseBoolean((String)object2.toString());
                        break block21;
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    return null;
                }
                if (!bl) {
                    return null;
                }
                try {
                    object = MNative.\u8d4b\u80fd(61188, (Serializable)"2379a0fb1cc59a8a0d85cce27facd00f91f722b2ddbdc99a168879abe1c5741fe909c6edbd8e6ad846ed7307178ae4cdb6b169dfb32ea70f830cbc4fe86abe3a");
                }
                catch (Throwable throwable) {
                    object = null;
                }
                Class class_ = (Class)object;
                if (class_ == null) {
                    return null;
                }
                ApplicationInfo applicationInfo2 = (ApplicationInfo)class_.getConstructor(null).newInstance(null);
                applicationInfo2.packageName = string2;
                applicationInfo2.processName = string3;
                applicationInfo2.name = string4;
                \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
                \u8fb9\u754c2.getClass();
                try {
                    if (!\u8fb9\u754c2.\u5bf9\u6807(string2)) {
                        \u8fb9\u754c.\u95ed\u73af.put(string2, new \u5934\u90e8(string2, new \u5dee\u5f02\u5316(string4)));
                        \u683c\u5c40.\u6293\u624b.getClass();
                        \u683c\u5c40.\u5e73\u53f0();
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
                Class[] arrclass = new Class[n2];
                arrclass[0] = class_;
                Constructor constructor = class_.getConstructor(arrclass);
                Object[] arrobject = new Object[n2];
                arrobject[0] = applicationInfo2;
                applicationInfo = (ApplicationInfo)constructor.newInstance(arrobject);
                int n3 = \u6f0f\u6597;
                if (n3 == 0) break block22;
                \u6f0f\u6597 = 0;
                n = n3;
                break block23;
            }
            for (n2 = 1; n2 < 25; ++n2) {
                try {
                    \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd;
                    int n4 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n2);
                    if (n4 >= 0) {
                        continue;
                    }
                    n = n2;
                    break;
                }
                catch (Exception exception) {
                    // empty catch block
                    break;
                }
            }
        }
        if (n == 0) {
            return null;
        }
        try {
            \u8fb9\u754c.\u6293\u624b.getClass();
            boolean bl = \u8fb9\u754c.\u4e2d\u53f0.containsKey(string2);
            int n5 = \u84dd\u6d77.\u8d4b\u80fd(applicationInfo.packageName, bl);
            String string7 = applicationInfo.packageName;
            string5 = applicationInfo.processName;
            string6 = applicationInfo.name;
            \u54c1\u724c2 = new \u54c1\u724c(string7, string5, string6, bl, n, n5);
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return null;
        }
        \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n, \u54c1\u724c2);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u95ed\u73af.\u8d4b\u80fd(string5.hashCode() + string6.hashCode(), \u54c1\u724c2);
        \u9ad8\u5730.\u8d4b\u80fd(n, \u54c1\u724c2);
        return \u54c1\u724c2;
    }

    public static void \u8d4b\u80fd() {
        int n = \u6f0f\u6597;
        if (n != 0) {
            \u9ad8\u5730$$ExternalSyntheticLambda4 \u9ad8\u5730$$ExternalSyntheticLambda4 = new \u9ad8\u5730$$ExternalSyntheticLambda4(n);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u9ad8\u5730$$ExternalSyntheticLambda4);
        }
    }

    public static void \u8d4b\u80fd(int n) {
        \u9ad8\u5730$$ExternalSyntheticLambda1 \u9ad8\u5730$$ExternalSyntheticLambda1 = new \u9ad8\u5730$$ExternalSyntheticLambda1(n);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u9ad8\u5730$$ExternalSyntheticLambda1);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u8d4b\u80fd(int n, \u54c1\u724c \u54c1\u724c2) {
        IBinder iBinder;
        Triple triple;
        boolean bl;
        try {
            triple = \u8d4b\u80fd;
            \u8d4b\u80fd = null;
        }
        catch (Exception exception) {
            return;
        }
        if (triple != null && ((Number)triple.getFirst()).intValue() == n && (bl = (iBinder = ((\u6fc0\u6d3b)triple.getSecond()).asBinder()).isBinderAlive() && iBinder.pingBinder())) {
            \u54c1\u724c2.\u5e73\u53f0 = ((Number)triple.getThird()).intValue();
            \u54c1\u724c2.\u7ed9\u5230 = (\u6fc0\u6d3b)triple.getSecond();
            \u9ad8\u5730$$ExternalSyntheticLambda2 \u9ad8\u5730$$ExternalSyntheticLambda2 = new \u9ad8\u5730$$ExternalSyntheticLambda2(n, \u54c1\u724c2);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u9ad8\u5730$$ExternalSyntheticLambda2);
            return;
        }
        \u9ad8\u5730$$ExternalSyntheticLambda3 \u9ad8\u5730$$ExternalSyntheticLambda3 = new \u9ad8\u5730$$ExternalSyntheticLambda3(n, \u54c1\u724c2);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u9ad8\u5730$$ExternalSyntheticLambda3);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void \u8d4b\u80fd(int var0, boolean var1_1, Function2 var2_2) {
        block6 : {
            try {
                var4_3 = \u98ce\u53e3.\u8d4b\u80fd;
                var5_4 = var4_3.getContentResolver();
                var6_5 = \u98ce\u53e3.\u6293\u624b;
                var7_6 = var6_5 + ".provider.stub" + var0;
                var8_7 = Uri.parse((String)("content://" + var7_6));
                var9_8 = String.valueOf((int)var0);
                \u8f6c\u578b.\u8d4b\u80fd.getClass();
                var11_9 = \u8f6c\u578b.\u6293\u624b;
                var11_9.putBoolean("mundo_base_bundle", \u8fb9\u754c.\u6293\u624b.\u5bf9\u6807("com.google.android.gms"));
                var13_10 = var5_4.call(var8_7, var9_8, null, var11_9);
                if (var13_10 == null) {
                    var2_2.invoke(null, (Object)0);
                    return;
                }
                var15_11 = var13_10.getBinder("user_handler");
                var16_12 = var13_10.getInt("user_pid", 0);
                var17_13 = var13_10.getBoolean("MundoAppThread", false);
                var20_15 = var15_11 != null ? ((var19_14 = var15_11.queryLocalInterface("MundoAppThread")) != null && var19_14 instanceof \u6fc0\u6d3b ? (\u6fc0\u6d3b)var19_14 : new \u52a9\u529b(var15_11)) : null;
                if (var20_15 == null) ** GOTO lbl41
                if (!var17_13) ** GOTO lbl36
                if (!var1_1) break block6;
                if (var16_12 == 0) ** GOTO lbl28
            }
            catch (Exception var3_19) {
                return;
            }
            try {
                Process.killProcess((int)var16_12);
                break block6;
lbl28: // 1 sources:
                var20_15.\u6f0f\u6597();
            }
            catch (Exception var27_16) {
                // empty catch block
            }
        }
        var2_2.invoke(null, (Object)var16_12);
        return;
lbl36: // 1 sources:
        var2_2.invoke(var20_15, (Object)var16_12);
        var23_17 = new Intent();
        var24_18 = MundoService.Companion.STUB.class.getName();
        var4_3.startService(var23_17.setComponent(new ComponentName(var6_5, var24_18 + var0)));
        return;
lbl41: // 1 sources:
        var2_2.invoke(null, (Object)var16_12);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void \u8d4b\u80fd(\u54c1\u724c var0) {
        block9 : {
            var3_1 = var0.\u7ed9\u5230;
            if (var3_1 != null) break block9;
            \u9ad8\u5730.\u6293\u624b(var0);
            var0.\u6c89\u6dc0 = false;
            var0.\u54cd\u5e94.open();
            return;
            {
                catch (Exception var2_2) {
                    return;
                }
            }
        }
        try {
            var4_3 = var0.\u5e73\u53f0;
            if (var4_3 == 0) ** GOTO lbl-1000
            var8_5 = var5_4 = \u9ad8\u5730.\u4e2d\u53f0;
            // MONITORENTER : var8_5
        }
        catch (Exception var1_7) {
            \u9ad8\u5730.\u6293\u624b(var0);
            var0.\u6c89\u6dc0 = false;
            var0.\u54cd\u5e94.open();
            return;
        }
        var5_4.\u8d4b\u80fd.\u8d4b\u80fd(var4_3, var0);
        // MONITOREXIT : var8_5
lbl-1000: // 2 sources:
        {
            var7_6 = var3_1.asBinder();
            var7_6.linkToDeath((IBinder.DeathRecipient)new \u9635\u5730(var7_6, var0), 0);
            var3_1.\u8d4b\u80fd(var0.\u8d4b\u80fd, var0.\u6293\u624b, var0.\u4e2d\u53f0, var0.\u95ed\u73af, \u9ad8\u5730.\u843d\u5730);
            var0.\u54cd\u5e94.open();
            return;
        }
    }
}

