/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u5171\u521b;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u5f15\u5bfc;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62c9\u5347;
import top.bienvenido.date_24323.\u62c9\u901a;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u5bdf;
import top.bienvenido.date_24323.\u8054\u52a8;
import top.bienvenido.date_24323.\u878d\u5408;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u900f\u4f20;

public final class \u652f\u6491
extends FunctionReferenceImpl
implements Function1 {
    public \u652f\u6491() {
        super(1, (Object)\u6d1e\u5bdf.\u8d4b\u80fd, \u6d1e\u5bdf.class, "makeProxyByOriginController", "makeProxyByOriginController(Ljava/lang/Object;)Ljava/lang/Object;", 0);
    }

    public final Object invoke(Object object) {
        ((\u6d1e\u5bdf)this.receiver).getClass();
        \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u672c\u6211.\u6293\u624b);
        \u5171\u521b \u5171\u521b2 = new \u5171\u521b();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(463520714, \u5171\u521b2);
        \u878d\u5408 \u878d\u54082 = new \u878d\u5408();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1293072352, \u878d\u54082);
        \u8054\u52a8 \u8054\u52a82 = \u900f\u4f20.\u8d4b\u80fd;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1666360360, \u8054\u52a82);
        \u534f\u540c \u534f\u540c2 = \u900f\u4f20.\u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1770569149, \u534f\u540c2);
        \u62c9\u901a \u62c9\u901a2 = new \u62c9\u901a();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1349683719, \u62c9\u901a2);
        \u62c9\u5347 \u62c9\u53472 = new \u62c9\u5347();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1985825802, \u62c9\u53472);
        \u5f15\u5bfc \u5f15\u5bfc2 = \u5f15\u5bfc.\u8d4b\u80fd;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1111243300, \u5f15\u5bfc2);
        return \u51fa\u51fb2.\u95ed\u73af;
    }
}

