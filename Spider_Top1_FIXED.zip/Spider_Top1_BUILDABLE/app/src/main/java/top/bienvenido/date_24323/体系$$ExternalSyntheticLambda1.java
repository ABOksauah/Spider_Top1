/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4f53\u7cfb;

public final class \u4f53\u7cfb$$ExternalSyntheticLambda1
implements Function1 {
    public final Object invoke(Object object) {
        return \u4f53\u7cfb.\u8d4b\u80fd((PackageManager)object);
    }
}

