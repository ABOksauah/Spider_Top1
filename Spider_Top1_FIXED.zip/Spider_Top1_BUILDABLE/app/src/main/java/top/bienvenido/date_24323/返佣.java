/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u6241\u5e73\u5316;

public final class \u8fd4\u4f63 {
    public static final \u8fd4\u4f63 \u6293\u624b = new \u8fd4\u4f63(0);
    public final \u6241\u5e73\u5316 \u8d4b\u80fd;

    public \u8fd4\u4f63(int n) {
        this.\u8d4b\u80fd = new \u6241\u5e73\u5316(n);
    }
}

