/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IIntentReceiver
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u62b9\u5e73
 */
package top.bienvenido.date_24323;

import android.content.IIntentReceiver;
import top.bienvenido.date_24323.\u62b9\u5e73;

public final class \u62b9\u5e73$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ IIntentReceiver f$0;

    public /* synthetic */ \u62b9\u5e73$$ExternalSyntheticLambda1(IIntentReceiver iIntentReceiver) {
        this.f$0 = iIntentReceiver;
    }

    public final void run() {
        \u62b9\u5e73.\u8d4b\u80fd((IIntentReceiver)this.f$0);
    }
}

