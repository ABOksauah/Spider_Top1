/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.nfc.NfcAdapter
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.nfc.NfcAdapter;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u914d\u79f0
extends \u96c6\u6210 {
    public static final \u914d\u79f0 \u6293\u624b = new \u914d\u79f0();

    @Override
    public final void \u8d4b\u80fd() {
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter((Context)\u98ce\u53e3.\u8d4b\u80fd);
        if (nfcAdapter == null) {
            return;
        }
        \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(NfcAdapter.class, "sService");
        Object object = \u81ea\u6d3d2.\u8d4b\u80fd((Object)nfcAdapter);
        if (object == null) {
            return;
        }
        this.\u8d4b\u80fd = \u672c\u6211.\u4e2d\u53f0;
        \u51fa\u51fb \u51fa\u51fb2 = this.\u8d4b\u80fd("nfc", object);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, \u51fa\u51fb2.\u95ed\u73af);
    }
}

