/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function3
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u53e3\u7891
extends FunctionReferenceImpl
implements Function3 {
    public static final \u53e3\u7891 \u8d4b\u80fd = new \u53e3\u7891();

    public \u53e3\u7891() {
        super(3, \u94f8\u9020.class, "getApplicationInfo", "getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;", 0);
    }

    public final Object invoke(Object object, Object object2, Object object3) {
        return ((\u94f8\u9020)object).\u6293\u624b((String)object2, ((Number)object3).intValue());
    }
}

