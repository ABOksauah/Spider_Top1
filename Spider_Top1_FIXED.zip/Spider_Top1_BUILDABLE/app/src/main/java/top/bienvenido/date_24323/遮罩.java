/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u906e\u7f69$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u906e\u7f69
extends \u89e6\u53d1 {
    public static final Unit \u8d4b\u80fd(ComponentName componentName, Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Object object = arrobject[1];
        int n = object instanceof Number ? ((Number)object).intValue() : 0;
        \u94f8\u90202.\u8d4b\u80fd(componentName, n);
        return Unit.INSTANCE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
        ComponentName componentName = (ComponentName)arrobject[0];
        if (componentName == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            \u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u906e\u7f69$$ExternalSyntheticLambda0(componentName, arrobject));
            return null;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

