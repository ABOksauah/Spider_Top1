/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.os.IBinder
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u84c4\u80fd$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94fe\u8def;

public final class \u84c4\u80fd
extends \u89e6\u53d1 {
    public static final boolean \u8d4b\u80fd(ComponentName componentName, IBinder iBinder, Integer n, \u7b14\u82af \u7b14\u82af2) {
        int n2 = n != null ? n : -1;
        return \u7b14\u82af2.\u8d4b\u80fd(componentName, iBinder, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IBinder iBinder;
        Integer n;
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
        ComponentName componentName = (ComponentName)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, ComponentName.class);
        Boolean bl = (Boolean)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u84c4\u80fd$$ExternalSyntheticLambda0(componentName, iBinder = (IBinder)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, IBinder.class), n = (Integer)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Integer.class)));
        if (bl == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            if (bl == false) return super.\u8d4b\u80fd(object, method, arrobject);
            return Boolean.TRUE;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

