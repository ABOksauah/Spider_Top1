/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ServiceInfo
 *  android.os.Binder
 *  kotlin.Pair
 */
package top.bienvenido.date_24323;

import android.content.pm.ServiceInfo;
import android.os.Binder;
import kotlin.Pair;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;

public final class \u53d8\u9769
extends Binder {
    public Pair \u4e2d\u53f0;
    public final ServiceInfo \u6293\u624b;
    public final \u5dee\u5f02\u5316 \u6f0f\u6597;
    public final \u515c\u5e95 \u843d\u5730;
    public final \u54c1\u724c \u8d4b\u80fd;
    public int \u95ed\u73af;

    public \u53d8\u9769(\u54c1\u724c \u54c1\u724c2, ServiceInfo serviceInfo) {
        this.\u8d4b\u80fd = \u54c1\u724c2;
        this.\u6293\u624b = serviceInfo;
        this.\u843d\u5730 = new \u515c\u5e95(0);
        this.\u6f0f\u6597 = new \u5dee\u5f02\u5316();
    }
}

