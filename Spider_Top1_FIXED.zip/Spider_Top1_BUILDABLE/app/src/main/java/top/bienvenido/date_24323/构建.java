/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u642d\u5efa;

public abstract class \u6784\u5efa
extends Binder
implements \u5e03\u5c40 {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u6784\u5efa() {
        this.attachInterface((IInterface)this, "MundoWindowManagerService");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        if (n >= 1 && n <= 16777215) {
            parcel.enforceInterface("MundoWindowManagerService");
        }
        if (n == 1598968902) {
            parcel2.writeString("MundoWindowManagerService");
            return true;
        }
        Object object = null;
        switch (n) {
            int n3;
            default: {
                return super.onTransact(n, parcel, parcel2, n2);
            }
            case 20: {
                parcel.readString();
                return true;
            }
            case 19: {
                int n4 = ((\u516c\u5173)this).\u4e2d\u53f0();
                parcel2.writeNoException();
                parcel2.writeInt(n4);
                return true;
            }
            case 18: {
                String string = ((\u516c\u5173)this).\u8d4b\u80fd();
                parcel2.writeNoException();
                parcel2.writeString(string);
                return true;
            }
            case 17: {
                String string = parcel.readString();
                ((\u516c\u5173)this).\u4e2d\u53f0(string);
                return true;
            }
            case 16: {
                IBinder iBinder = parcel.readStrongBinder();
                int n5 = ((\u516c\u5173)this).\u95ed\u73af(iBinder);
                parcel2.writeNoException();
                parcel2.writeInt(n5);
                return true;
            }
            case 15: {
                String string = parcel.readString();
                String string2 = parcel.readString();
                ((\u516c\u5173)this).\u843d\u5730(string, string2);
                return true;
            }
            case 14: {
                String string = parcel.readString();
                String string3 = parcel.readString();
                int n6 = ((\u516c\u5173)this).\u6293\u624b(string, string3);
                parcel2.writeNoException();
                parcel2.writeInt(n6);
                return true;
            }
            case 13: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = ((\u516c\u5173)this).\u7ed9\u5230(iBinder);
                parcel2.writeNoException();
                parcel2.writeString(string);
                return true;
            }
            case 12: {
                IBinder iBinder = parcel.readStrongBinder();
                ComponentName componentName = ((\u516c\u5173)this).\u8d4b\u80fd(iBinder);
                parcel2.writeNoException();
                \u642d\u5efa.\u8d4b\u80fd(parcel2, (Parcelable)componentName, 1);
                return true;
            }
            case 11: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                String string4 = parcel.readString();
                String string5 = parcel.readString();
                int n7 = parcel.readInt();
                ((\u516c\u5173)this).\u8d4b\u80fd(iBinder, string, string4, string5, n7);
                parcel2.writeNoException();
                return true;
            }
            case 10: {
                long l = parcel.readLong();
                int n8 = parcel.readInt();
                List list = ((\u516c\u5173)this).\u8d4b\u80fd(l, n8);
                parcel2.writeNoException();
                if (list == null) {
                    parcel2.writeInt(-1);
                    return true;
                }
                int n9 = list.size();
                parcel2.writeInt(n9);
                for (n3 = 0; n3 < n9; ++n3) {
                    \u642d\u5efa.\u8d4b\u80fd(parcel2, (Parcelable)list.get(n3), 1);
                }
                break;
            }
            case 9: {
                long l = parcel.readLong();
                List list = ((\u516c\u5173)this).\u8d4b\u80fd(l);
                parcel2.writeNoException();
                if (list == null) {
                    parcel2.writeInt(-1);
                    return true;
                }
                int n10 = list.size();
                parcel2.writeInt(n10);
                while (n3 < n10) {
                    \u642d\u5efa.\u8d4b\u80fd(parcel2, (Parcelable)list.get(n3), 1);
                    ++n3;
                }
                break;
            }
            case 8: {
                IBinder iBinder = parcel.readStrongBinder();
                ((\u516c\u5173)this).\u6f0f\u6597(iBinder);
                return true;
            }
            case 7: {
                \u516c\u5173.\u8d4b\u80fd(null, parcel.readString(), parcel.readString());
                return true;
            }
            case 6: {
                String string = parcel.readString();
                String string6 = parcel.readString();
                int n11 = ((\u516c\u5173)this).\u6f0f\u6597(string, string6);
                parcel2.writeNoException();
                parcel2.writeInt(n11);
                return true;
            }
            case 5: {
                IBinder iBinder = parcel.readStrongBinder();
                IBinder iBinder2 = parcel.readStrongBinder();
                ((\u516c\u5173)this).\u8d4b\u80fd(iBinder, iBinder2);
                return true;
            }
            case 4: {
                long l = parcel.readLong();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                Intent intent2 = ((\u516c\u5173)this).\u8d4b\u80fd(l, intent);
                parcel2.writeNoException();
                \u642d\u5efa.\u8d4b\u80fd(parcel2, (Parcelable)intent2, 1);
                return true;
            }
            case 3: {
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                String string = parcel.readString();
                ((\u516c\u5173)this).\u8d4b\u80fd(intent, string);
                return true;
            }
            case 2: {
                IBinder iBinder = parcel.readStrongBinder();
                Intent[] arrintent = (Intent[])parcel.createTypedArray(Intent.CREATOR);
                int n12 = parcel.readInt();
                Intent[] arrintent2 = ((\u516c\u5173)this).\u8d4b\u80fd(iBinder, arrintent, n12);
                parcel2.writeNoException();
                parcel2.writeTypedArray((Parcelable[])arrintent2, 1);
                return true;
            }
            case 1: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Intent.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Intent intent = (Intent)object;
                int n13 = parcel.readInt();
                int n14 = parcel.readInt();
                boolean bl = false;
                if (n14 != 0) {
                    bl = true;
                }
                Intent intent3 = ((\u516c\u5173)this).\u8d4b\u80fd(iBinder, intent, n13, bl);
                parcel2.writeNoException();
                \u642d\u5efa.\u8d4b\u80fd(parcel2, (Parcelable)intent3, 1);
            }
        }
        return true;
    }
}

