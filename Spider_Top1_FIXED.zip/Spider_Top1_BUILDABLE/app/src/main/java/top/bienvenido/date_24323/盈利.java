/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.SharedLibraryInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.SharedLibraryInfo;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u6307\u6807;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u76c8\u5229
extends \u89e6\u8fbe {
    public final \u6307\u6807 \u8d4b\u80fd;

    public \u76c8\u5229(\u6307\u6807 \u6307\u68072) {
        this.\u8d4b\u80fd = \u6307\u68072;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        int n;
        int n2;
        String[] arrstring;
        ArrayList arrayList;
        Object object2 = this.\u8d4b\u80fd.\u8d4b\u80fd(object, method, arrobject);
        try {
            if (!(object2 instanceof ApplicationInfo) || !Intrinsics.areEqual((Object)((ApplicationInfo)object2).packageName, (Object)\u6c34\u4f4d.\u6293\u624b) || \u6c34\u4f4d.\u6f0f\u6597) return object2;
            List list = (List)\u51b7\u542f\u52a8.\u8d4b\u80fd.\u6293\u624b.\u8d4b\u80fd(object2);
            if (list != null) {
                Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    if (!Intrinsics.areEqual((Object)"com.huawei.easygo", (Object)((SharedLibraryInfo)iterator.next()).getName())) continue;
                    iterator.remove();
                }
            }
            if ((arrstring = ((ApplicationInfo)object2).sharedLibraryFiles) == null) return object2;
            if (arrstring.length == 0) {
                return object2;
            }
            arrayList = new ArrayList(arrstring.length);
            n2 = arrstring.length;
            n = 0;
        }
        catch (Exception exception) {
            // empty catch block
            return object2;
        }
        do {
            if (n < n2) {
                String string = arrstring[n];
                if (!StringsKt.endsWith$default((String)string, (String)"HwEasyGo.apk", (boolean)false, (int)2, null)) {
                    arrayList.add((Object)string);
                }
            } else {
                if (arrstring.length == arrayList.size()) return object2;
                ((ApplicationInfo)object2).sharedLibraryFiles = (String[])arrayList.toArray((Object[])\u4e0b\u6c89.\u95ed\u73af);
                return object2;
            }
            ++n;
        } while (true);
    }
}

