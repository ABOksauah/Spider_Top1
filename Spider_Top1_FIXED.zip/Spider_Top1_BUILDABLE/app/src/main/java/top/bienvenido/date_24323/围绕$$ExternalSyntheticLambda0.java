/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u56f4\u7ed5$$ExternalSyntheticLambda0
implements InvocationHandler {
    public final /* synthetic */ \u89e6\u8fbe f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ \u56f4\u7ed5$$ExternalSyntheticLambda0(\u89e6\u8fbe \u89e6\u8fbe2, Object object) {
        this.f$0 = \u89e6\u8fbe2;
        this.f$1 = object;
    }

    public final Object invoke(Object object, Method method, Object[] arrobject) {
        return \u56f4\u7ed5.\u8d4b\u80fd(this.f$0, this.f$1, object, method, arrobject);
    }
}

