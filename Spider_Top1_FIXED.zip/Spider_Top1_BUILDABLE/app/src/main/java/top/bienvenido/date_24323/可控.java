/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u56f0\u5c40;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u7a33\u5b9a;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u53ef\u63a7
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = super.\u8d4b\u80fd(object, method, arrobject);
        if (object2 == null) {
            return null;
        }
        try {
            \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object2, \u672c\u6211.\u4e2d\u53f0);
            \u56f0\u5c40 \u56f0\u5c402 = new \u56f0\u5c40(new \u7a33\u5b9a());
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(339680146, \u56f0\u5c402);
            Object object3 = \u51fa\u51fb2.\u95ed\u73af;
            return object3;
        }
        catch (Exception exception) {
            return object2;
        }
    }
}

