/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u5bf9\u6807$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u5bf9\u6807
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        IInterface iInterface = (IInterface)arrobject[0];
        IBinder iBinder = iInterface != null ? iInterface.asBinder() : null;
        Object object = arrobject[1];
        String string = null;
        if (object != null) {
            string = object.toString();
        }
        \u589e\u957f2.\u8d4b\u80fd(iBinder, string, Intrinsics.areEqual((Object)arrobject[2], (Object)Boolean.TRUE));
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u5bf9\u6807$$ExternalSyntheticLambda0(arrobject));
    }
}

