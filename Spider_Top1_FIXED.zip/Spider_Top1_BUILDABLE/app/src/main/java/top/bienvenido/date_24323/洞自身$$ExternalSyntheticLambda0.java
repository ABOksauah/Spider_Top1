/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u8e1d\u90e8;

public final class \u6d1e\u81ea\u8eab$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u6d1e\u81ea\u8eab.\u8d4b\u80fd((\u8e1d\u90e8)object);
    }
}

