/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.media.session.MediaSession
 *  android.media.session.MediaSession$Token
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.media.session.MediaSession;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6d3b\u8dc3;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u6d3b\u8dc3$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u81ea\u6d3d f$0;

    public /* synthetic */ \u6d3b\u8dc3$$ExternalSyntheticLambda0(\u81ea\u6d3d \u81ea\u6d3d2) {
        this.f$0 = \u81ea\u6d3d2;
    }

    public final Object invoke(Object object) {
        return \u6d3b\u8dc3.\u8d4b\u80fd(this.f$0, (MediaSession.Token)object);
    }
}

