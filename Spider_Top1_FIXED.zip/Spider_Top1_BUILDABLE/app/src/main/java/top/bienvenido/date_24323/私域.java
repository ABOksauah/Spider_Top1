/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u79c1\u57df
extends \u89e6\u8fbe {
    public final /* synthetic */ Object \u8d4b\u80fd;

    public \u79c1\u57df(Object object) {
        this.\u8d4b\u80fd = object;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return this.\u8d4b\u80fd;
    }
}

