/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import top.bienvenido.date_24323.\u6a2a\u5411;

public final class \u6a2a\u5411$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ \u6a2a\u5411$$ExternalSyntheticLambda1(Intent intent, String string2) {
        this.f$0 = intent;
        this.f$1 = string2;
    }

    public final void run() {
        \u6a2a\u5411.\u6293\u624b(this.f$0, this.f$1);
    }
}

