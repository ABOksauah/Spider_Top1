/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u652f\u6491
 *  top.bienvenido.date_24323.\u6a21\u578b
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u5171\u521b;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u56f0\u5c40;
import top.bienvenido.date_24323.\u5f15\u5bfc;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u62c9\u5347;
import top.bienvenido.date_24323.\u62c9\u901a;
import top.bienvenido.date_24323.\u652f\u6491;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6a21\u578b;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8054\u52a8;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u878d\u5408;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d70\u51fa\u53bb;
import top.bienvenido.date_24323.\u8f90\u5c04;
import top.bienvenido.date_24323.\u900f\u4f20;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u534f\u8c03
extends \u96c6\u6210 {
    public static final \u534f\u8c03 \u6293\u624b = new \u534f\u8c03();

    @Override
    public final void \u8d4b\u80fd() {
        Object object;
        this.\u8d4b\u80fd = \u672c\u6211.\u4e2d\u53f0;
        try {
            object = \u771f\u9999.\u8d4b\u80fd("android.app.ActivityTaskManager", "IActivityTaskManagerSingleton").\u8d4b\u80fd(null);
        }
        catch (Exception exception) {
            object = null;
        }
        if (object == null) {
            return;
        }
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("activity_task", this.\u8d4b\u80fd, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        Object object2 = \u51fa\u51fb2.\u95ed\u73af;
        \u8d70\u51fa\u53bb.\u8d4b\u80fd.\u8d4b\u80fd(object, object2);
        if (\u62bd\u8c61.\u5347\u7ea7) {
            \u81ea\u6d3d \u81ea\u6d3d2;
            String string = \u62bd\u8c61.\u8ddf\u8fdb && \u62bd\u8c61.\u5e73\u53f0 ? "com.hihonor.android.app.HwActivityTaskManager" : "com.huawei.android.app.HwActivityTaskManager";
            Class[] arrclass = \u4e0b\u6c89.\u6293\u624b;
            try {
                \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(Class.forName((String)string), "getService", arrclass);
            }
            catch (Exception exception) {
                \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
            }
            \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, new Object[0]);
        }
        \u6a21\u578b.\u6293\u624b.\u8d4b\u80fd(\u51fa\u51fb2);
        if (!\u62bd\u8c61.\u5e73\u53f0) {
            \u5171\u521b \u5171\u521b2 = new \u5171\u521b();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(463520714, \u5171\u521b2);
            \u878d\u5408 \u878d\u54082 = new \u878d\u5408();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1293072352, \u878d\u54082);
            \u8054\u52a8 \u8054\u52a82 = \u900f\u4f20.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1666360360, \u8054\u52a82);
            \u534f\u540c \u534f\u540c2 = \u900f\u4f20.\u6293\u624b;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1770569149, \u534f\u540c2);
            \u62c9\u901a \u62c9\u901a2 = new \u62c9\u901a();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1349683719, \u62c9\u901a2);
            \u62c9\u5347 \u62c9\u53472 = new \u62c9\u5347();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1985825802, \u62c9\u53472);
            \u5f15\u5bfc \u5f15\u5bfc2 = \u5f15\u5bfc.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1111243300, \u5f15\u5bfc2);
        }
        \u56f0\u5c40 \u56f0\u5c402 = new \u56f0\u5c40((Function1)new \u652f\u6491());
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-516686740, \u56f0\u5c402);
        \u8f90\u5c04 \u8f90\u5c042 = \u8f90\u5c04.\u8d4b\u80fd;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1059947677, \u8f90\u5c042);
    }
}

