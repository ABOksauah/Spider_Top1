/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u4e0d\u53ef\u63a7;

public final class \u4e0d\u53ef\u63a7$$ExternalSyntheticLambda0
implements Function0 {
    public final Object invoke() {
        return \u4e0d\u53ef\u63a7.\u8d4b\u80fd();
    }
}

