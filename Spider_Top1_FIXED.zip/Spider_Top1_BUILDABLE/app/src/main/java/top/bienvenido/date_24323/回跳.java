/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.usage.StorageStats
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  sun.misc.Unsafe
 */
package top.bienvenido.date_24323;

import android.app.usage.StorageStats;
import java.lang.reflect.Method;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u56de\u8df3
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = super.\u8d4b\u80fd(object, method, arrobject);
        if (object2 == null) {
            try {
                Object object3 = \u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(StorageStats.class);
                return object3;
            }
            catch (Throwable throwable) {
                object2 = null;
            }
        }
        return object2;
    }
}

