/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u5e74\u6846;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u7ec8\u7aef
extends \u89e6\u53d1 {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        \u5e74\u6846.\u8d4b\u80fd(\u5e74\u6846.\u6293\u624b, arrobject);
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

