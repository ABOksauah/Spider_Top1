/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Package
 *  android.content.pm.PackageParser$SigningDetails
 *  android.content.pm.Signature
 *  android.content.pm.SigningDetails
 *  android.content.pm.SigningInfo
 *  android.os.Build
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.android.internal.content.NativeLibraryHelper
 *  com.android.internal.content.NativeLibraryHelper$Handle
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.security.PublicKey
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateFactory
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.collections.ArraysKt
 *  kotlin.io.FilesKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u64cd\u76d8
 *  top.bienvenido.date_24323.\u8d77\u98de
 *  top.bienvenido.date_24323.\u8fb9\u754c
 *  top.bienvenido.date_24323.\u9884\u5224$
 *  top.bienvenido.date_24323.\u9884\u5224$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageParser;
import android.content.pm.Signature;
import android.content.pm.SigningDetails;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import com.android.internal.content.NativeLibraryHelper;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.ArraysKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u4ed8\u8d39;
import top.bienvenido.date_24323.\u4f53\u7cfb;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u5934\u90e8;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u64cd\u76d8;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53ca;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u8f6c\u5316;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u9884\u5224$;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u9884\u5224 {
    public static Pair \u4e2d\u53f0(File file, boolean bl) {
        \u64cd\u76d8 \u64cd\u76d82;
        block3 : {
            try {
                Pair pair = \u9884\u5224.\u6293\u624b(file, bl);
                \u64cd\u76d82 = (\u64cd\u76d8)pair.getSecond();
                if (\u64cd\u76d82 != null) break block3;
                return pair;
            }
            catch (Exception exception) {
                return TuplesKt.to((Object)-1, null);
            }
        }
        \u9884\u5224.\u8d4b\u80fd(\u64cd\u76d82);
        Pair pair = TuplesKt.to((Object)1, (Object)\u64cd\u76d82);
        return pair;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Pair \u6293\u624b(File file, boolean bl) {
        try {
            void var9_8;
            long l;
            if (!\u4f53\u7cfb.\u8d4b\u80fd()) {
                return TuplesKt.to((Object)-3, null);
            }
            PackageInfo packageInfo = (PackageInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(file, -2147483584));
            if (packageInfo == null) {
                packageInfo = \u9884\u5224.\u8d4b\u80fd(file);
            }
            if (packageInfo == null) {
                return TuplesKt.to((Object)-2, null);
            }
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (applicationInfo == null) {
                return TuplesKt.to((Object)-5, null);
            }
            String string2 = packageInfo.packageName;
            \u5408\u529b.\u6293\u624b.\u95ed\u73af(string2, null);
            \u8fb9\u754c.\u6293\u624b.getClass();
            \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u8fb9\u754c.\u4e2d\u53f0.get(string2);
            if (\u64cd\u76d82 != null) {
                \u64cd\u76d8 \u64cd\u76d83 = \u64cd\u76d82;
            } else {
                \u5934\u90e8 \u5934\u90e82 = (\u5934\u90e8)\u8fb9\u754c.\u95ed\u73af.get(string2);
            }
            \u5dee\u5f02\u5316 \u5dee\u5f02\u53162 = var9_8 != null ? var9_8.\u6293\u624b : new \u5dee\u5f02\u5316("0");
            packageInfo.lastUpdateTime = l = System.currentTimeMillis();
            packageInfo.firstInstallTime = \u64cd\u76d82 != null ? \u64cd\u76d82.\u4e2d\u53f0.firstInstallTime : l;
            packageInfo.splitNames = \u4e0b\u6c89.\u95ed\u73af;
            File file2 = \u89e6\u53ca.\u6293\u624b;
            \u8f6c\u5316.\u4e2d\u53f0(new File(file2, string2));
            File file3 = new File(file2, string2);
            file3.mkdirs();
            File file4 = new File(file3, "base.apk");
            if (!bl || !file.renameTo(file4)) {
                FilesKt.copyTo$default((File)file, (File)file4, (boolean)true, (int)0, (int)4, null);
            }
            String string3 = file4.getCanonicalPath();
            \u771f\u9999.\u8d4b\u80fd(ApplicationInfo.class, String.valueOf((Object)\u4f53\u7cfb.\u8d4b\u80fd("37e41a97f6a8ef509c6669dafc9c29a7"))).\u8d4b\u80fd((Object)applicationInfo, (Object)string3);
            \u771f\u9999.\u8d4b\u80fd(ApplicationInfo.class, String.valueOf((Object)\u4f53\u7cfb.\u8d4b\u80fd("3c380e0df24a9aec04f367bcbab97a01"))).\u8d4b\u80fd((Object)applicationInfo, (Object)string3);
            applicationInfo.dataDir = "/dev/null";
            \u64cd\u76d8 \u64cd\u76d84 = new \u64cd\u76d8(packageInfo, applicationInfo, \u5dee\u5f02\u53162);
            if (\u62bd\u8c61.\u6f0f\u6597) {
                boolean bl2 = \u62bd\u8c61.\u7ed9\u5230;
                String[] arrstring = bl2 ? new String[]{"/system/framework/org.apache.http.legacy.jar", "/system/framework/android.test.base.jar"} : (\u62bd\u8c61.\u6c89\u6dc0 ? new String[]{"/system/framework/org.apache.http.legacy.jar"} : new String[]{"/system/framework/org.apache.http.legacy.boot.jar"});
                applicationInfo.sharedLibraryFiles = arrstring;
            }
            File file5 = \u89e6\u53ca.\u6293\u624b(string2);
            applicationInfo.nativeLibraryDir = file5.getAbsolutePath();
            \u8d77\u98de \u8d77\u98de2 = \u51b7\u542f\u52a8.\u4e2d\u53f0;
            String string4 = file4.getParent();
            if (string4 == null) {
                string4 = "/";
            }
            \u51b7\u542f\u52a8.\u95ed\u73af.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, (Object)string4);
            \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, (Object)string4);
            if (\u62bd\u8c61.\u540c\u6b65) {
                file4.setReadOnly();
            }
            \u8d77\u98de \u8d77\u98de3 = \u51b7\u542f\u52a8.\u6293\u624b;
            String string5 = \u9884\u5224.\u8d4b\u80fd()[\u9884\u5224.\u8d4b\u80fd(file4, file5)];
            \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, (Object)string5);
            (\u5934\u90e8)\u8fb9\u754c.\u95ed\u73af.remove(string2);
            return TuplesKt.to((Object)0, (Object)\u64cd\u76d84);
        }
        catch (Throwable throwable) {
            return TuplesKt.to((Object)-1, null);
        }
    }

    public static int \u8d4b\u80fd(File file, File file2) {
        block3 : {
            NativeLibraryHelper.Handle handle;
            int n;
            try {
                handle = NativeLibraryHelper.Handle.create((File)file);
                n = NativeLibraryHelper.findSupportedAbi((NativeLibraryHelper.Handle)handle, (String[])\u9884\u5224.\u8d4b\u80fd());
                if (n < 0) break block3;
            }
            catch (Throwable throwable) {
                return 0;
            }
            NativeLibraryHelper.copyNativeBinaries((NativeLibraryHelper.Handle)handle, (File)file2, (String)\u9884\u5224.\u8d4b\u80fd()[n]);
            return n;
        }
        return 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static PackageInfo \u8d4b\u80fd(File var0) {
        var1_1 = new PackageInfo();
        var2_2 = new PackageParser();
        var3_3 = 0;
        var5_4 = var2_2.parsePackage(var0, 0);
        var1_1.packageName = var6_5 = var5_4.packageName;
        var1_1.lastUpdateTime = System.currentTimeMillis();
        var1_1.firstInstallTime = System.currentTimeMillis();
        var1_1.applicationInfo = var5_4.applicationInfo;
        if (\u62bd\u8c61.\u8d4b\u80fd) {
            var1_1.baseRevisionCode = var5_4.baseRevisionCode;
            var1_1.splitRevisionCodes = \u4e0b\u6c89.\u8d4b\u80fd;
        }
        if (var7_6 = \u62bd\u8c61.\u6f0f\u6597) {
            var8_7 = var5_4.mVersionCodeMajor;
            var9_8 = var5_4.mVersionCode;
            var1_1.setLongVersionCode((long)var8_7 << 32 | 0xFFFFFFFFL & (long)var9_8);
        } else {
            var1_1.versionCode = var5_4.mVersionCode;
        }
        var1_1.splitNames = \u4e0b\u6c89.\u95ed\u73af;
        var1_1.versionName = var5_4.mVersionName;
        var1_1.sharedUserLabel = var5_4.mSharedUserLabel;
        var1_1.sharedUserId = var5_4.mSharedUserId;
        var1_1.installLocation = var5_4.installLocation;
        var1_1.gids = \u4e0b\u6c89.\u8d4b\u80fd;
        try {
            var11_9 = var6_5.hashCode();
            if (!ArraysKt.contains((int[])\u4ed8\u8d39.\u6293\u624b, (int)var11_9) && !Intrinsics.areEqual((Object)var5_4.mSigningDetails, (Object)PackageParser.SigningDetails.UNKNOWN)) {
                if (var7_6) {
                    var25_10 = var5_4.mSigningDetails;
                    var12_11 = TuplesKt.to((Object)var25_10.signatures, (Object)var25_10.signatureSchemeVersion);
                } else {
                    var12_11 = TuplesKt.to((Object)var5_4.mSignatures, (Object)0);
                }
            } else {
                var12_11 = TuplesKt.to((Object)new Signature[]{new Signature("308204433082032ba003020102020900c2e08746644a308d300d06092a864886f70d01010405003074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f6964301e170d3038303832313233313333345a170d3336303130373233313333345a3074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f696430820120300d06092a864886f70d01010105000382010d00308201080282010100ab562e00d83ba208ae0a966f124e29da11f2ab56d08f58e2cca91303e9b754d372f640a71b1dcb130967624e4656a7776a92193db2e5bfb724a91e77188b0e6a47a43b33d9609b77183145ccdf7b2e586674c9e1565b1f4c6a5955bff251a63dabf9c55c27222252e875e4f8154a645f897168c0b1bfc612eabf785769bb34aa7984dc7e2ea2764cae8307d8c17154d7ee5f64a51a44a602c249054157dc02cd5f5c0e55fbef8519fbe327f0b1511692c5a06f19d18385f5c4dbc2d6b93f68cc2979c70e18ab93866b3bd5db8999552a0e3b4c99df58fb918bedc182ba35e003c1b4b10dd244a8ee24fffd333872ab5221985edab0fc0d0b145b6aa192858e79020103a381d93081d6301d0603551d0e04160414c77d8cc2211756259a7fd382df6be398e4d786a53081a60603551d2304819e30819b8014c77d8cc2211756259a7fd382df6be398e4d786a5a178a4763074310b3009060355040613025553311330110603550408130a43616c69666f726e6961311630140603550407130d4d6f756e7461696e205669657731143012060355040a130b476f6f676c6520496e632e3110300e060355040b1307416e64726f69643110300e06035504031307416e64726f6964820900c2e08746644a308d300c0603551d13040530030101ff300d06092a864886f70d010104050003820101006dd252ceef85302c360aaace939bcff2cca904bb5d7a1661f8ae46b2994204d0ff4a68c7ed1a531ec4595a623ce60763b167297a7ae35712c407f208f0cb109429124d7b106219c084ca3eb3f9ad5fb871ef92269a8be28bf16d44c8d9a08e6cb2f005bb3fe2cb96447e868e731076ad45b33f6009ea19c161e62641aa99271dfd5228c5c587875ddb7f452758d661f6cc0cccb7352e424cc4365c523532f7325137593c4ae341f4db41edda0d0b1071a7c440f0fe9ea01cb627ca674369d084bd2fd911ff06cdbf2cfa10dc0f893ae35762919048c7efc64c7144178342f70581c9de573af55b390dd7fdb9418631895d5f759f30112687ff621410c069308a")}, (Object)2);
            }
            if (!var7_6) ** GOTO lbl54
            if (\u62bd\u8c61.\u5bf9\u9f50) {
                var18_12 = ((Number)var12_11.getSecond()).intValue();
                var19_13 = ArraysKt.asList((Object[])((Object[])var12_11.getFirst()));
                var20_14 = (Signature[])var12_11.getFirst();
                var21_15 = new ArrayList(var20_14.length);
                var22_16 = var20_14.length;
            } else {
                var13_19 = \u62bd\u8c61.\u54cd\u5e94;
                var14_20 = var13_19 != false ? SigningDetails.class : PackageParser.SigningDetails.class;
                var15_21 = SigningInfo.class.getDeclaredConstructor(new Class[]{var14_20});
                var15_21.setAccessible(true);
                if (var13_19) {
                    var16_22 = new SigningDetails((Signature[])var12_11.getFirst(), ((Number)var12_11.getSecond()).intValue());
                } else {
                    var16_23 = new PackageParser.SigningDetails((Signature[])var12_11.getFirst(), ((Number)var12_11.getSecond()).intValue());
                }
                var17_18 = (SigningInfo)var15_21.newInstance(new Object[]{var16_24});
lbl52: // 2 sources:
                do {
                    var1_1.signingInfo = var17_18;
lbl54: // 2 sources:
                    var1_1.signatures = (Signature[])var12_11.getFirst();
                    return var1_1;
                    break;
                } while (true);
                catch (Throwable var4_26) {
                    return null;
                }
            }
            while (var3_3 < var22_16) {
                var23_17 = var20_14[var3_3].toByteArray();
                var21_15.add((Object)CertificateFactory.getInstance((String)"X.509").generateCertificate((InputStream)new ByteArrayInputStream(var23_17)).getPublicKey());
                ++var3_3;
            }
            var17_18 = new SigningInfo(var18_12, (Collection)var19_13, (Collection)var21_15, null);
            ** continue;
        }
        catch (Throwable var10_25) {
            return var1_1;
        }
    }

    public static final PackageInfo \u8d4b\u80fd(File file, int n, PackageManager packageManager) {
        String string2 = file.getAbsolutePath();
        if (\u62bd\u8c61.\u6f0f\u6597) {
            n |= 134217728;
        }
        return packageManager.getPackageArchiveInfo(string2, n);
    }

    /*
     * Exception decompiling
     */
    public static Pair \u8d4b\u80fd(File var0, boolean var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 42[FORLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void \u8d4b\u80fd(\u64cd\u76d8 \u64cd\u76d82) {
        try {
            String string2 = \u64cd\u76d82.\u8d4b\u80fd;
            File file = \u6253\u78e8.\u8d4b\u80fd(\u89e6\u53ca.\u6293\u624b, string2, "installation.bin");
            Parcel parcel = Parcel.obtain();
            parcel.writeParcelable((Parcelable)\u64cd\u76d82.\u4e2d\u53f0, 0);
            byte[] arrby = parcel.marshall();
            parcel.recycle();
            FilesKt.writeBytes((File)file, (byte[])arrby);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static String[] \u8d4b\u80fd() {
        if (\u89e6\u53ca.\u8d4b\u80fd) {
            return Build.SUPPORTED_64_BIT_ABIS;
        }
        String[] arrstring = Build.SUPPORTED_32_BIT_ABIS;
        if (arrstring.length == 0) {
            arrstring = new String[]{"armeabi-v7a", "armeabi"};
        }
        return arrstring;
    }
}

