/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u5168\u57df;

public final class \u5168\u57df$$ExternalSyntheticLambda0
implements Thread.UncaughtExceptionHandler {
    public final /* synthetic */ Thread.UncaughtExceptionHandler f$0;

    public /* synthetic */ \u5168\u57df$$ExternalSyntheticLambda0(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f$0 = uncaughtExceptionHandler;
    }

    public final void uncaughtException(Thread thread, Throwable throwable) {
        \u5168\u57df.\u8d4b\u80fd(this.f$0, thread, throwable);
    }
}

