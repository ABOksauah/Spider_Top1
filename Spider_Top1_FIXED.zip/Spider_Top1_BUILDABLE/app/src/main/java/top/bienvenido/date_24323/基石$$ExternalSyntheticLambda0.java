/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$ObjectRef
 *  top.bienvenido.date_24323.\u57fa\u77f3
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Ref;
import top.bienvenido.date_24323.\u57fa\u77f3;
import top.bienvenido.date_24323.\u5e03\u5c40;

public final class \u57fa\u77f3$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Ref.ObjectRef f$0;
    public final /* synthetic */ Intent[] f$1;

    public /* synthetic */ \u57fa\u77f3$$ExternalSyntheticLambda0(Ref.ObjectRef objectRef, Intent[] arrintent) {
        this.f$0 = objectRef;
        this.f$1 = arrintent;
    }

    public final Object invoke(Object object) {
        return \u57fa\u77f3.\u8d4b\u80fd((Ref.ObjectRef)this.f$0, (Intent[])this.f$1, (\u5e03\u5c40)((\u5e03\u5c40)object));
    }
}

