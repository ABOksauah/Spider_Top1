/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u9ad8\u5730;

public final class \u9ad8\u5730$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ int f$0;

    public /* synthetic */ \u9ad8\u5730$$ExternalSyntheticLambda4(int n) {
        this.f$0 = n;
    }

    public final void run() {
        \u9ad8\u5730.\u4e2d\u53f0(this.f$0);
    }
}

