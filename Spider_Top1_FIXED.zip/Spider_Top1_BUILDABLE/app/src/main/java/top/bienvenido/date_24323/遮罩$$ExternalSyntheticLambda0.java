/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u906e\u7f69
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u906e\u7f69;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u906e\u7f69$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ ComponentName f$0;
    public final /* synthetic */ Object[] f$1;

    public /* synthetic */ \u906e\u7f69$$ExternalSyntheticLambda0(ComponentName componentName, Object[] arrobject) {
        this.f$0 = componentName;
        this.f$1 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u906e\u7f69.\u8d4b\u80fd((ComponentName)this.f$0, (Object[])this.f$1, (\u94f8\u9020)((\u94f8\u9020)object));
    }
}

