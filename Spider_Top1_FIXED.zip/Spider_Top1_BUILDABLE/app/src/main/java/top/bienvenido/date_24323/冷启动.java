/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public abstract class \u51b7\u542f\u52a8 {
    public static final \u8d77\u98de \u4e2d\u53f0;
    public static final \u8d77\u98de \u6293\u624b;
    public static final \u8d77\u98de \u6c89\u6dc0;
    public static final \u8d77\u98de \u6f0f\u6597;
    public static final \u81ea\u6d3d \u7ed9\u5230;
    public static final \u8d77\u98de \u843d\u5730;
    public static final \u8d77\u98de \u8d4b\u80fd;
    public static final \u8d77\u98de \u95ed\u73af;

    static {
        \u8d4b\u80fd = new \u8d77\u98de("sharedLibraryInfos");
        \u6293\u624b = new \u8d77\u98de("primaryCpuAbi");
        \u4e2d\u53f0 = new \u8d77\u98de("scanSourceDir");
        \u95ed\u73af = new \u8d77\u98de("scanPublicSourceDir");
        \u843d\u5730 = new \u8d77\u98de("intent");
        \u6f0f\u6597 = new \u8d77\u98de("networkSecurityConfigRes");
        \u6c89\u6dc0 = new \u8d77\u98de("mPath");
        \u81ea\u6d3d \u81ea\u6d3d2 = \u62bd\u8c61.\u4e2d\u53f0 ? \u771f\u9999.\u8d4b\u80fd(ApplicationInfo.class, "credentialProtectedDataDir") : \u81ea\u6d3d.\u8d4b\u80fd;
        \u7ed9\u5230 = \u81ea\u6d3d2;
    }
}

