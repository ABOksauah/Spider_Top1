/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationChannel
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.app.NotificationChannel;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u5206\u53d1;
import top.bienvenido.date_24323.\u56de\u6d41;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u529b\u573a
extends \u89e6\u53d1 {
    public final int \u6293\u624b;

    public \u529b\u573a() {
        int n = \u62bd\u8c61.\u6c89\u6dc0 ? 3 : 1;
        this.\u6293\u624b = n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        try {
            if (!\u6c34\u4f4d.\u8d4b\u80fd) {
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            int n = arrobject.length;
            int n2 = this.\u6293\u624b;
            if (n > n2) {
                arrobject[n2] = \u5206\u53d1.\u8d4b\u80fd(\u6c34\u4f4d.\u6293\u624b, String.valueOf((Object)arrobject[n2]));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if ((object2 = super.\u8d4b\u80fd(object, method, arrobject)) instanceof NotificationChannel) {
            \u56de\u6d41.\u8d4b\u80fd((NotificationChannel)object2, \u6c34\u4f4d.\u6293\u624b);
        }
        return object2;
    }
}

