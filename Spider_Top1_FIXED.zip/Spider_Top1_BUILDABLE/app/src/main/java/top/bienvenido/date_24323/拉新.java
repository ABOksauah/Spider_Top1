/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Object
 *  java.util.Collections
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.util.Collections;
import java.util.List;
import top.bienvenido.date_24323.\u660e\u786e;

public abstract class \u62c9\u65b0 {
    public static final ParceledListSlice \u8d4b\u80fd = \u660e\u786e.\u8d4b\u80fd(Collections.EMPTY_LIST);
}

