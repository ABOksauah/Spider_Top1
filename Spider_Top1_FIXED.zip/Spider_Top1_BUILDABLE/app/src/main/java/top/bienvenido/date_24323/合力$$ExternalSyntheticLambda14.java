/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  kotlin.Pair
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import kotlin.Pair;
import top.bienvenido.date_24323.\u53d8\u9769;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda14
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ \u53d8\u9769 f$1;
    public final /* synthetic */ Pair f$2;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda14(IBinder iBinder, \u53d8\u9769 \u53d8\u97692, Pair pair) {
        this.f$0 = iBinder;
        this.f$1 = \u53d8\u97692;
        this.f$2 = pair;
    }

    public final void run() {
        \u5408\u529b.\u8d4b\u80fd((IBinder)this.f$0, (\u53d8\u9769)this.f$1, (Pair)this.f$2);
    }
}

