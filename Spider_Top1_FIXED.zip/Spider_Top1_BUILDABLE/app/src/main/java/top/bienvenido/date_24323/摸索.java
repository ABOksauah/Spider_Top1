/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u6478\u7d22$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u6478\u7d22
extends \u89e6\u8fbe {
    public final Function1 \u8d4b\u80fd;

    public \u6478\u7d22(Function1 function1) {
        this.\u8d4b\u80fd = function1;
    }

    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u6478\u7d22 \u6478\u7d222, \u589e\u957f \u589e\u957f2) {
        \u589e\u957f2.\u8d4b\u80fd((Account)arrobject[0], (String)\u6478\u7d222.\u8d4b\u80fd.invoke((Object)arrobject));
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u6478\u7d22$$ExternalSyntheticLambda0(arrobject, this));
    }
}

