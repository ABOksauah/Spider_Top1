/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda13
implements Function1 {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda13(String string) {
        this.f$0 = string;
    }

    public final Object invoke(Object object) {
        return \u8fb9\u754c.\u8d4b\u80fd(this.f$0, (PackageManager)object);
    }
}

