/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u63d0\u70bc$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u63d0\u70bc
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        IInterface iInterface = (IInterface)arrobject[0];
        IBinder iBinder = iInterface != null ? iInterface.asBinder() : null;
        \u589e\u957f2.\u8d4b\u80fd(iBinder, (String)arrobject[1], (String[])arrobject[2]);
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u63d0\u70bc$$ExternalSyntheticLambda0(arrobject));
    }
}

