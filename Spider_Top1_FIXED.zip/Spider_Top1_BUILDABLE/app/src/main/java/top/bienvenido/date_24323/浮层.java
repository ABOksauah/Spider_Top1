/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IClipboardManagerExt
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.content.IClipboardManagerExt;

public final class \u6d6e\u5c42
implements IClipboardManagerExt {
}

