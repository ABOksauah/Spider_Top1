/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import java.util.ArrayList;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u670d\u52a1
extends FunctionReferenceImpl
implements Function2 {
    public static final \u670d\u52a1 \u8d4b\u80fd = new \u670d\u52a1();

    public \u670d\u52a1() {
        super(2, \u94f8\u9020.class, "getInstalledPackages", "getInstalledPackages(I)Ljava/util/List;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u4e2d\u53f0(((Number)object2).intValue());
    }
}

