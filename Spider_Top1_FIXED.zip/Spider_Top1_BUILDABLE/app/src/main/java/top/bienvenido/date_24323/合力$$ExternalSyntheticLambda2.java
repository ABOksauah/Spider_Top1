/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda2
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ IBinder f$2;
    public final /* synthetic */ IBinder f$3;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda2(IBinder iBinder, Intent intent, IBinder iBinder2, IBinder iBinder3) {
        this.f$0 = iBinder;
        this.f$1 = intent;
        this.f$2 = iBinder2;
        this.f$3 = iBinder3;
    }

    public final void run() {
        \u5408\u529b.\u8d4b\u80fd((IBinder)this.f$0, (Intent)this.f$1, (IBinder)this.f$2, (IBinder)this.f$3);
    }
}

