/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u74f6\u9888
 *  top.bienvenido.date_24323.\u7b56\u7565
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b;
import top.bienvenido.date_24323.\u74f6\u9888;
import top.bienvenido.date_24323.\u7b56\u7565;

public final class \u4ef7\u503c
extends \u62a2\u54c1\u7c7b {
    public final \u74f6\u9888 \u6293\u624b = \u74f6\u9888.\u8d4b\u80fd;
    public final \u7b56\u7565 \u8d4b\u80fd = \u7b56\u7565.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

