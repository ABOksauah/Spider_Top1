/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.storage.StorageVolume
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.storage.StorageVolume;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u4f18\u5148\u7ea7$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u81ea\u6d3d f$0;
    public final /* synthetic */ StorageVolume f$1;
    public final /* synthetic */ StorageVolume[] f$2;

    public /* synthetic */ \u4f18\u5148\u7ea7$$ExternalSyntheticLambda0(\u81ea\u6d3d \u81ea\u6d3d2, StorageVolume storageVolume, StorageVolume[] arrstorageVolume) {
        this.f$0 = \u81ea\u6d3d2;
        this.f$1 = storageVolume;
        this.f$2 = arrstorageVolume;
    }

    public final Object invoke(Object object) {
        return \u4f18\u5148\u7ea7.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (\u94f8\u9020)object);
    }
}

