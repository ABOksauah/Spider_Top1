/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u6587\u6848
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6c34\u4f4d;

public final class \u59ff\u6001
implements IBinder.DeathRecipient {
    public final /* synthetic */ IBinder \u8d4b\u80fd;

    public \u59ff\u6001(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final void binderDied() {
        try {
            this.\u8d4b\u80fd.unlinkToDeath((IBinder.DeathRecipient)this, 0);
            if (\u6c34\u4f4d.\u8d4b\u80fd) {
                ((\u5e03\u5c40)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd()).\u8d4b\u80fd((IBinder)\u6bb5\u4f4d.\u6293\u624b, \u6c34\u4f4d.\u6293\u624b, \u6c34\u4f4d.\u4e2d\u53f0, \u6c34\u4f4d.\u95ed\u73af, \u6c34\u4f4d.\u6c89\u6dc0);
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

