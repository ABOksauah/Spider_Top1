/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.lang.reflect.Method;
import java.util.List;
import top.bienvenido.date_24323.\u56de\u6d41;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u89e6\u70b9
extends \u89e6\u53d1 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        block4 : {
            object2 = super.\u8d4b\u80fd(object, method, arrobject);
            if (\u6c34\u4f4d.\u8d4b\u80fd) break block4;
            return object2;
        }
        List list = \u660e\u786e.\u8d4b\u80fd(object2);
        if (list == null) return object2;
        try {
            \u56de\u6d41.\u8d4b\u80fd(list, \u6c34\u4f4d.\u6293\u624b);
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return list;
            return \u660e\u786e.\u8d4b\u80fd(list);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return object2;
    }
}

