/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u4e0b\u8dea;
import top.bienvenido.date_24323.\u81f4\u656c;
import top.bienvenido.date_24323.\u8ba2\u9605;

public final class \u75db\u70b9
extends FunctionReferenceImpl
implements Function1 {
    public static final \u75db\u70b9 \u8d4b\u80fd = new \u75db\u70b9();

    public \u75db\u70b9() {
        super(1, \u81f4\u656c.class, "asInterface", "asInterface(Landroid/os/IBinder;)Ltop/bienvenido/mundo/IMundoContentService;", 0);
    }

    public final Object invoke(Object object) {
        IBinder iBinder = (IBinder)object;
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("MundoContentService");
        if (iInterface != null && iInterface instanceof \u8ba2\u9605) {
            return (\u8ba2\u9605)iInterface;
        }
        return new \u4e0b\u8dea(iBinder);
    }
}

