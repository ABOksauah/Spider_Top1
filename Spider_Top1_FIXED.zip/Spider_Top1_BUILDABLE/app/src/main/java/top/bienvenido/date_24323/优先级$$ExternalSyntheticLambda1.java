/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.storage.StorageVolume
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function3
 */
package top.bienvenido.date_24323;

import android.os.storage.StorageVolume;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function3;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;

public final class \u4f18\u5148\u7ea7$$ExternalSyntheticLambda1
implements Function3 {
    public final /* synthetic */ StorageVolume[] f$0;

    public /* synthetic */ \u4f18\u5148\u7ea7$$ExternalSyntheticLambda1(StorageVolume[] arrstorageVolume) {
        this.f$0 = arrstorageVolume;
    }

    public final Object invoke(Object object, Object object2, Object object3) {
        return \u4f18\u5148\u7ea7.\u8d4b\u80fd(this.f$0, object, (Method)object2, (Object[])object3);
    }
}

