/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda12
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ IBinder f$2;
    public final /* synthetic */ int f$3;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda12(String string2, Intent intent, IBinder iBinder, int n) {
        this.f$0 = string2;
        this.f$1 = intent;
        this.f$2 = iBinder;
        this.f$3 = n;
    }

    public final void run() {
        \u6bb5\u4f4d.\u6293\u624b((String)this.f$0, (Intent)this.f$1, (IBinder)this.f$2, (int)this.f$3);
    }
}

