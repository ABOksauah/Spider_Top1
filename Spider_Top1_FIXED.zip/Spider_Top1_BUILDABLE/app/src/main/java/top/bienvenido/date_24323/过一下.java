/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;
import top.bienvenido.date_24323.\u683c\u5c40;

public final class \u8fc7\u4e00\u4e0b
extends \u5f00\u573a\u5b50 {
    public final Account \u540c\u6b65;

    public \u8fc7\u4e00\u4e0b(IAccountManagerResponse iAccountManagerResponse, Account account, boolean bl) {
        super(iAccountManagerResponse, account.type, bl, true, account.name, false, false);
        this.\u540c\u6b65 = account;
    }

    @Override
    public final void onResult(Bundle bundle) {
        if (bundle != null && bundle.containsKey("booleanResult") && !bundle.containsKey("intent")) {
            IAccountManagerResponse iAccountManagerResponse;
            if (bundle.getBoolean("booleanResult")) {
                \u683c\u5c40 \u683c\u5c402 = \u683c\u5c40.\u6293\u624b;
                Account account = this.\u540c\u6b65;
                \u683c\u5c402.getClass();
                \u683c\u5c40.\u95ed\u73af(account);
            }
            if ((iAccountManagerResponse = this.\u540c\u6b65()) != null) {
                try {
                    iAccountManagerResponse.onResult(bundle);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
        super.onResult(bundle);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.getAccountRemovalAllowed((IAccountAuthenticatorResponse)this, this.\u540c\u6b65);
        }
    }
}

