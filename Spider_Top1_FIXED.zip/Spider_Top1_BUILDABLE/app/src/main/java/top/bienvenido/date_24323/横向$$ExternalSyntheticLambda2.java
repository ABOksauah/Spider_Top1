/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.LoadedApk
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.app.LoadedApk;
import android.content.Intent;
import top.bienvenido.date_24323.\u6a2a\u5411;

public final class \u6a2a\u5411$$ExternalSyntheticLambda2
implements Runnable {
    public final /* synthetic */ LoadedApk f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ \u6a2a\u5411$$ExternalSyntheticLambda2(LoadedApk loadedApk, Intent intent, String string2) {
        this.f$0 = loadedApk;
        this.f$1 = intent;
        this.f$2 = string2;
    }

    public final void run() {
        \u6a2a\u5411.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2);
    }
}

