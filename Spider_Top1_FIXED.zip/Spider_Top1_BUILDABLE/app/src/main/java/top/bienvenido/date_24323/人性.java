/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u590d\u5229
 *  top.bienvenido.date_24323.\u6210\u672c
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u5361\u8ba4\u77e5;
import top.bienvenido.date_24323.\u590d\u5229;
import top.bienvenido.date_24323.\u6210\u672c;

public final class \u4eba\u6027
extends \u5361\u8ba4\u77e5 {
    public final \u6210\u672c \u6293\u624b = \u6210\u672c.\u8d4b\u80fd;
    public final \u590d\u5229 \u8d4b\u80fd = \u590d\u5229.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

