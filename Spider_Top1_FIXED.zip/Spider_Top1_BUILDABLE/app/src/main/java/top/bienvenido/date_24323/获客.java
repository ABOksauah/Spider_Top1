/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u4f18\u5148\u7ea7
 *  top.bienvenido.date_24323.\u56f0\u5c40
 *  top.bienvenido.date_24323.\u79c1\u57df
 *  top.bienvenido.date_24323.\u83b7\u5ba2$
 *  top.bienvenido.date_24323.\u83b7\u5ba2$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u56f0\u5c40;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u83b7\u5ba2$;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public abstract class \u83b7\u5ba2 {
    public static final Object \u8d4b\u80fd(int n, \u89e6\u8fbe \u89e6\u8fbe2, Object object) {
        \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u672c\u6211.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(n, \u89e6\u8fbe2);
        return \u51fa\u51fb2.\u95ed\u73af;
    }

    public static \u56f0\u5c40 \u8d4b\u80fd(int n, \u89e6\u8fbe \u89e6\u8fbe2) {
        return new \u56f0\u5c40((Function1)new $ExternalSyntheticLambda0(n, \u89e6\u8fbe2));
    }

    public static boolean \u8d4b\u80fd(Class class_, String string2) {
        \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(class_, string2);
        Object object = \u81ea\u6d3d2.\u8d4b\u80fd(null);
        if (object != null) {
            \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object, \u672c\u6211.\u8d4b\u80fd);
            \u56f0\u5c40 \u56f0\u5c402 = \u83b7\u5ba2.\u8d4b\u80fd(-1850562866, (\u89e6\u8fbe)\u4f18\u5148\u7ea7.\u6293\u624b);
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-89840621, (Object)\u56f0\u5c402);
            \u56f0\u5c40 \u56f0\u5c403 = \u83b7\u5ba2.\u8d4b\u80fd(774213295, (\u89e6\u8fbe)\u672c\u6211.\u6c89\u6dc0);
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1315692475, (Object)\u56f0\u5c403);
            \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, \u51fa\u51fb2.\u95ed\u73af);
            return true;
        }
        return false;
    }
}

