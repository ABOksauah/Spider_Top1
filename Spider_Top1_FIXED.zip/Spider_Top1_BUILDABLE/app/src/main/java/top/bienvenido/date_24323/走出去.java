/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Singleton
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.util.Singleton;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public abstract class \u8d70\u51fa\u53bb {
    public static final \u81ea\u6d3d \u8d4b\u80fd = \u771f\u9999.\u8d4b\u80fd(Singleton.class, "mInstance");
}

