/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u91cd\u5851$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u91cd\u5851
extends \u89e6\u53d1 {
    public static final int \u8d4b\u80fd(Intent intent, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u4e2d\u53f0(intent, \u6c34\u4f4d.\u95ed\u73af);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            String string;
            if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
            Intent intent = (Intent)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Intent.class);
            if (intent == null) return super.\u8d4b\u80fd(object, method, arrobject);
            ComponentName componentName = intent.getComponent();
            if (componentName == null || (string = componentName.getPackageName()) == null) {
                string = intent.getPackage();
            }
            if (Intrinsics.areEqual((Object)string, (Object)\u98ce\u53e3.\u6293\u624b)) return super.\u8d4b\u80fd(object, method, arrobject);
            Integer n = (Integer)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u91cd\u5851$$ExternalSyntheticLambda0(intent));
            int n2 = n != null ? n : -1;
            if (n2 < 0) return super.\u8d4b\u80fd(object, method, arrobject);
            return n2;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

