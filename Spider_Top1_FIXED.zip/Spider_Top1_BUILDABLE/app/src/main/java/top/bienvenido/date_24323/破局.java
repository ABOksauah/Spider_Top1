/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$IntentInfo
 *  android.content.pm.PackageParser$Provider
 *  android.content.pm.PackageParser$ProviderIntentInfo
 *  android.content.pm.ProviderInfo
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u7834\u5708
 *  top.bienvenido.date_24323.\u89e3\u9898
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageParser;
import android.content.pm.ProviderInfo;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u5171\u4eab;
import top.bienvenido.date_24323.\u7834\u5708;
import top.bienvenido.date_24323.\u7ea6\u675f;
import top.bienvenido.date_24323.\u89e3\u9898;

public final class \u7834\u5c40
extends \u5171\u4eab {
    public final /* synthetic */ \u7ea6\u675f \u6c89\u6dc0;

    public \u7834\u5c40(\u7ea6\u675f \u7ea6\u675f2, ArrayList arrayList) {
        this.\u6c89\u6dc0 = \u7ea6\u675f2;
        for (PackageParser.Provider provider : arrayList) {
            ArrayList arrayList2;
            if (provider.info == null || (arrayList2 = provider.intents) == null) continue;
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                this.\u8d4b\u80fd((IntentFilter)((PackageParser.ProviderIntentInfo)iterator.next()));
            }
        }
    }

    @Override
    public final int \u6293\u624b(IntentFilter intentFilter) {
        return ((PackageParser.ProviderIntentInfo)intentFilter).provider.info.name.hashCode();
    }

    @Override
    public final Object \u8d4b\u80fd(IntentFilter intentFilter, int n, int n2) {
        PackageParser.ProviderIntentInfo providerIntentInfo = (PackageParser.ProviderIntentInfo)intentFilter;
        return \u7ea6\u675f.\u8d4b\u80fd(this.\u6c89\u6dc0, (ComponentInfo)providerIntentInfo.provider.info, (Function2)new \u89e3\u9898((Object)\u7834\u5708.\u8d4b\u80fd), (PackageParser.IntentInfo)providerIntentInfo, n2, n);
    }
}

