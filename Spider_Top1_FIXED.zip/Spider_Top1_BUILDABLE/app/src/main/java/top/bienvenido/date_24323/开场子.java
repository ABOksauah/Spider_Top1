/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticator$Stub
 *  android.accounts.IAccountManagerResponse
 *  android.content.ClipData
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.Parcelable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.Map
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountManagerResponse;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ComponentInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u5165\u53e3;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u8d4b\u80fd;
import top.bienvenido.date_24323.\u9884\u8a00;
import top.bienvenido.mundo.common.ext.MundoAccountSession;
import top.bienvenido.mundo.common.ext.MundoServiceConnection;

public abstract class \u5f00\u573a\u5b50
extends MundoAccountSession
implements IBinder.DeathRecipient,
ServiceConnection {
    public static final \u78b0\u4e00\u4e0b \u54cd\u5e94 = new \u78b0\u4e00\u4e0b();
    public final boolean \u4e2d\u53f0;
    public final MundoServiceConnection \u5e73\u53f0;
    public final boolean \u6293\u624b;
    public IAccountManagerResponse \u6c89\u6dc0;
    public final boolean \u6f0f\u6597;
    public IAccountAuthenticator \u7ed9\u5230;
    public final boolean \u843d\u5730;
    public final String \u8d4b\u80fd;
    public final String \u95ed\u73af;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public \u5f00\u573a\u5b50(IAccountManagerResponse iAccountManagerResponse, String string, boolean bl, boolean bl2, String string2, boolean bl3, boolean bl4) {
        this.\u8d4b\u80fd = string;
        this.\u6293\u624b = bl;
        this.\u4e2d\u53f0 = bl2;
        this.\u95ed\u73af = string2;
        this.\u843d\u5730 = bl3;
        this.\u6f0f\u6597 = bl4;
        this.\u6c89\u6dc0 = iAccountManagerResponse;
        this.\u5e73\u53f0 = new MundoServiceConnection(this);
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u54cd\u5e94;
        int n = this.toString().hashCode();
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n, (Object)this);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        if (iAccountManagerResponse == null) return;
        try {
            iAccountManagerResponse.asBinder().linkToDeath((IBinder.DeathRecipient)this, 0);
            return;
        }
        catch (Exception exception) {
            this.\u6c89\u6dc0 = null;
            this.\u54cd\u5e94();
        }
    }

    public static void \u8d4b\u80fd(Bundle bundle) {
        Intent intent = (Intent)bundle.getParcelable("intent");
        if (intent == null) {
            return;
        }
        if (intent.getClipData() == null) {
            intent.setClipData(ClipData.newPlainText(null, null));
        }
    }

    public final void binderDied() {
        this.\u6c89\u6dc0 = null;
        this.\u54cd\u5e94();
    }

    @Override
    public final void onError(int n, String string) {
        IAccountManagerResponse iAccountManagerResponse = this.\u540c\u6b65();
        if (iAccountManagerResponse != null) {
            try {
                iAccountManagerResponse.onError(n, string);
                return;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    @Override
    public final void onRequestContinued() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public void onResult(Bundle var1_1) {
        if (var1_1 != null) {
            var4_2 = var1_1.getBoolean("booleanResult", false);
            var5_3 = var1_1.containsKey("authAccount") != false && var1_1.containsKey("accountType") != false;
            var6_4 = this.\u6f0f\u6597 != false && (var4_2 != false || var5_3 != false);
            if (var6_4 || this.\u843d\u5730) {
                block22 : {
                    block21 : {
                        var7_5 = \u683c\u5c40.\u6293\u624b;
                        var8_6 = this.\u95ed\u73af;
                        var9_7 = this.\u8d4b\u80fd;
                        var7_5.getClass();
                        try {
                            var30_8 = \u683c\u5c40.\u4e2d\u53f0.\u8d4b\u80fd.iterator();
                            while (var30_8.hasNext()) {
                                var31_10 = ((\u8d4b\u80fd)var30_8.next()).\u8d4b\u80fd;
                                if (!Intrinsics.areEqual((Object)var31_10.type, (Object)var9_7) || !(var32_9 = Intrinsics.areEqual((Object)var31_10.name, (Object)var8_6))) continue;
                                break block21;
                            }
                            var12_11 = false;
                            break block22;
                        }
                        catch (Exception var11_12) {
                            // empty catch block
                        }
                    }
                    var12_11 = true;
                }
                var13_13 = "com.google";
                if (var6_4 && var12_11) {
                    var23_14 = \u683c\u5c40.\u6293\u624b;
                    var24_15 = this.\u95ed\u73af;
                    if (var24_15 == null) {
                        var24_15 = var13_13;
                    }
                    var25_16 = new Account(var24_15, this.\u8d4b\u80fd);
                    var23_14.getClass();
                    try {
                        for (\u8d4b\u80fd var29_18 : \u683c\u5c40.\u4e2d\u53f0.\u8d4b\u80fd) {
                            if (!Intrinsics.areEqual((Object)var29_18.\u8d4b\u80fd, (Object)var25_16)) continue;
                            var29_18.\u843d\u5730 = System.currentTimeMillis();
                            break;
                        }
                    }
                    catch (Exception var27_19) {
                        // empty catch block
                    }
                }
                if (this.\u843d\u5730) {
                    var14_20 = -1L;
                    if (var12_11) {
                        var16_21 = \u683c\u5c40.\u6293\u624b;
                        var17_22 = this.\u95ed\u73af;
                        if (var17_22 != null) {
                            var13_13 = var17_22;
                        }
                        var18_23 = new Account(var13_13, this.\u8d4b\u80fd);
                        var16_21.getClass();
                        try {
                            for (\u8d4b\u80fd var22_25 : \u683c\u5c40.\u4e2d\u53f0.\u8d4b\u80fd) {
                                if (!Intrinsics.areEqual((Object)var22_25.\u8d4b\u80fd, (Object)var18_23)) continue;
                                var14_20 = var22_25.\u843d\u5730;
                                break;
                            }
                        }
                        catch (Exception var20_26) {
                            // empty catch block
                        }
                    }
                    var1_1.putLong("lastAuthenticatedTime", var14_20);
                }
            }
        }
        if (var1_1 != null) {
            \u5f00\u573a\u5b50.\u8d4b\u80fd(var1_1);
        }
        var2_27 = this.\u6293\u624b != false && var1_1 != null && var1_1.containsKey("intent") != false ? this.\u6c89\u6dc0 : this.\u540c\u6b65();
        if (var2_27 == null) return;
        if (var1_1 != null) ** GOTO lbl67
        try {
            var2_27.onError(5, "null bundle returned");
            return;
lbl67: // 1 sources:
            if (this.\u4e2d\u53f0) {
                var1_1.remove("authtoken");
            }
            if (var1_1.getInt("errorCode", -1) > 0) {
                var2_27.onError(var1_1.getInt("errorCode"), var1_1.getString("errorMessage"));
                return;
            }
            var2_27.onResult(var1_1);
            return;
        }
        catch (Exception var3_28) {
            // empty catch block
        }
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.\u7ed9\u5230 = IAccountAuthenticator.Stub.asInterface((IBinder)iBinder);
        try {
            this.\u5bf9\u9f50();
            return;
        }
        catch (Exception exception) {
            this.onError(1, "remote exception");
            return;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        IAccountManagerResponse iAccountManagerResponse = this.\u540c\u6b65();
        if (iAccountManagerResponse != null) {
            try {
                iAccountManagerResponse.onError(1, "disconnected");
                return;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public final IAccountManagerResponse \u540c\u6b65() {
        IAccountManagerResponse iAccountManagerResponse = this.\u6c89\u6dc0;
        if (iAccountManagerResponse == null) {
            this.\u54cd\u5e94();
            return null;
        }
        this.\u54cd\u5e94();
        return iAccountManagerResponse;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void \u54cd\u5e94() {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u54cd\u5e94;
        int n = this.toString().hashCode();
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        boolean bl = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u6293\u624b(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        if (!bl) {
            return;
        }
        IAccountManagerResponse iAccountManagerResponse = this.\u6c89\u6dc0;
        if (iAccountManagerResponse != null) {
            iAccountManagerResponse.asBinder().unlinkToDeath((IBinder.DeathRecipient)this, 0);
            this.\u6c89\u6dc0 = null;
        }
        if (this.\u7ed9\u5230 == null) return;
        this.\u7ed9\u5230 = null;
        \u5408\u529b.\u6293\u624b.\u4e2d\u53f0((IBinder)this.\u5e73\u53f0);
    }

    public abstract void \u5bf9\u9f50();

    public final void \u5e73\u53f0() {
        String string = this.\u8d4b\u80fd;
        \u683c\u5c40.\u6293\u624b.getClass();
        \u9884\u8a00 \u9884\u8a002 = (\u9884\u8a00)((Object)\u683c\u5c40.\u4e2d\u53f0.\u6293\u624b.get((Object)string));
        if (\u9884\u8a002 != null) {
            Intent intent = new Intent("android.accounts.AccountAuthenticator");
            intent.setComponent(\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u9884\u8a002.\u8d4b\u80fd));
            if (\u5408\u529b.\u6293\u624b.\u6293\u624b(intent, (IBinder)this.\u5e73\u53f0, "0") != -1) {
                return;
            }
        }
        this.onError(1, "bind failure");
    }
}

