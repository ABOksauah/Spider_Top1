/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89c2\u5bdf$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u89c2\u5bdf
extends \u89e6\u8fbe {
    public static final String[] \u8d4b\u80fd(Object object, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u8d4b\u80fd((int[])object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        String[] arrstring;
        Object object2 = arrobject[0];
        if (!\u6c34\u4f4d.\u8d4b\u80fd || !(object2 instanceof int[]) || (arrstring = (String[])\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u89c2\u5bdf$$ExternalSyntheticLambda0(object2))) == null) return method.invoke(object, arrobject);
        try {
            int n = arrstring.length;
            if (n == 0) return method.invoke(object, arrobject);
            return arrstring;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

