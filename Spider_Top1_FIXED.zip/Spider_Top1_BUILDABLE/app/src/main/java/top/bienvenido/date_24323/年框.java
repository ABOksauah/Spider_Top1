/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityThread
 *  android.content.Context
 *  android.content.pm.IPackageManager
 *  android.content.pm.PackageManager
 *  android.content.pm.ParceledListSlice
 *  android.os.Handler
 *  android.permission.PermissionManager
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.List
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u4ea7\u4e1a
 *  top.bienvenido.date_24323.\u5751\u4f4d
 *  top.bienvenido.date_24323.\u5957\u8def
 *  top.bienvenido.date_24323.\u5c0f\u767d
 *  top.bienvenido.date_24323.\u5e55\u5e18
 *  top.bienvenido.date_24323.\u670d\u52a1
 *  top.bienvenido.date_24323.\u6807\u51c6
 *  top.bienvenido.date_24323.\u697c\u5c42
 *  top.bienvenido.date_24323.\u793e\u7fa4
 *  top.bienvenido.date_24323.\u7ec8\u7aef
 *  top.bienvenido.date_24323.\u8f7d\u4f53
 *  top.bienvenido.date_24323.\u906e\u7f69
 */
package top.bienvenido.date_24323;

import android.app.ActivityThread;
import android.content.Context;
import android.content.pm.IPackageManager;
import android.content.pm.PackageManager;
import android.content.pm.ParceledListSlice;
import android.os.Handler;
import android.permission.PermissionManager;
import java.util.Collections;
import java.util.List;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u4ea7\u4e1a;
import top.bienvenido.date_24323.\u4eba\u6027;
import top.bienvenido.date_24323.\u4ef7\u503c;
import top.bienvenido.date_24323.\u5171\u60c5;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u52a1\u5b9e;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u5730\u57df;
import top.bienvenido.date_24323.\u5751\u4f4d;
import top.bienvenido.date_24323.\u57cb\u70b9;
import top.bienvenido.date_24323.\u5957\u8def;
import top.bienvenido.date_24323.\u5c0f\u767d;
import top.bienvenido.date_24323.\u5e55\u5e18;
import top.bienvenido.date_24323.\u60c5\u6000;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u62c9\u65b0;
import top.bienvenido.date_24323.\u6307\u6807;
import top.bienvenido.date_24323.\u6355\u83b7;
import top.bienvenido.date_24323.\u670d\u52a1;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6807\u51c6;
import top.bienvenido.date_24323.\u697c\u5c42;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u73a9\u5bb6;
import top.bienvenido.date_24323.\u76c8\u5229;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u793e\u7fa4;
import top.bienvenido.date_24323.\u798f\u5229;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7ea2\u5305;
import top.bienvenido.date_24323.\u7ec8\u7aef;
import top.bienvenido.date_24323.\u8111\u6d1e;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89c4\u8303;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u8f7d\u4f53;
import top.bienvenido.date_24323.\u8fc1\u79fb;
import top.bienvenido.date_24323.\u906e\u7f69;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u98ce\u9669;

public final class \u5e74\u6846
extends \u96c6\u6210 {
    public static final \u5e74\u6846 \u6293\u624b = new \u5e74\u6846();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(\u5e74\u6846 \u5e74\u68462, Object[] arrobject) {
        \u5e74\u68462.getClass();
        try {
            Object object = arrobject[1];
            int n = object instanceof Number ? ((Number)object).intValue() : 0;
            if ((n & 4194304) == 0) return;
            {
                if (object instanceof Long) {
                    arrobject[1] = -4194305L & ((Number)object).longValue();
                    return;
                }
                if (!(object instanceof Integer)) return;
                {
                    arrobject[1] = -4194305 & ((Number)object).intValue();
                    return;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void \u8d4b\u80fd() {
        void var12_14;
        this.\u8d4b\u80fd = \u672c\u6211.\u6293\u624b;
        IPackageManager iPackageManager = ActivityThread.getPackageManager();
        if (iPackageManager == null) {
            return;
        }
        \u51fa\u51fb \u51fa\u51fb2 = this.\u8d4b\u80fd("package", (Object)iPackageManager);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "sPackageManager", \u51fa\u51fb2.\u95ed\u73af);
        \u8fc1\u79fb \u8fc1\u79fb2 = \u8fc1\u79fb.\u8d4b\u80fd;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(686218487, \u8fc1\u79fb2);
        \u5171\u60c5 \u5171\u60c52 = new \u5171\u60c5((Function2)\u5c0f\u767d.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(871155123, \u5171\u60c52);
        \u5171\u60c5 \u5171\u60c53 = new \u5171\u60c5((Function2)\u6807\u51c6.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1207111861, \u5171\u60c53);
        \u89c4\u8303 \u89c4\u83032 = new \u89c4\u8303();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1326102014, \u89c4\u83032);
        \u5171\u60c5 \u5171\u60c54 = new \u5171\u60c5((Function2)\u793e\u7fa4.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1039974701, \u5171\u60c54);
        \u5171\u60c5 \u5171\u60c55 = new \u5171\u60c5((Function2)\u4ea7\u4e1a.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1725989837, \u5171\u60c55);
        \u52a1\u5b9e \u52a1\u5b9e2 = new \u52a1\u5b9e((Function2)\u8f7d\u4f53.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1600494599, \u52a1\u5b9e2);
        \u52a1\u5b9e \u52a1\u5b9e3 = new \u52a1\u5b9e((Function2)\u670d\u52a1.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-150905391, \u52a1\u5b9e3);
        \u5730\u57df \u5730\u57df2 = new \u5730\u57df();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(268353758, \u5730\u57df2);
        \u6307\u6807 \u6307\u68072 = new \u6307\u6807();
        boolean bl = \u62bd\u8c61.\u5347\u7ea7;
        if (bl && \u62bd\u8c61.\u6c89\u6dc0 && !\u62bd\u8c61.\u8ddf\u8fdb) {
            \u76c8\u5229 \u76c8\u52292 = new \u76c8\u5229(\u6307\u68072);
        }
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1710913560, var12_14);
        \u7ec8\u7aef \u7ec8\u7aef2 = new \u7ec8\u7aef();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1550050946, (Object)\u7ec8\u7aef2);
        \u5e55\u5e18 \u5e55\u5e182 = new \u5e55\u5e18();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-432049674, (Object)\u5e55\u5e182);
        \u906e\u7f69 \u906e\u7f692 = new \u906e\u7f69();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-59811990, (Object)\u906e\u7f692);
        int[] arrn = new int[]{263663077, 653544665, 1321112681, -125888630, -1017315255, 1036223380, -2055791732, -2120318040, 1647146784, 1762051604, 689134333, 1556563560, 1543304065};
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        \u51fa\u51fb2.\u8d4b\u80fd(arrn, \u89e6\u53d12);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{1051878911, 1784040466}, \u672c\u6211.\u6f0f\u6597);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{125212131, -254077928, -1463700733}, \u672c\u6211.\u95ed\u73af);
        if (\u62bd\u8c61.\u8d4b\u80fd) {
            void var20_24;
            int[] arrn2 = new int[]{964371846, -1655019925};
            if (\u62bd\u8c61.\u4e2d\u53f0) {
                ParceledListSlice parceledListSlice = \u62c9\u65b0.\u8d4b\u80fd;
            } else {
                List list = Collections.EMPTY_LIST;
            }
            \u51fa\u51fb2.\u8d4b\u80fd(arrn2, new \u79c1\u57df(var20_24));
            if (\u62bd\u8c61.\u6f0f\u6597) {
                \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-2055791732, \u89e6\u53d12);
                if (bl) {
                    try {
                        \u6bb5\u4f4d.\u6293\u624b.getClass();
                        ActivityThread activityThread = \u6bb5\u4f4d.\u4e2d\u53f0;
                        Object object = new \u8d77\u98de((String)"mPreloadHandler").\u6293\u624b.\u8d4b\u80fd((Object)activityThread);
                        if (object instanceof Handler) {
                            ((Handler)object).sendEmptyMessage(0);
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                if (\u62bd\u8c61.\u7ed9\u5230) {
                    \u57cb\u70b9 \u57cb\u70b92 = new \u57cb\u70b9();
                    \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1354875218, \u57cb\u70b92);
                    try {
                        \u8111\u6d1e \u8111\u6d1e2 = new \u8111\u6d1e();
                        \u8111\u6d1e2.\u8d4b\u80fd(PackageManager.class, "sPackageInfoCache");
                        \u8111\u6d1e2.\u8d4b\u80fd(PackageManager.class, "sApplicationInfoCache");
                        \u8111\u6d1e2.\u8d4b\u80fd(PermissionManager.class, "sPackageNamePermissionCache");
                        \u8111\u6d1e2.\u8d4b\u80fd(PermissionManager.class, "sPermissionCache");
                        if (\u62bd\u8c61.\u5e73\u53f0) {
                            boolean bl2 = \u62bd\u8c61.\u5bf9\u6807;
                            if (bl2) {
                                \u8111\u6d1e2.\u8d4b\u80fd(PermissionManager.class, "sPermissionRequestStateCache");
                            }
                            Class class_ = \u98ce\u53e3.\u8d4b\u80fd.getPackageManager().getClass();
                            String string = bl2 ? "sGetPackagesForUidCache" : "mGetPackagesForUidCache";
                            \u8111\u6d1e2.\u8d4b\u80fd(class_, string);
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    if (\u62bd\u8c61.\u5e73\u53f0) {
                        \u5751\u4f4d \u5751\u4f4d2 = new \u5751\u4f4d();
                        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-945173823, (Object)\u5751\u4f4d2);
                        \u79c1\u57df \u79c1\u57df2 = \u672c\u6211.\u843d\u5730;
                        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-132294875, \u79c1\u57df2);
                        if (\u62bd\u8c61.\u54cd\u5e94) {
                            \u697c\u5c42 \u697c\u5c422 = new \u697c\u5c42();
                            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1854171575, (Object)\u697c\u5c422);
                        }
                    }
                }
            }
        }
        \u79c1\u57df \u79c1\u57df3 = \u672c\u6211.\u843d\u5730;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-548994423, \u79c1\u57df3);
        \u7ea2\u5305 \u7ea2\u53052 = new \u7ea2\u5305();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-109758974, \u7ea2\u53052);
        \u98ce\u9669 \u98ce\u96692 = new \u98ce\u9669();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-297395415, \u98ce\u96692);
        \u4ef7\u503c \u4ef7\u503c2 = new \u4ef7\u503c();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1374193809, \u4ef7\u503c2);
        \u4eba\u6027 \u4eba\u60272 = new \u4eba\u6027();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-564624472, \u4eba\u60272);
        \u73a9\u5bb6 \u73a9\u5bb62 = new \u73a9\u5bb6();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1786110784, \u73a9\u5bb62);
        \u798f\u5229 \u798f\u52292 = new \u798f\u5229();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1530208819, \u798f\u52292);
        \u5957\u8def \u5957\u8def2 = new \u5957\u8def();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1280559169, (Object)\u5957\u8def2);
        \u60c5\u6000 \u60c5\u60002 = new \u60c5\u6000();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1700882705, \u60c5\u60002);
        \u6355\u83b7.\u8d4b\u80fd.\u8d4b\u80fd(\u51fa\u51fb2);
    }
}

