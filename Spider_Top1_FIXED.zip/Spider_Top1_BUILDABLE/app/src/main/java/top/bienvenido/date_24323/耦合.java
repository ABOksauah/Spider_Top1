/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.bluetooth.BluetoothAdapter
 *  android.bluetooth.BluetoothManager
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package top.bienvenido.date_24323;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u590d\u7528;
import top.bienvenido.date_24323.\u5bb9\u707e;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e3\u8026;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u8026\u5408
extends \u96c6\u6210 {
    public static final \u8026\u5408 \u6293\u624b = new \u8026\u5408();

    @Override
    public final void \u8d4b\u80fd() {
        BluetoothManager bluetoothManager;
        \u89e6\u8fbe \u89e6\u8fbe2;
        this.\u8d4b\u80fd = \u89e6\u8fbe2 = \u672c\u6211.\u8d4b\u80fd(\u672c\u6211.\u4e2d\u53f0);
        boolean bl = \u62bd\u8c61.\u5bf9\u6807;
        Object object = bl ? ((bluetoothManager = (BluetoothManager)\u98ce\u53e3.\u8d4b\u80fd.getSystemService(BluetoothManager.class)) != null ? bluetoothManager.getAdapter() : null) : BluetoothAdapter.getDefaultAdapter();
        if (object == null) {
            return;
        }
        \u8d77\u98de \u8d77\u98de2 = new \u8d77\u98de("mManagerService");
        Object object2 = \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object);
        if (object2 == null) {
            return;
        }
        \u51fa\u51fb \u51fa\u51fb2 = this.\u8d4b\u80fd("bluetooth_manager", object2);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        if (bl) {
            \u771f\u9999.\u8d4b\u80fd(BluetoothAdapter.class, "sAdapter").\u8d4b\u80fd((Object)null, (Object)null);
        } else {
            Object object3 = \u51fa\u51fb2.\u95ed\u73af;
            \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object, object3);
        }
        \u515c\u5e95 \u515c\u5e952 = new \u515c\u5e95(0);
        \u5bb9\u707e \u5bb9\u707e2 = new \u5bb9\u707e(\u515c\u5e952, \u89e6\u8fbe2);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1296507092, \u5bb9\u707e2);
        \u89e3\u8026 \u89e3\u80262 = new \u89e3\u8026(\u515c\u5e952, \u89e6\u8fbe2);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(2097720179, \u89e3\u80262);
        \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df("02:00:00:00:00:00");
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-110831682, \u79c1\u57df2);
        if (\u62bd\u8c61.\u540c\u6b65) {
            try {
                \u590d\u7528.\u6293\u624b.\u8d4b\u80fd();
                return;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }
}

