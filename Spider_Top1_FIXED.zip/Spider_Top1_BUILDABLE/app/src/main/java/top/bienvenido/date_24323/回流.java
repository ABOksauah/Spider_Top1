/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Icon
 *  android.net.Uri
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  android.widget.RemoteViews
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.app.Notification;
import android.app.NotificationChannel;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.provider.Settings;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u5206\u53d1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u56de\u6d41 {
    public static final \u8d77\u98de \u4e2d\u53f0;
    public static final \u8d77\u98de \u6293\u624b;
    public static final \u8d77\u98de \u6f0f\u6597;
    public static final \u8d77\u98de \u843d\u5730;
    public static final \u8d77\u98de \u8d4b\u80fd;
    public static final \u8d77\u98de \u95ed\u73af;

    static {
        \u8d4b\u80fd = new \u8d77\u98de("mId");
        \u6293\u624b = new \u8d77\u98de("mType");
        \u4e2d\u53f0 = new \u8d77\u98de("mObj1");
        \u95ed\u73af = new \u8d77\u98de("mString1");
        \u843d\u5730 = new \u8d77\u98de("mInt1");
        \u6f0f\u6597 = new \u8d77\u98de("mChannelId");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u8d4b\u80fd(Notification notification, String string2) {
        try {
            if (\u62bd\u8c61.\u843d\u5730) {
                String string3 = notification.getChannelId();
                String string4 = string3 != null && string3.length() != 0 ? \u5206\u53d1.\u8d4b\u80fd(string2, string3) : \u5206\u53d1.\u8d4b\u80fd(string2, "default_channel");
                \u56de\u6d41.\u6f0f\u6597.\u6293\u624b.\u8d4b\u80fd((Object)notification, (Object)string4);
            }
            if (\u6c34\u4f4d.\u6f0f\u6597) {
                if (\u62bd\u8c61.\u6293\u624b) {
                    Icon icon;
                    Icon icon2 = notification.getSmallIcon();
                    if (icon2 != null) {
                        \u56de\u6d41.\u8d4b\u80fd((Object)icon2);
                    }
                    if ((icon = notification.getLargeIcon()) != null) {
                        \u56de\u6d41.\u8d4b\u80fd((Object)icon);
                    }
                }
                notification.tickerView = null;
                notification.contentView = null;
                notification.bigContentView = null;
                notification.headsUpContentView = null;
            }
            notification.icon = 17629184;
            notification.flags = -3 & notification.flags;
            if (notification.sound == null) return;
            notification.sound = Settings.System.DEFAULT_NOTIFICATION_URI;
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void \u8d4b\u80fd(NotificationChannel notificationChannel, String string2) {
        block6 : {
            if (!StringsKt.startsWith$default((String)notificationChannel.getId(), (String)\u5206\u53d1.\u8d4b\u80fd(string2), (boolean)false, (int)2, null)) break block6;
            \u8d77\u98de \u8d77\u98de2 = \u8d4b\u80fd;
            String string3 = notificationChannel.getId();
            try {
                String string4 = \u5206\u53d1.\u8d4b\u80fd(string2);
                if (StringsKt.startsWith$default((String)string3, (String)string4, (boolean)false, (int)2, null)) {
                    string3 = string3.substring(string4.length());
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)notificationChannel, (Object)string3);
                return;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public static void \u8d4b\u80fd(Object object) {
        try {
            \u8d77\u98de \u8d77\u98de2 = \u6293\u624b;
            Integer n = 2;
            \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object, (Object)n);
            \u8d77\u98de \u8d77\u98de3 = \u4e2d\u53f0;
            Resources resources = \u98ce\u53e3.\u8d4b\u80fd.getResources();
            \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd(object, (Object)resources);
            \u8d77\u98de \u8d77\u98de4 = \u95ed\u73af;
            String string2 = \u98ce\u53e3.\u6293\u624b;
            \u8d77\u98de4.\u6293\u624b.\u8d4b\u80fd(object, (Object)string2);
            \u8d77\u98de \u8d77\u98de5 = \u843d\u5730;
            Integer n2 = 17629184;
            \u8d77\u98de5.\u6293\u624b.\u8d4b\u80fd(object, (Object)n2);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static void \u8d4b\u80fd(List list, String string2) {
        new ArrayList();
        try {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                \u56de\u6d41.\u8d4b\u80fd((NotificationChannel)iterator.next(), string2);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

