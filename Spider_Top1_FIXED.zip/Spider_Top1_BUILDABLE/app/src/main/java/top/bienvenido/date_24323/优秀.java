/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ProviderInfo
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ProviderInfo;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u6bd4\u5fc3;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u4f18\u79c0
implements \u7b14\u82af {
    public final IBinder \u8d4b\u80fd;

    public \u4f18\u79c0(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final int \u4e2d\u53f0(Intent intent, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(3, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u4e2d\u53f0(IBinder iBinder) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoActivityManagerService");
                parcel.writeStrongBinder(iBinder);
                this.\u8d4b\u80fd.transact(6, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final void \u5e73\u53f0(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(18, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final int \u6293\u624b(Intent intent, IBinder iBinder, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(5, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final int \u6293\u624b(Intent intent, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(13, parcel, parcel2, 0);
            parcel2.readException();
            int n = parcel2.readInt();
            return n;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u6293\u624b(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(12, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final ArrayList \u6f0f\u6597(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(9, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ActivityManager.RunningAppProcessInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u6f0f\u6597(String string, String string2) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel2 = Parcel.obtain();
            parcel = Parcel.obtain();
            try {
                parcel2.writeInterfaceToken("MundoActivityManagerService");
                parcel2.writeString(string);
                parcel2.writeString(string2);
                this.\u8d4b\u80fd.transact(15, parcel2, parcel, 0);
                parcel.readException();
                int n = parcel.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel.recycle();
                parcel2.recycle();
                throw throwable;
            }
        }
        parcel.recycle();
        parcel2.recycle();
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ComponentName \u843d\u5730(Intent intent, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(2, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ComponentName.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ComponentName componentName = (ComponentName)object;
            return componentName;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final IBinder \u8d4b\u80fd(ComponentName componentName, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(8, parcel, parcel2, 0);
            parcel2.readException();
            IBinder iBinder = parcel2.readStrongBinder();
            return iBinder;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final IBinder \u8d4b\u80fd(String string, String string2, ProviderInfo[] arrproviderInfo, String[] arrstring, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            parcel.writeInt(arrproviderInfo.length);
            parcel.writeInt(arrstring.length);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(1, parcel, parcel2, 0);
            parcel2.readException();
            IBinder iBinder = parcel2.readStrongBinder();
            parcel2.readTypedArray((Object[])arrproviderInfo, ProviderInfo.CREATOR);
            parcel2.readStringArray(arrstring);
            return iBinder;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(int n, IBinder iBinder, IntentFilter intentFilter) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeInt(n);
            parcel.writeStrongBinder(iBinder);
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intentFilter, 0);
            this.\u8d4b\u80fd.transact(11, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string, String string2, String string3) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            parcel.writeString(string3);
            this.\u8d4b\u80fd.transact(19, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u8d4b\u80fd(ComponentName componentName, IBinder iBinder, int n) {
        Parcel parcel;
        Parcel parcel2;
        boolean bl;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoActivityManagerService");
                \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)componentName, 0);
                parcel.writeStrongBinder(iBinder);
                parcel.writeInt(n);
                this.\u8d4b\u80fd.transact(4, parcel, parcel2, 0);
                parcel2.readException();
                int n2 = parcel2.readInt();
                bl = false;
                if (n2 == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final boolean \u8d4b\u80fd(IBinder iBinder, Intent intent, IBinder iBinder2) {
        Parcel parcel;
        Parcel parcel2;
        boolean bl;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoActivityManagerService");
                parcel.writeStrongBinder(iBinder);
                \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
                parcel.writeStrongBinder(iBinder2);
                this.\u8d4b\u80fd.transact(7, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final IBinder \u95ed\u73af(Intent intent, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            \u6bd4\u5fc3.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(17, parcel, parcel2, 0);
            parcel2.readException();
            IBinder iBinder = parcel2.readStrongBinder();
            return iBinder;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u95ed\u73af() {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            this.\u8d4b\u80fd.transact(16, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u95ed\u73af(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(14, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final String[] \u95ed\u73af(int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoActivityManagerService");
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(10, parcel, parcel2, 0);
            parcel2.readException();
            String[] arrstring = parcel2.createStringArray();
            return arrstring;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }
}

