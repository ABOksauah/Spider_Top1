/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.view.WindowManager;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u4fbf\u6377\u6027
extends MutablePropertyReference1Impl {
    public static final \u4fbf\u6377\u6027 \u8d4b\u80fd = new \u4fbf\u6377\u6027();

    public \u4fbf\u6377\u6027() {
        super(WindowManager.LayoutParams.class, "packageName", "getPackageName()Ljava/lang/String;", 0);
    }

    public final Object get(Object object) {
        return ((WindowManager.LayoutParams)object).packageName;
    }

    public final void set(Object object, Object object2) {
        ((WindowManager.LayoutParams)object).packageName = (String)object2;
    }
}

