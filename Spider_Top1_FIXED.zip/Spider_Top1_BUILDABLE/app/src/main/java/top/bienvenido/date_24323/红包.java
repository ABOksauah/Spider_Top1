/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u6309\u94ae
 *  top.bienvenido.date_24323.\u63a8\u9001
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b;
import top.bienvenido.date_24323.\u6309\u94ae;
import top.bienvenido.date_24323.\u63a8\u9001;

public final class \u7ea2\u5305
extends \u62a2\u54c1\u7c7b {
    public final \u6309\u94ae \u6293\u624b = \u6309\u94ae.\u8d4b\u80fd;
    public final \u63a8\u9001 \u8d4b\u80fd = \u63a8\u9001.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

