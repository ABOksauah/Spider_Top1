/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.IBinder$FrozenStateChangeCallback
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.ResultReceiver
 *  android.os.ShellCallback
 *  java.io.FileDescriptor
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.concurrent.Executor
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ResultReceiver;
import android.os.ShellCallback;
import java.io.FileDescriptor;
import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u8e1d\u90e8
implements IBinder {
    public static final \u81ea\u6d3d \u4e2d\u53f0;
    public final IInterface \u6293\u624b;
    public final IBinder \u8d4b\u80fd;

    static {
        \u81ea\u6d3d \u81ea\u6d3d2;
        if (\u62bd\u8c61.\u7ed9\u5230) {
            Class[] arrclass = \u4e0b\u6c89.\u6293\u624b;
            try {
                Method method = IBinder.class.getDeclaredMethod("getExtension", arrclass);
                method.setAccessible(true);
                \u81ea\u6d3d2 = new \u76ae\u5b9e(method);
            }
            catch (Exception exception) {
                \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
            }
        } else {
            \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
        }
        \u4e2d\u53f0 = \u81ea\u6d3d2;
    }

    public \u8e1d\u90e8(IBinder iBinder, IInterface iInterface) {
        this.\u8d4b\u80fd = iBinder;
        this.\u6293\u624b = iInterface;
    }

    public final void addFrozenStateChangeCallback(Executor executor, IBinder.FrozenStateChangeCallback frozenStateChangeCallback) {
        this.\u8d4b\u80fd.addFrozenStateChangeCallback(executor, frozenStateChangeCallback);
    }

    public final void dump(FileDescriptor fileDescriptor, String[] arrstring) {
        this.\u8d4b\u80fd.dump(fileDescriptor, arrstring);
    }

    public final void dumpAsync(FileDescriptor fileDescriptor, String[] arrstring) {
        this.\u8d4b\u80fd.dumpAsync(fileDescriptor, arrstring);
    }

    public final IBinder getExtension() {
        return (IBinder)\u4e2d\u53f0.\u8d4b\u80fd((Object)this.\u8d4b\u80fd, new Object[0]);
    }

    public final String getInterfaceDescriptor() {
        return this.\u8d4b\u80fd.getInterfaceDescriptor();
    }

    public final boolean isBinderAlive() {
        return this.\u8d4b\u80fd.isBinderAlive();
    }

    public final void linkToDeath(IBinder.DeathRecipient deathRecipient, int n) {
        this.\u8d4b\u80fd.linkToDeath(deathRecipient, n);
    }

    public final boolean pingBinder() {
        return this.\u8d4b\u80fd.pingBinder();
    }

    public final IInterface queryLocalInterface(String string2) {
        return this.\u6293\u624b;
    }

    public final boolean removeFrozenStateChangeCallback(IBinder.FrozenStateChangeCallback frozenStateChangeCallback) {
        return this.\u8d4b\u80fd.removeFrozenStateChangeCallback(frozenStateChangeCallback);
    }

    public final void shellCommand(FileDescriptor fileDescriptor, FileDescriptor fileDescriptor2, FileDescriptor fileDescriptor3, String[] arrstring, ShellCallback shellCallback, ResultReceiver resultReceiver) {
    }

    public final boolean transact(int n, Parcel parcel, Parcel parcel2, int n2) {
        return this.\u8d4b\u80fd.transact(n, parcel, parcel2, n2);
    }

    public final boolean unlinkToDeath(IBinder.DeathRecipient deathRecipient, int n) {
        return this.\u8d4b\u80fd.unlinkToDeath(deathRecipient, n);
    }
}

