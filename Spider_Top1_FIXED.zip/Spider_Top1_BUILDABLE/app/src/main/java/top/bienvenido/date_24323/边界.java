/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$ComponentEnabledSetting
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.os.ConditionVariable
 *  android.os.Parcel
 *  android.os.Parcelable
 *  java.io.File
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.lang.reflect.Constructor
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Future
 *  kotlin.collections.CollectionsKt
 *  kotlin.io.FilesKt
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.functions.Function4
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u53d8\u91cf
 *  top.bienvenido.date_24323.\u573a\u57df
 *  top.bienvenido.date_24323.\u58c1\u5792
 *  top.bienvenido.date_24323.\u6001\u52bf
 *  top.bienvenido.date_24323.\u671f\u6743
 *  top.bienvenido.date_24323.\u67b6\u6784
 *  top.bienvenido.date_24323.\u6807\u6746
 *  top.bienvenido.date_24323.\u6807\u914d
 *  top.bienvenido.date_24323.\u7cfb\u7edf
 *  top.bienvenido.date_24323.\u951a\u70b9
 *  top.bienvenido.date_24323.\u957f\u5c3e
 *  top.bienvenido.date_24323.\u9608\u503c
 */
package top.bienvenido.date_24323;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Parcel;
import android.os.Parcelable;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import kotlin.collections.CollectionsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u5206\u53d1;
import top.bienvenido.date_24323.\u53d8\u91cf;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u573a\u57df;
import top.bienvenido.date_24323.\u58c1\u5792;
import top.bienvenido.date_24323.\u5916\u5305;
import top.bienvenido.date_24323.\u5934\u90e8;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6001\u52bf;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6388\u6743;
import top.bienvenido.date_24323.\u64cd\u76d8;
import top.bienvenido.date_24323.\u671f\u6743;
import top.bienvenido.date_24323.\u67b6\u6784;
import top.bienvenido.date_24323.\u6807\u6746;
import top.bienvenido.date_24323.\u6807\u914d;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u6d41\u5931;
import top.bienvenido.date_24323.\u6df1\u5165;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u798f\u62a5;
import top.bienvenido.date_24323.\u7cfb\u7edf;
import top.bienvenido.date_24323.\u81ea\u6211;
import top.bienvenido.date_24323.\u89e6\u53ca;
import top.bienvenido.date_24323.\u8f6c\u5316;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda10;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda13;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda14;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda4;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda5;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda6;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda7;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda8;
import top.bienvenido.date_24323.\u8fb9\u754c$$ExternalSyntheticLambda9;
import top.bienvenido.date_24323.\u8fd4\u4f63;
import top.bienvenido.date_24323.\u8fdb\u5316;
import top.bienvenido.date_24323.\u951a\u70b9;
import top.bienvenido.date_24323.\u957f\u5c3e;
import top.bienvenido.date_24323.\u9608\u503c;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u9ad8\u5730;
import top.bienvenido.mundo.common.initialize.MNative;

public final class \u8fb9\u754c
extends \u6388\u6743 {
    public static final \u515c\u5e95 \u4e2d\u53f0;
    public static final \u8fb9\u754c \u6293\u624b;
    public static final \u6241\u5e73\u5316 \u6f0f\u6597;
    public static final ConditionVariable \u843d\u5730;
    public static final \u515c\u5e95 \u95ed\u73af;

    static {
        \u6293\u624b = new \u8fb9\u754c();
        \u4e2d\u53f0 = new \u515c\u5e95(0);
        \u95ed\u73af = new \u515c\u5e95(0);
        \u843d\u5730 = new ConditionVariable();
        new Thread((Runnable)new \u8fb9\u754c$$ExternalSyntheticLambda1()).start();
        \u6f0f\u6597 = new \u6241\u5e73\u5316(0);
    }

    public static final void \u4ea4\u4ed8(String string) {
        block5 : {
            String string2;
            NotificationManager notificationManager;
            \u6293\u624b.getClass();
            try {
                if (!\u62bd\u8c61.\u843d\u5730) break block5;
                notificationManager = (NotificationManager)\u98ce\u53e3.\u8d4b\u80fd.getSystemService(NotificationManager.class);
                String string3 = \u5206\u53d1.\u8d4b\u80fd(string);
                Iterator iterator = notificationManager.getNotificationChannels().iterator();
                while (iterator.hasNext()) {
                    string2 = ((NotificationChannel)iterator.next()).getId();
                    boolean bl = StringsKt.startsWith$default((String)string2, (String)string3, (boolean)false, (int)2, null);
                    if (!bl) continue;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            {
                try {
                    notificationManager.deleteNotificationChannel(string2);
                }
                catch (Exception exception) {}
                continue;
                break;
            }
        }
        \u8f6c\u5316.\u4e2d\u53f0(new File(\u81ea\u6211.\u8d4b\u80fd, string));
    }

    public static void \u5012\u903c(String string) {
        \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.remove(string);
        \u8fb9\u754c$$ExternalSyntheticLambda0 \u8fb9\u754c$$ExternalSyntheticLambda0 = new \u8fb9\u754c$$ExternalSyntheticLambda0(string, \u64cd\u76d82);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda0);
    }

    public static void \u5347\u7ea7(String string) {
        try {
            \u8fb9\u754c.\u5012\u903c(string);
            \u8fb9\u754c$$ExternalSyntheticLambda9 \u8fb9\u754c$$ExternalSyntheticLambda9 = new \u8fb9\u754c$$ExternalSyntheticLambda9(string);
            ExecutorService executorService = \u964d\u7ea7.\u6293\u624b;
            executorService.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda9);
            executorService.execute((Runnable)new \u8fb9\u754c$$ExternalSyntheticLambda10(string));
            (\u5934\u90e8)\u95ed\u73af.remove(string);
            \u683c\u5c40.\u6293\u624b.getClass();
            \u683c\u5c40.\u5e73\u53f0();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u540c\u6b65() {
        ArrayList arrayList;
        int n;
        block16 : {
            int n2;
            File[] arrfile;
            arrayList = new ArrayList();
            n = 0;
            try {
                arrfile = \u89e6\u53ca.\u6293\u624b.listFiles();
                if (arrfile == null) break block16;
                n2 = arrfile.length;
            }
            catch (Exception exception) {
                // empty catch block
                break block16;
            }
            for (int i = 0; i < n2; ++i) {
                File file = arrfile[i];
                if (!file.isDirectory()) continue;
                File file2 = new File(file, "installation.bin");
                if (file2.exists()) {
                    arrayList.add((Object)file2);
                    continue;
                }
                \u8f6c\u5316.\u4e2d\u53f0(file);
            }
        }
        ArrayList arrayList2 = new ArrayList(arrayList.size());
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            byte[] arrby = FilesKt.readBytes((File)((File)iterator.next()));
            Parcel parcel = Parcel.obtain();
            try {
                ApplicationInfo applicationInfo;
                parcel.unmarshall(arrby, 0, arrby.length);
                parcel.setDataPosition(0);
                PackageInfo packageInfo = (PackageInfo)parcel.readParcelable(PackageInfo.class.getClassLoader());
                if (packageInfo == null) {
                    packageInfo = new PackageInfo();
                }
                if ((applicationInfo = packageInfo.applicationInfo) == null) {
                    applicationInfo = new ApplicationInfo();
                }
                \u64cd\u76d8 \u64cd\u76d82 = new \u64cd\u76d8(packageInfo, applicationInfo);
                \u8fb9\u754c$$ExternalSyntheticLambda3 \u8fb9\u754c$$ExternalSyntheticLambda3 = new \u8fb9\u754c$$ExternalSyntheticLambda3(\u64cd\u76d82);
                arrayList2.add((Object)\u964d\u7ea7.\u6293\u624b.submit((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda3));
                \u4e2d\u53f0.put(\u64cd\u76d82.\u8d4b\u80fd, \u64cd\u76d82);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            parcel.recycle();
        }
        \u8fb9\u754c.\u5bf9\u9f50();
        if (\u9ad8\u5730.\u6f0f\u6597 == 0) {
            for (int i = 1; i < 25; ++i) {
                try {
                    \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u9ad8\u5730.\u6293\u624b.\u8d4b\u80fd;
                    int n3 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, i);
                    if (n3 >= 0) {
                        continue;
                    }
                    n = i;
                    break;
                }
                catch (Exception exception) {
                    // empty catch block
                    break;
                }
            }
            \u9ad8\u5730.\u8d4b\u80fd(n);
            \u9ad8\u5730.\u6f0f\u6597 = n;
        }
        Iterator iterator2 = arrayList2.iterator();
        do {
            if (!iterator2.hasNext()) {
                \u683c\u5c40.\u6293\u624b.getClass();
                \u683c\u5c40.\u5e73\u53f0();
                return;
            }
            ((Future)iterator2.next()).get();
        } while (true);
    }

    public static void \u540c\u6b65(String string, String string2) {
        \u8fb9\u754c$$ExternalSyntheticLambda8 \u8fb9\u754c$$ExternalSyntheticLambda8 = new \u8fb9\u754c$$ExternalSyntheticLambda8(string, string2);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda8);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u54cd\u5e94() {
        ConditionVariable conditionVariable;
        try {
            conditionVariable = \u843d\u5730;
            conditionVariable.close();
            \u4e2d\u53f0.clear();
            \u95ed\u73af.clear();
            \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u6f0f\u6597;
            \u6241\u5e73\u53162.\u4e2d\u53f0 = 0;
            \u6241\u5e73\u53162.\u8d4b\u80fd = \u4e0b\u6c89.\u8d4b\u80fd;
            \u6241\u5e73\u53162.\u6293\u624b = \u4e0b\u6c89.\u4e2d\u53f0;
            \u6293\u624b.getClass();
            \u8fb9\u754c.\u540c\u6b65();
        }
        catch (Throwable throwable) {
            conditionVariable = \u843d\u5730;
        }
        conditionVariable.open();
    }

    public static final File \u590d\u76d8(String string) {
        Class class_;
        try {
            class_ = (Class)MNative.\u8d4b\u80fd(61185, (Serializable)"f221ad5694a99ff2cfd2518512661c60");
        }
        catch (Throwable throwable) {
            class_ = null;
        }
        if (class_ != null) {
            File file = (File)class_.getConstructor(new Class[]{string.getClass()}).newInstance(new Object[]{string});
            if (file != null) {
                return file;
            }
        }
        throw new UnsupportedOperationException();
    }

    public static final void \u5bf9\u6807(String string, String string2) {
        try {
            \u5408\u529b.\u6293\u624b.\u95ed\u73af(string, string2);
            \u798f\u62a5.\u8d4b\u80fd(string, string2);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void \u5bf9\u9f50() {
        block13 : {
            block12 : {
                block11 : {
                    try {
                        var2 = new ArrayList();
                        var3_1 = \u798f\u62a5.\u8d4b\u80fd.listFiles();
                        if (var3_1 != null) {
                            for (File var6_4 : var3_1) {
                                if (!var6_4.isDirectory()) continue;
                                var2.add((Object)var6_4);
                            }
                        }
                        var8_5 = var2.iterator();
lbl10: // 3 sources:
                        do {
                            if (var8_5.hasNext() == false) return;
                            var9_6 = (File)var8_5.next();
                            var10_7 = var9_6.getName();
                            var11_8 = (\u64cd\u76d8)\u8fb9\u754c.\u4e2d\u53f0.get(var10_7);
                            if (var11_8 == null) {
                                if (\u98ce\u53e3.\u8d4b\u80fd(new \u8fb9\u754c$$ExternalSyntheticLambda13(var10_7)) == null) {
                                    var21_14 = new \u8fb9\u754c$$ExternalSyntheticLambda14(var10_7);
                                    \u964d\u7ea7.\u6293\u624b.execute((Runnable)var21_14);
                                    continue;
                                }
                                var13_9 = \u8fb9\u754c.\u95ed\u73af;
                                var14_10 = var9_6.listFiles();
                                if (var14_10 != null) {
                                    var15_11 = new \u5dee\u5f02\u5316(var14_10.length);
                                    var16_12 = var14_10.length;
                                    break block11;
                                }
                                var15_11 = new \u5dee\u5f02\u5316("0");
                                break block12;
                            }
                            var22_15 = var9_6.listFiles();
                            if (var22_15 == null) continue;
                            var23_16 = var11_8.\u6293\u624b;
                            var24_17 = var22_15.length;
                            var25_18 = 0;
                            break block13;
                            break;
                        } while (true);
                    }
                    catch (Exception var0_19) {
                        // empty catch block
                    }
                    return;
                }
                for (var17_13 = 0; var17_13 < var16_12; ++var17_13) {
                    var15_11.add(var14_10[var17_13].getName());
                }
            }
            var13_9.put(var10_7, new \u5934\u90e8(var10_7, var15_11));
            ** GOTO lbl10
        }
        do {
            if (var25_18 < var24_17) ** break;
            ** continue;
            var23_16.add(var22_15[var25_18].getName());
            ++var25_18;
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u5bf9\u9f50(String string, String string2) {
        try {
            void var4_4;
            \u6293\u624b.getClass();
            \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
            if (\u64cd\u76d82 == null) {
                \u5934\u90e8 \u5934\u90e82 = (\u5934\u90e8)\u95ed\u73af.get(string);
            }
            if (var4_4 != null) {
                var4_4.\u6293\u624b.remove(string2);
            }
            \u8fb9\u754c$$ExternalSyntheticLambda5 \u8fb9\u754c$$ExternalSyntheticLambda5 = new \u8fb9\u754c$$ExternalSyntheticLambda5(string, string2);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda5);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u5e73\u53f0() {
        try {
            \u81ea\u6211.\u8d4b\u80fd();
            \u6293\u624b.getClass();
            \u8fb9\u754c.\u540c\u6b65();
        }
        catch (Throwable throwable) {}
        \u843d\u5730.open();
    }

    /*
     * Exception decompiling
     */
    public static void \u6293\u624b(PackageInfo var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 7[WHILELOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    public static final void \u6293\u624b(List list) {
        for (PackageManager.ComponentEnabledSetting componentEnabledSetting : list) {
            \u64cd\u76d8 \u64cd\u76d82;
            ComponentName componentName = componentEnabledSetting.getComponentName();
            if (componentName == null || (\u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(componentName.getPackageName())) == null) continue;
            int n = componentEnabledSetting.getEnabledState();
            \u64cd\u76d82.\u6c89\u6dc0.\u8d4b\u80fd(componentName.getClassName(), n);
            \u64cd\u76d82.\u6c89\u6dc0.\u6293\u624b();
        }
    }

    public static final void \u68b3\u7406(String string) {
        if (!\u6293\u624b.\u6293\u624b(string)) {
            \u8fb9\u754c.\u5347\u7ea7(string);
        }
    }

    public static ComponentInfo \u6f0f\u6597(ComponentName componentName) {
        block3 : {
            \u64cd\u76d8 \u64cd\u76d82;
            try {
                \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(componentName.getPackageName());
                if (\u64cd\u76d82 == null) break block3;
            }
            catch (Exception exception) {
                return null;
            }
            \u8fd4\u4f63 \u8fd4\u4f632 = \u64cd\u76d82.\u6f0f\u6597;
            String string = componentName.getClassName();
            ComponentInfo componentInfo = (ComponentInfo)\u8fd4\u4f632.\u8d4b\u80fd.\u8d4b\u80fd(string.hashCode());
            return componentInfo;
        }
        return null;
    }

    public static final void \u805a\u7126(String string) {
        try {
            \u798f\u62a5.\u8d4b\u80fd(string, null);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final PackageInfo \u8d4b\u80fd(String string, PackageManager packageManager) {
        return packageManager.getPackageInfo(string, 512);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static List \u8d4b\u80fd(Intent intent, String string, int n, Function2 function2, Function4 function4) {
        ArrayList arrayList = new ArrayList();
        try {
            Object object = intent.getComponent();
            if (object == null) {
                Intent intent2 = intent.getSelector();
                object = intent2 != null ? intent2.getComponent() : null;
            }
            if (object != null) {
                \u6293\u624b.getClass();
                ComponentInfo componentInfo = \u8fb9\u754c.\u6f0f\u6597(object);
                if (componentInfo == null) return arrayList;
                {
                    ResolveInfo resolveInfo = new ResolveInfo();
                    function2.invoke((Object)resolveInfo, (Object)componentInfo);
                    arrayList.add((Object)resolveInfo);
                    return arrayList;
                }
            } else {
                String string2 = intent.getPackage();
                if (string2 != null) {
                    \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string2);
                    if (\u64cd\u76d82 != null) return (List)function4.invoke((Object)\u64cd\u76d82.\u843d\u5730, (Object)intent, (Object)string, (Object)n);
                    return arrayList;
                }
                Iterator iterator = \u4e2d\u53f0.values().iterator();
                while (iterator.hasNext()) {
                    arrayList.addAll((Collection)function4.invoke((Object)((\u64cd\u76d8)iterator.next()).\u843d\u5730, (Object)intent, (Object)string, (Object)n));
                }
            }
            return arrayList;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrayList;
    }

    /*
     * Exception decompiling
     */
    public static void \u8d4b\u80fd(PackageInfo var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 7[WHILELOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u8d4b\u80fd(String string, \u64cd\u76d8 \u64cd\u76d82) {
        \u8f6c\u5316.\u4e2d\u53f0(new File(\u89e6\u53ca.\u6293\u624b, string));
        if (\u64cd\u76d82 == null) return;
        try {
            \u8fb9\u754c \u8fb9\u754c2 = \u6293\u624b;
            PackageInfo packageInfo = \u64cd\u76d82.\u4e2d\u53f0;
            \u8fb9\u754c2.getClass();
            \u8fb9\u754c.\u6293\u624b(packageInfo);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static final void \u8d4b\u80fd(\u64cd\u76d8 \u64cd\u76d82) {
        try {
            \u8fdb\u5316.\u8d4b\u80fd(\u64cd\u76d82, 0);
            \u8fb9\u754c \u8fb9\u754c2 = \u6293\u624b;
            PackageInfo packageInfo = \u64cd\u76d82.\u4e2d\u53f0;
            \u8fb9\u754c2.getClass();
            \u8fb9\u754c.\u8d4b\u80fd(packageInfo);
            \u64cd\u76d82.\u6c89\u6dc0.\u8d4b\u80fd();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static final void \u8d4b\u80fd(\u64cd\u76d8 \u64cd\u76d82, ComponentName componentName, int n) {
        \u64cd\u76d82.\u6c89\u6dc0.\u8d4b\u80fd(componentName.getClassName(), n);
        \u64cd\u76d82.\u6c89\u6dc0.\u6293\u624b();
    }

    public static final void \u8d4b\u80fd(\u64cd\u76d8 \u64cd\u76d82, \u64cd\u76d8 \u64cd\u76d83) {
        int n = \u64cd\u76d83 != null ? 2 : 1;
        try {
            \u8fdb\u5316.\u8d4b\u80fd(\u64cd\u76d82, n);
            \u8fb9\u754c \u8fb9\u754c2 = \u6293\u624b;
            PackageInfo packageInfo = \u64cd\u76d82.\u4e2d\u53f0;
            \u8fb9\u754c2.getClass();
            \u8fb9\u754c.\u8d4b\u80fd(packageInfo);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8fed\u4ee3(String string, String string2) {
        try {
            void var4_4;
            \u6293\u624b.getClass();
            \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
            if (\u64cd\u76d82 == null) {
                \u5934\u90e8 \u5934\u90e82 = (\u5934\u90e8)\u95ed\u73af.get(string);
            }
            if (var4_4 != null) {
                var4_4.\u6293\u624b.add(string2);
            } else {
                \u95ed\u73af.put(string, new \u5934\u90e8(string, new \u5dee\u5f02\u5316(string2)));
                \u683c\u5c40.\u6293\u624b.getClass();
                \u683c\u5c40.\u5e73\u53f0();
            }
            File file = \u6253\u78e8.\u8d4b\u80fd(\u798f\u62a5.\u8d4b\u80fd, string, string2);
            if (!file.mkdirs()) return;
            \u8f6c\u5316.\u8d4b\u80fd(file);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public final PackageInfo \u4e2d\u53f0(String string, int n) {
        block4 : {
            \u64cd\u76d8 \u64cd\u76d82;
            try {
                \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
                if (\u64cd\u76d82 == null) break block4;
            }
            catch (Exception exception) {
                return null;
            }
            PackageInfo packageInfo = \u64cd\u76d82.\u4e2d\u53f0;
            if (packageInfo == null) break block4;
            PackageInfo packageInfo2 = \u8fdb\u5316.\u8d4b\u80fd.\u8d4b\u80fd(packageInfo, n);
            return packageInfo2;
        }
        return null;
    }

    @Override
    public final ProviderInfo \u4e2d\u53f0(ComponentName componentName) {
        return (ProviderInfo)\u8fb9\u754c.\u6f0f\u6597(componentName);
    }

    @Override
    public final ArrayList \u4e2d\u53f0(int n) {
        \u515c\u5e95 \u515c\u5e952 = \u4e2d\u53f0;
        ArrayList arrayList = new ArrayList(\u515c\u5e952.\u4e2d\u53f0);
        try {
            for (\u64cd\u76d8 \u64cd\u76d82 : \u515c\u5e952.values()) {
                arrayList.add((Object)\u8fdb\u5316.\u8d4b\u80fd.\u8d4b\u80fd(\u64cd\u76d82.\u4e2d\u53f0, n));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrayList;
    }

    @Override
    public final List \u4e2d\u53f0(Intent intent, String string, int n) {
        return \u8fb9\u754c.\u8d4b\u80fd(intent, string, n, (Function2)new \u9608\u503c((Object)\u573a\u57df.\u8d4b\u80fd), (Function4)\u67b6\u6784.\u8d4b\u80fd);
    }

    @Override
    public final void \u4e2d\u53f0(String string, String string2) {
        if (string2 != null && string2.length() != 0) {
            \u8fb9\u754c.\u540c\u6b65(string, string2);
            return;
        }
        \u8fb9\u754c.\u5347\u7ea7(string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final int \u4f18\u5316(String string) {
        \u64cd\u76d8 \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
        if (\u64cd\u76d82 == null) return -1;
        try {
            return \u64cd\u76d82.\u95ed\u73af.uid;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    @Override
    public final void \u540c\u6b65(String string) {
        if (string == null) {
            return;
        }
        try {
            File file = new File(string);
            file.mkdirs();
            \u81ea\u6211.\u8d4b\u80fd = file;
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public final boolean \u5bf9\u6807(String string) {
        return \u4e2d\u53f0.containsKey(string) || \u95ed\u73af.containsKey(string);
        {
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ArrayList \u5e73\u53f0(String string, String string2) {
        try {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = \u4e2d\u53f0.values().iterator();
            while (iterator.hasNext()) {
                ProviderInfo[] arrproviderInfo = ((\u64cd\u76d8)iterator.next()).\u4e2d\u53f0.providers;
                if (arrproviderInfo == null) continue;
                for (ProviderInfo providerInfo : arrproviderInfo) {
                    Bundle bundle;
                    if (providerInfo.authority == null || string != null && !Intrinsics.areEqual((Object)string, (Object)providerInfo.processName) || string2 != null && string2.length() != 0 && ((bundle = providerInfo.metaData) == null || !bundle.containsKey(string2))) continue;
                    arrayList.add((Object)providerInfo);
                }
            }
            return arrayList;
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public final ActivityInfo \u6293\u624b(ComponentName componentName) {
        return (ActivityInfo)\u8fb9\u754c.\u6f0f\u6597(componentName);
    }

    @Override
    public final ApplicationInfo \u6293\u624b(String string, int n) {
        block3 : {
            \u64cd\u76d8 \u64cd\u76d82;
            try {
                \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
                if (\u64cd\u76d82 == null) break block3;
            }
            catch (Exception exception) {
                return null;
            }
            ApplicationInfo applicationInfo = \u64cd\u76d82.\u95ed\u73af;
            return applicationInfo;
        }
        return null;
    }

    @Override
    public final ArrayList \u6293\u624b() {
        \u515c\u5e95 \u515c\u5e952 = \u4e2d\u53f0;
        int n = \u515c\u5e952.\u4e2d\u53f0;
        \u515c\u5e95 \u515c\u5e953 = \u95ed\u73af;
        ArrayList arrayList = new ArrayList(n + \u515c\u5e953.\u4e2d\u53f0);
        try {
            arrayList.addAll((Collection)\u515c\u5e952.keySet());
            arrayList.addAll((Collection)\u515c\u5e953.keySet());
            return arrayList;
        }
        catch (Exception exception) {
            return arrayList;
        }
    }

    @Override
    public final List \u6293\u624b(Intent intent, String string, int n) {
        return \u8fb9\u754c.\u8d4b\u80fd(intent, string, n, (Function2)new \u58c1\u5792((Object)\u53d8\u91cf.\u8d4b\u80fd), (Function4)\u671f\u6743.\u8d4b\u80fd);
    }

    @Override
    public final void \u6293\u624b(int n) {
        if (n == 0) {
            \u5916\u5305.\u8d4b\u80fd();
            return;
        }
        \u5916\u5305.\u8d4b\u80fd = new \u6241\u5e73\u5316(0);
    }

    @Override
    public final boolean \u6293\u624b(String string) {
        block5 : {
            File file;
            block6 : {
                if (string == null) {
                    new Thread((Runnable)new \u8fb9\u754c$$ExternalSyntheticLambda7()).start();
                    return true;
                }
                if (!new File(\u89e6\u53ca.\u6293\u624b, string).exists()) break block5;
                file = \u89e6\u53ca.\u8d4b\u80fd(string);
                if (this.\u8d4b\u80fd(file.getAbsolutePath(), 4) >= 0) break block6;
                return false;
            }
            try {
                \u8f6c\u5316.\u4e2d\u53f0(file);
                return true;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return false;
    }

    @Override
    public final void \u6c89\u6dc0() {
        \u843d\u5730.block(10000L);
    }

    @Override
    public final String[] \u6c89\u6dc0(int n) {
        ArrayList arrayList = new ArrayList();
        try {
            for (Map.Entry entry : \u4e2d\u53f0.entrySet()) {
                if (((\u64cd\u76d8)entry.getValue()).\u95ed\u73af.uid != n) continue;
                arrayList.add(entry.getKey());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return (String[])arrayList.toArray((Object[])\u4e0b\u6c89.\u95ed\u73af);
    }

    @Override
    public final String[] \u6c89\u6dc0(String string) {
        \u5934\u90e8 \u5934\u90e82;
        block6 : {
            \u5934\u90e82 = (\u64cd\u76d8)\u4e2d\u53f0.get(string);
            if (\u5934\u90e82 != null) break block6;
            try {
                \u5934\u90e82 = (\u5934\u90e8)\u95ed\u73af.get(string);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (\u5934\u90e82 != null) {
            if (!\u5934\u90e82.\u6293\u624b.isEmpty()) {
                String[] arrstring = (String[])\u5934\u90e82.\u6293\u624b.toArray((Object[])\u4e0b\u6c89.\u95ed\u73af);
                return arrstring;
            }
        }
        return new String[]{"0"};
    }

    @Override
    public final int \u6f0f\u6597(String string) {
        if (string != null) {
            try {
                for (\u64cd\u76d8 \u64cd\u76d82 : \u4e2d\u53f0.values()) {
                    if (!Intrinsics.areEqual((Object)string, (Object)\u64cd\u76d82.\u4e2d\u53f0.sharedUserId)) continue;
                    int n = \u64cd\u76d82.\u95ed\u73af.uid;
                    return n;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        return -1;
    }

    @Override
    public final List \u6f0f\u6597(Intent intent, String string, int n) {
        return \u8fb9\u754c.\u8d4b\u80fd(intent, string, n, (Function2)new \u7cfb\u7edf((Object)\u6807\u914d.\u8d4b\u80fd), (Function4)\u957f\u5c3e.\u8d4b\u80fd);
    }

    @Override
    public final ProviderInfo \u7ed9\u5230(String string) {
        try {
            ProviderInfo providerInfo = (ProviderInfo)\u6f0f\u6597.\u8d4b\u80fd(string.hashCode());
            return providerInfo;
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public final void \u7ed9\u5230(String string, String string2) {
        \u8fb9\u754c$$ExternalSyntheticLambda2 \u8fb9\u754c$$ExternalSyntheticLambda2 = new \u8fb9\u754c$$ExternalSyntheticLambda2(string, string2);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda2);
    }

    @Override
    public final ResolveInfo \u843d\u5730(Intent intent, String string, int n) {
        return (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(this.\u4e2d\u53f0(intent, string, n)));
    }

    @Override
    public final ServiceInfo \u843d\u5730(ComponentName componentName) {
        return (ServiceInfo)\u8fb9\u754c.\u6f0f\u6597(componentName);
    }

    @Override
    public final ArrayList \u843d\u5730(int n) {
        \u515c\u5e95 \u515c\u5e952 = \u4e2d\u53f0;
        ArrayList arrayList = new ArrayList(\u515c\u5e952.\u4e2d\u53f0);
        try {
            Iterator iterator = \u515c\u5e952.values().iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)((\u64cd\u76d8)iterator.next()).\u95ed\u73af);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final boolean \u843d\u5730(String string) {
        int n;
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        try {
            \u6241\u5e73\u53162 = \u5916\u5305.\u8d4b\u80fd;
            n = string != null ? string.hashCode() : 0;
        }
        catch (Exception exception) {
            return false;
        }
        int n2 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n);
        return n2 >= 0;
    }

    @Override
    public final int \u8d4b\u80fd(ComponentName componentName) {
        \u64cd\u76d8 \u64cd\u76d82;
        block3 : {
            try {
                \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(componentName.getPackageName());
                if (\u64cd\u76d82 != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                return 0;
            }
        }
        int n = \u64cd\u76d82.\u6c89\u6dc0.\u8d4b\u80fd(componentName.getClassName());
        return n;
    }

    /*
     * Exception decompiling
     */
    @Override
    public final int \u8d4b\u80fd(String var1_1, int var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[CASE]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final String \u8d4b\u80fd(int n) {
        try {
            for (Map.Entry entry : \u4e2d\u53f0.entrySet()) {
                if (((\u64cd\u76d8)entry.getValue()).\u95ed\u73af.uid != n) continue;
                String string = (String)entry.getKey();
                return string;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    @Override
    public final List \u8d4b\u80fd(Intent intent, String string, int n) {
        return \u8fb9\u754c.\u8d4b\u80fd(intent, string, n, (Function2)new \u6001\u52bf((Object)\u951a\u70b9.\u8d4b\u80fd), (Function4)\u6807\u6746.\u8d4b\u80fd);
    }

    @Override
    public final void \u8d4b\u80fd(ComponentName componentName, int n) {
        \u64cd\u76d8 \u64cd\u76d82;
        block3 : {
            try {
                \u64cd\u76d82 = (\u64cd\u76d8)\u4e2d\u53f0.get(componentName.getPackageName());
                if (\u64cd\u76d82 != null) break block3;
                return;
            }
            catch (Exception exception) {
                return;
            }
        }
        \u8fb9\u754c$$ExternalSyntheticLambda6 \u8fb9\u754c$$ExternalSyntheticLambda6 = new \u8fb9\u754c$$ExternalSyntheticLambda6(\u64cd\u76d82, componentName, n);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda6);
    }

    @Override
    public final void \u8d4b\u80fd(List list) {
        try {
            if (list.isEmpty()) {
                return;
            }
            \u8fb9\u754c$$ExternalSyntheticLambda4 \u8fb9\u754c$$ExternalSyntheticLambda4 = new \u8fb9\u754c$$ExternalSyntheticLambda4(list);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u8fb9\u754c$$ExternalSyntheticLambda4);
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    @Override
    public final String[] \u8d4b\u80fd(int[] arrn) {
        if (arrn == null) {
            return null;
        }
        String[] arrstring = new String[arrn.length];
        int n = arrn.length;
        boolean bl = false;
        for (int i = 0; i < n; ++i) {
            String string = this.\u8d4b\u80fd(arrn[i]);
            if (string == null) continue;
            try {
                arrstring[i] = string;
                bl = true;
                continue;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (bl) {
            return arrstring;
        }
        return null;
    }

    @Override
    public final String \u8fed\u4ee3(String string) {
        return new File(\u81ea\u6211.\u8d4b\u80fd, string).getAbsolutePath();
    }

    @Override
    public final ActivityInfo \u95ed\u73af(ComponentName componentName) {
        return (ActivityInfo)\u8fb9\u754c.\u6f0f\u6597(componentName);
    }

    @Override
    public final ResolveInfo \u95ed\u73af(Intent intent, String string, int n) {
        return (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(this.\u6293\u624b(intent, string, n)));
    }

    @Override
    public final boolean \u95ed\u73af(String string) {
        return \u4e2d\u53f0.containsKey(string);
    }
}

