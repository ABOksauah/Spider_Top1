/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityThread
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.os.Process
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.app.ActivityThread;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u653b\u575a;

public abstract class \u98ce\u53e3 {
    public static final int \u4e2d\u53f0;
    public static final String \u6293\u624b;
    public static final Context \u8d4b\u80fd;
    public static final int \u95ed\u73af;

    static {
        int n;
        Context context = \u653b\u575a.\u8d4b\u80fd;
        if (context == null) {
            context = ActivityThread.currentApplication().getBaseContext();
        }
        \u8d4b\u80fd = context;
        \u6293\u624b = context.getPackageName();
        \u4e2d\u53f0 = n = Process.myUid();
        \u95ed\u73af = n / 100000;
    }

    public static Object \u8d4b\u80fd(Function1 function1) {
        try {
            Object object = function1.invoke((Object)\u8d4b\u80fd.getPackageManager());
            return object;
        }
        catch (Exception exception) {
            return null;
        }
    }
}

