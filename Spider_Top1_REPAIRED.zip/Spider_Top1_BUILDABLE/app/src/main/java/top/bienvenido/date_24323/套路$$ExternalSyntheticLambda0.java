/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5957\u8def
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5957\u8def;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5957\u8def$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object f$0;

    public /* synthetic */ \u5957\u8def$$ExternalSyntheticLambda0(Object object) {
        this.f$0 = object;
    }

    public final Object invoke(Object object) {
        return \u5957\u8def.\u8d4b\u80fd((Object)this.f$0, (\u94f8\u9020)((\u94f8\u9020)object));
    }
}

