/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.AuthenticatorDescription
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.AuthenticatorDescription;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.HashMap;
import java.util.Map;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u88c2\u53d8;

public final class \u8986\u76d6
implements \u589e\u957f {
    public final IBinder \u8d4b\u80fd;

    public \u8986\u76d6(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final String \u4e2d\u53f0(Account account) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            this.\u8d4b\u80fd.transact(1, parcel, parcel2, 0);
            parcel2.readException();
            String string = parcel2.readString();
            return string;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String \u4e2d\u53f0(Account account, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(2, parcel, parcel2, 0);
            parcel2.readException();
            String string2 = parcel2.readString();
            return string2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final HashMap \u54cd\u5e94(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(26, parcel, parcel2, 0);
            parcel2.readException();
            HashMap hashMap = parcel2.readHashMap(\u8986\u76d6.class.getClassLoader());
            return hashMap;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String \u6293\u624b(Account account, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(12, parcel, parcel2, 0);
            parcel2.readException();
            String string2 = parcel2.readString();
            return string2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u6293\u624b(Account account, String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(13, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u6293\u624b(IBinder iBinder, String string, String[] arrstring) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeStringArray(arrstring);
            this.\u8d4b\u80fd.transact(8, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u6293\u624b(Account account) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoAccountManagerService");
                \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
                this.\u8d4b\u80fd.transact(21, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final Account[] \u7ed9\u5230() {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeString(null);
            parcel.writeInt(0);
            this.\u8d4b\u80fd.transact(4, parcel, parcel2, 0);
            parcel2.readException();
            Account[] arraccount = (Account[])parcel2.createTypedArray(Account.CREATOR);
            return arraccount;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final AuthenticatorDescription[] \u843d\u5730() {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            this.\u8d4b\u80fd.transact(3, parcel, parcel2, 0);
            parcel2.readException();
            AuthenticatorDescription[] arrauthenticatorDescription = (AuthenticatorDescription[])parcel2.createTypedArray(AuthenticatorDescription.CREATOR);
            return arrauthenticatorDescription;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(Account account, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(14, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(Account account, String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(15, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            this.\u8d4b\u80fd.transact(24, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, Bundle bundle, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)bundle);
            parcel.writeInt((int)bl);
            this.\u8d4b\u80fd.transact(20, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(23, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, String string, boolean bl, Bundle bundle) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            parcel.writeInt((int)bl);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)bundle);
            this.\u8d4b\u80fd.transact(18, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, String string, boolean bl, boolean bl2, Bundle bundle) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeString(string);
            parcel.writeInt((int)bl);
            parcel.writeInt((int)bl2);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)bundle);
            this.\u8d4b\u80fd.transact(16, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeInt((int)bl);
            this.\u8d4b\u80fd.transact(9, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Account account, String[] arrstring) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
            parcel.writeStringArray(arrstring);
            this.\u8d4b\u80fd.transact(6, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(22, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, String string2, String[] arrstring, boolean bl, Bundle bundle) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeString(string2);
            parcel.writeStringArray(arrstring);
            parcel.writeInt((int)bl);
            \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)bundle);
            this.\u8d4b\u80fd.transact(17, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeInt((int)bl);
            this.\u8d4b\u80fd.transact(19, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, String[] arrstring) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeStringArray(arrstring);
            this.\u8d4b\u80fd.transact(7, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(11, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u8d4b\u80fd(Account account) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoAccountManagerService");
                \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
                this.\u8d4b\u80fd.transact(10, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final boolean \u8d4b\u80fd(Account account, String string, Bundle bundle, Map map) {
        boolean bl;
        Parcel parcel;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoAccountManagerService");
                \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)account);
                parcel.writeString(string);
                \u88c2\u53d8.\u8d4b\u80fd(parcel, (Parcelable)bundle);
                parcel.writeMap(map);
                this.\u8d4b\u80fd.transact(25, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }

    @Override
    public final Account[] \u8ddf\u8fdb(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAccountManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(5, parcel, parcel2, 0);
            parcel2.readException();
            Account[] arraccount = (Account[])parcel2.createTypedArray(Account.CREATOR);
            return arraccount;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }
}

