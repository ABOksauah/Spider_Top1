/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function3
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u8499\u5c42$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u8499\u5c42
extends \u89e6\u8fbe {
    public static final Object \u8d4b\u80fd(\u8499\u5c42 \u8499\u5c422, Object object, Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Function3 function3 = \u8499\u5c422.\u6293\u624b();
        Object object2 = arrobject[1];
        int n = object2 instanceof Number ? ((Number)object2).intValue() : 0;
        return function3.invoke((Object)\u94f8\u90202, object, (Object)n);
    }

    public abstract Function3 \u6293\u624b();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        block5 : {
            object2 = arrobject[0];
            if (!(object2 instanceof String) || Intrinsics.areEqual((Object)object2, (Object)\u98ce\u53e3.\u6293\u624b)) return method.invoke(object, arrobject);
            if (\u6c34\u4f4d.\u6f0f\u6597 || !Intrinsics.areEqual((Object)object2, (Object)\u6c34\u4f4d.\u6293\u624b)) break block5;
            \u89e6\u8fbe.\u8d4b\u80fd(arrobject, 1);
            Object object3 = method.invoke(object, arrobject);
            if (object3 == null) return null;
            this.\u8d4b\u80fd().invoke(object3);
            return object3;
        }
        Object object4 = \u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u8499\u5c42$$ExternalSyntheticLambda0(this, object2, arrobject));
        if (object4 == null) return method.invoke(object, arrobject);
        try {
            this.\u8d4b\u80fd().invoke(object4);
            return object4;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }

    public abstract Function1 \u8d4b\u80fd();
}

