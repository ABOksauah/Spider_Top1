/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ActivityInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u793e\u7fa4
extends FunctionReferenceImpl
implements Function2 {
    public static final \u793e\u7fa4 \u8d4b\u80fd = new \u793e\u7fa4();

    public \u793e\u7fa4() {
        super(2, \u94f8\u9020.class, "getActivityInfo", "getActivityInfo(Landroid/content/ComponentName;)Landroid/content/pm/ActivityInfo;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u6293\u624b((ComponentName)object2);
    }
}

