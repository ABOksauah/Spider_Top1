/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u54c1\u724c;

public final class \u516c\u5173$$ExternalSyntheticLambda14
implements Runnable {
    public final /* synthetic */ \u54c1\u724c f$0;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda14(\u54c1\u724c \u54c1\u724c2) {
        this.f$0 = \u54c1\u724c2;
    }

    public final void run() {
        \u516c\u5173.\u6293\u624b((\u54c1\u724c)this.f$0);
    }
}

