/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u80cc\u9505$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94fe\u8def;

public final class \u80cc\u9505
extends \u89e6\u8fbe {
    public static final List \u8d4b\u80fd(\u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u6f0f\u6597(\u6c34\u4f4d.\u6c89\u6dc0);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        List list;
        if (\u6c34\u4f4d.\u8d4b\u80fd && (list = (List)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u80cc\u9505$$ExternalSyntheticLambda0())) != null) {
            return list;
        }
        return method.invoke(object, arrobject);
    }
}

