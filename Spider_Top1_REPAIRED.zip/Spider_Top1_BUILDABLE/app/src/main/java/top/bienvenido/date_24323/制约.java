/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$IntentInfo
 *  android.content.pm.PackageParser$Service
 *  android.content.pm.PackageParser$ServiceIntentInfo
 *  android.content.pm.ServiceInfo
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u5b9a\u6027
 *  top.bienvenido.date_24323.\u5b9a\u91cf
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageParser;
import android.content.pm.ServiceInfo;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u5171\u4eab;
import top.bienvenido.date_24323.\u5b9a\u6027;
import top.bienvenido.date_24323.\u5b9a\u91cf;
import top.bienvenido.date_24323.\u7ea6\u675f;

public final class \u5236\u7ea6
extends \u5171\u4eab {
    public final /* synthetic */ \u7ea6\u675f \u6c89\u6dc0;

    public \u5236\u7ea6(\u7ea6\u675f \u7ea6\u675f2, ArrayList arrayList) {
        this.\u6c89\u6dc0 = \u7ea6\u675f2;
        for (PackageParser.Service service : arrayList) {
            ArrayList arrayList2;
            if (service.info == null || (arrayList2 = service.intents) == null) continue;
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                this.\u8d4b\u80fd((IntentFilter)((PackageParser.ServiceIntentInfo)iterator.next()));
            }
        }
    }

    @Override
    public final int \u6293\u624b(IntentFilter intentFilter) {
        return ((PackageParser.ServiceIntentInfo)intentFilter).service.info.name.hashCode();
    }

    @Override
    public final Object \u8d4b\u80fd(IntentFilter intentFilter, int n, int n2) {
        PackageParser.ServiceIntentInfo serviceIntentInfo = (PackageParser.ServiceIntentInfo)intentFilter;
        return \u7ea6\u675f.\u8d4b\u80fd(this.\u6c89\u6dc0, (ComponentInfo)serviceIntentInfo.service.info, (Function2)new \u5b9a\u91cf((Object)\u5b9a\u6027.\u8d4b\u80fd), (PackageParser.IntentInfo)serviceIntentInfo, n2, n);
    }
}

