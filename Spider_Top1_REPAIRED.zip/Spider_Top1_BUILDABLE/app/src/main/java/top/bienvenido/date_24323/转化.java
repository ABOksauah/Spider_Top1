/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.system.Os
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.file.Files
 *  java.nio.file.Path
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u8f6c\u5316$
 *  top.bienvenido.date_24323.\u8f6c\u5316$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u8f6c\u5316$$ExternalSyntheticLambda1
 */
package top.bienvenido.date_24323;

import android.system.Os;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u8f6c\u5316$;

public final class \u8f6c\u5316 {
    public static final Function1 \u8d4b\u80fd;

    static {
        Object object = \u62bd\u8c61.\u843d\u5730 ? new $ExternalSyntheticLambda0() : new $ExternalSyntheticLambda1();
        \u8d4b\u80fd = object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean \u4e2d\u53f0(File file) {
        int n;
        int n2;
        File[] arrfile;
        try {
            if (!file.exists()) {
                return true;
            }
            if (!file.isDirectory()) {
                return file.delete();
            }
            arrfile = file.listFiles();
            if (arrfile == null) return file.delete();
            if (arrfile.length == 0) return file.delete();
            n2 = arrfile.length;
            n = 0;
        }
        catch (Exception exception) {
            return false;
        }
        while (n < n2) {
            File file2 = arrfile[n];
            boolean bl = file2.isFile();
            if (bl) {
                if (!file2.delete()) {
                    "Delete file " + (Object)file2 + " failed.";
                    return false;
                }
            } else if (file2.isDirectory()) {
                if (!((Boolean)\u8d4b\u80fd.invoke((Object)file2)).booleanValue()) {
                    "Delete directory " + (Object)file2 + " failed.";
                    return false;
                }
            } else {
                "File " + (Object)file2 + " is not file, wtf?";
                file2.delete();
            }
            ++n;
        }
        return file.delete();
    }

    public static void \u6293\u624b(File file) {
        int n;
        File[] arrfile;
        block8 : {
            if (!file.exists()) {
                return;
            }
            if (!file.isDirectory()) {
                return;
            }
            arrfile = file.listFiles();
            if (arrfile != null) break block8;
            return;
        }
        try {
            n = arrfile.length;
        }
        catch (Exception exception) {
            return;
        }
        for (int i = 0; i < n; ++i) {
            File file2 = arrfile[i];
            if (file2.isFile()) {
                file2.delete();
                continue;
            }
            \u8f6c\u5316.\u4e2d\u53f0(file2);
        }
        return;
    }

    public static final boolean \u843d\u5730(File file) {
        if (Intrinsics.areEqual((Object)file.getCanonicalPath(), (Object)file.getAbsolutePath())) {
            return \u8f6c\u5316.\u4e2d\u53f0(file);
        }
        return file.delete() || \u8f6c\u5316.\u4e2d\u53f0(file.getCanonicalFile());
        {
        }
    }

    public static void \u8d4b\u80fd(File file) {
        try {
            Os.chmod((String)file.getAbsolutePath(), (int)493);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static boolean \u8d4b\u80fd(String string2, String string3) {
        try {
            Os.symlink((String)string2, (String)string3);
            return true;
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static final boolean \u95ed\u73af(File file) {
        if (Files.isSymbolicLink((Path)file.toPath())) {
            return file.delete();
        }
        return \u8f6c\u5316.\u4e2d\u53f0(file);
    }
}

