/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Message
 *  android.os.MessageQueue
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u4f53\u611f
 *  top.bienvenido.date_24323.\u611f\u77e5
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4f53\u611f;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u611f\u77e5;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u4e0a\u9650
implements Callable {
    public final \u8d77\u98de \u4e2d\u53f0;
    public final Object \u6293\u624b;
    public final \u611f\u77e5 \u843d\u5730;
    public final \u81ea\u6d3d \u8d4b\u80fd = \u771f\u9999.\u8d4b\u80fd(MessageQueue.class, "mMessages");
    public final \u4f53\u611f \u95ed\u73af;

    public \u4e0a\u9650() {
        \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(Handler.class, "mQueue");
        \u6bb5\u4f4d.\u6293\u624b.getClass();
        this.\u6293\u624b = \u81ea\u6d3d2.\u8d4b\u80fd((Object)\u6bb5\u4f4d.\u95ed\u73af);
        this.\u4e2d\u53f0 = new \u8d77\u98de("token");
        this.\u95ed\u73af = new \u4f53\u611f((\u81ea\u6d3d)new \u8d77\u98de("intents"));
        \u8d77\u98de \u8d77\u98de2 = \u51b7\u542f\u52a8.\u843d\u5730;
        \u8d77\u98de \u8d77\u98de3 = new \u8d77\u98de("activityInfo");
        \u81ea\u6d3d \u81ea\u6d3d3 = \u62bd\u8c61.\u8d4b\u80fd ? new \u8d77\u98de("referrer") : \u81ea\u6d3d.\u8d4b\u80fd;
        this.\u843d\u5730 = new \u611f\u77e5((\u81ea\u6d3d)\u8d77\u98de2, (\u81ea\u6d3d)\u8d77\u98de3, \u81ea\u6d3d3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final Object call() {
        Object object;
        block14 : {
            Message message;
            block12 : {
                block13 : {
                    block11 : {
                        block10 : {
                            block9 : {
                                if (Intrinsics.areEqual((Object)Looper.myLooper(), (Object)Looper.getMainLooper())) break block9;
                                return null;
                            }
                            message = (Message)this.\u8d4b\u80fd.\u8d4b\u80fd(this.\u6293\u624b);
                            if (message != null) break block10;
                            return null;
                        }
                        \u6bb5\u4f4d.\u6293\u624b.getClass();
                        if (Intrinsics.areEqual((Object)\u6bb5\u4f4d.\u95ed\u73af, (Object)message.getTarget())) break block11;
                        return null;
                    }
                    int n = message.what;
                    if (n == 100) break block12;
                    if (n == 112) break block13;
                    return null;
                }
                Object object2 = message.obj;
                if (object2 == null) return null;
                this.\u95ed\u73af.invoke(object2);
                return null;
            }
            object = message.obj;
            if (object != null) break block14;
            return null;
        }
        try {
            \u611f\u77e5 \u611f\u77e52 = this.\u843d\u5730;
            Object object3 = this.\u4e2d\u53f0.\u6293\u624b.\u8d4b\u80fd(object);
            \u611f\u77e52.getClass();
            \u611f\u77e52.\u8d4b\u80fd(object, (IBinder)object3);
            return null;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }
}

