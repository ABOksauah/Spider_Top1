/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u8111\u66b4
implements Function1 {
    public final \u81ea\u6d3d \u8d4b\u80fd;

    public \u8111\u66b4() {
        \u81ea\u6d3d \u81ea\u6d3d2;
        Class[] arrclass = \u4e0b\u6c89.\u6293\u624b;
        try {
            \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(Class.forName((String)"android.app.PropertyInvalidatedCache$CacheMap"), "clear", arrclass);
        }
        catch (Exception exception) {
            \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
        }
        this.\u8d4b\u80fd = \u81ea\u6d3d2;
    }

    public final Object invoke(Object object) {
        this.\u8d4b\u80fd.\u8d4b\u80fd(object, new Object[0]);
        return Unit.INSTANCE;
    }
}

