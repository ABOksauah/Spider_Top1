/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u8ba4\u77e5;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5361\u8ba4\u77e5$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u5361\u8ba4\u77e5 f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object[] f$2;

    public /* synthetic */ \u5361\u8ba4\u77e5$$ExternalSyntheticLambda0(\u5361\u8ba4\u77e5 \u5361\u8ba4\u77e52, Object object, Object[] arrobject) {
        this.f$0 = \u5361\u8ba4\u77e52;
        this.f$1 = object;
        this.f$2 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u5361\u8ba4\u77e5.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (\u94f8\u9020)object);
    }
}

