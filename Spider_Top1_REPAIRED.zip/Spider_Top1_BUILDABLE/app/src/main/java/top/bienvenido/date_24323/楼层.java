/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.List
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u697c\u5c42$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u697c\u5c42
extends \u89e6\u53d1 {
    public static final Unit \u8d4b\u80fd(List list, \u94f8\u9020 \u94f8\u90202) {
        \u94f8\u90202.\u8d4b\u80fd(list);
        return Unit.INSTANCE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
        List list = (List)arrobject[0];
        if (list == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            \u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u697c\u5c42$$ExternalSyntheticLambda0(list));
            return null;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

