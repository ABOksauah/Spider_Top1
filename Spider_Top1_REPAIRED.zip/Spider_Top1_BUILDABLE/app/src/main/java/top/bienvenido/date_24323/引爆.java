/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.IServiceConnection
 *  android.os.IBinder
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.app.IServiceConnection;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5f15\u7206$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94fe\u8def;

public final class \u5f15\u7206
extends \u89e6\u53d1 {
    public static final boolean \u8d4b\u80fd(IServiceConnection iServiceConnection, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u4e2d\u53f0(iServiceConnection.asBinder());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
        IServiceConnection iServiceConnection = (IServiceConnection)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, IServiceConnection.class);
        if (iServiceConnection == null) return super.\u8d4b\u80fd(object, method, arrobject);
        Boolean bl = (Boolean)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u5f15\u7206$$ExternalSyntheticLambda0(iServiceConnection));
        if (bl == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            if (bl == false) return super.\u8d4b\u80fd(object, method, arrobject);
            return Boolean.TRUE;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

