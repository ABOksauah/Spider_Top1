/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.IBinder
 *  java.lang.Exception
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.IBinder;
import top.bienvenido.date_24323.\u5f39\u7a97;
import top.bienvenido.date_24323.\u81f4\u656c;

public final class \u75d2\u70b9
extends \u81f4\u656c {
    public static final \u5f39\u7a97 \u4e2d\u53f0;
    public static final \u75d2\u70b9 \u6293\u624b;

    static {
        \u6293\u624b = new \u75d2\u70b9();
        \u4e2d\u53f0 = new \u5f39\u7a97("");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void \u6293\u624b(Uri uri, IBinder iBinder, boolean bl) {
        \u5f39\u7a97 \u5f39\u7a972;
        if (iBinder == null) return;
        if (uri == null) {
            return;
        }
        \u5f39\u7a97 \u5f39\u7a973 = \u5f39\u7a972 = \u4e2d\u53f0;
        // MONITORENTER : \u5f39\u7a973
        \u5f39\u7a972.\u8d4b\u80fd(uri, 0, iBinder, bl);
        try {
            // MONITOREXIT : \u5f39\u7a973
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void \u843d\u5730(IBinder iBinder) {
        \u5f39\u7a97 \u5f39\u7a972;
        if (iBinder == null) {
            return;
        }
        try {
            \u5f39\u7a97 \u5f39\u7a973 = \u5f39\u7a972 = \u4e2d\u53f0;
            // MONITORENTER : \u5f39\u7a973
        }
        catch (Exception exception) {
            return;
        }
        \u5f39\u7a972.\u8d4b\u80fd(iBinder);
        // MONITOREXIT : \u5f39\u7a973
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void \u8d4b\u80fd(Uri var1_1, IBinder var2_2, boolean var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 10[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }
}

