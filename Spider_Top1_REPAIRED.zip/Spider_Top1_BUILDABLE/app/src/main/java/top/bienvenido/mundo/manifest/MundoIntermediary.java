/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.atomic.AtomicBoolean
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u516c\u5173
 *  top.bienvenido.date_24323.\u8fb9\u754c
 *  top.bienvenido.mundo.manifest.MundoIntermediary$
 *  top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda1
 */
package top.bienvenido.mundo.manifest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u6536\u53e3;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.manifest.MundoIntermediary$;
import top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda0;
import top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda2;
import top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda3;
import top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda4;
import top.bienvenido.mundo.manifest.MundoIntermediary$$ExternalSyntheticLambda5;

@Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"Ltop/bienvenido/mundo/manifest/MundoIntermediary;", "Landroid/app/Activity;", "<init>", "()V", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoIntermediary
extends Activity {
    public AtomicBoolean \u8d4b\u80fd = new AtomicBoolean(true);

    public static final Unit \u8d4b\u80fd(Intent intent, \u5e73\u53f0\u5316 \u5e73\u53f0\u53162, MundoIntermediary mundoIntermediary, Intent intent2, ArrayList arrayList, PackageManager packageManager) {
        Iterator iterator = packageManager.queryIntentActivities(intent, 131072).iterator();
        while (iterator.hasNext()) {
            ActivityInfo activityInfo = ((ResolveInfo)iterator.next()).activityInfo;
            int n = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)activityInfo).hashCode();
            if (\u753b\u997c.\u8d4b\u80fd(\u5e73\u53f0\u53162.\u8d4b\u80fd, \u5e73\u53f0\u53162.\u6293\u624b, n) >= 0 || Intrinsics.areEqual((Object)activityInfo.packageName, (Object)mundoIntermediary.getPackageName()) && Intrinsics.areEqual((Object)intent2.getScheme(), (Object)"fbconnect")) continue;
            arrayList.add((Object)activityInfo);
        }
        return Unit.INSTANCE;
    }

    public static final void \u8d4b\u80fd(AlertDialog.Builder builder) {
        try {
            builder.show();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(ArrayList arrayList, MundoIntermediary mundoIntermediary, Intent intent, Pair pair, Intent intent2, AtomicBoolean atomicBoolean, DialogInterface dialogInterface, int n) {
        ActivityInfo activityInfo;
        String string2;
        try {
            activityInfo = (ActivityInfo)arrayList.get(n);
            string2 = \u8fb9\u754c.\u6293\u624b.\u5bf9\u6807(activityInfo.packageName) ? (String)pair.getSecond() : null;
        }
        catch (Exception exception) {
            mundoIntermediary.\u8d4b\u80fd(atomicBoolean);
            return;
        }
        mundoIntermediary.\u8d4b\u80fd(intent, string2, activityInfo, intent2, atomicBoolean);
    }

    public static final void \u8d4b\u80fd(MundoIntermediary mundoIntermediary, Intent intent, AtomicBoolean atomicBoolean) {
        mundoIntermediary.\u8d4b\u80fd(intent, atomicBoolean);
    }

    public static final void \u8d4b\u80fd(MundoIntermediary mundoIntermediary, AtomicBoolean atomicBoolean, DialogInterface dialogInterface) {
        mundoIntermediary.\u8d4b\u80fd(atomicBoolean);
    }

    public static final void \u8d4b\u80fd(MundoIntermediary mundoIntermediary, AtomicBoolean atomicBoolean, DialogInterface dialogInterface, int n) {
        mundoIntermediary.\u8d4b\u80fd(atomicBoolean);
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.\u6293\u624b(this.getIntent(), this.\u8d4b\u80fd);
    }

    public final void onNewIntent(Intent intent) {
        AtomicBoolean atomicBoolean;
        super.onNewIntent(intent);
        this.\u8d4b\u80fd.set(false);
        this.\u8d4b\u80fd = atomicBoolean = new AtomicBoolean(true);
        this.\u6293\u624b(intent, atomicBoolean);
    }

    public final void onPause() {
        super.onPause();
        this.finish();
    }

    public final void \u6293\u624b(Intent intent, AtomicBoolean atomicBoolean) {
        MundoIntermediary$$ExternalSyntheticLambda0 mundoIntermediary$$ExternalSyntheticLambda0 = new MundoIntermediary$$ExternalSyntheticLambda0(this, intent, atomicBoolean);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)mundoIntermediary$$ExternalSyntheticLambda0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void \u8d4b\u80fd(Intent intent, String string2, ActivityInfo activityInfo, Intent intent2, AtomicBoolean atomicBoolean) {
        Intent intent3;
        block5 : {
            block4 : {
                try {
                    intent.setComponent(\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)activityInfo));
                    if (string2 == null) break block4;
                    \u516c\u5173 \u516c\u51732 = \u516c\u5173.\u6293\u624b;
                    IBinder iBinder = \u6536\u53e3.\u8d4b\u80fd(intent2, intent);
                    \u516c\u51732.getClass();
                    intent3 = \u516c\u5173.\u8d4b\u80fd((Intent)intent, (String)string2, (IBinder)iBinder, (ActivityInfo)activityInfo);
                    break block5;
                }
                catch (Exception exception) {
                    return;
                }
            }
            intent3 = null;
        }
        if (intent3 != null) {
            intent = intent3;
        }
        if (!\u6253\u78e8.\u8d4b\u80fd(intent.getFlags(), 268435456)) {
            intent.addFlags(33554432);
        }
        this.startActivity(intent);
        this.\u8d4b\u80fd(atomicBoolean);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void \u8d4b\u80fd(Intent var1_1, AtomicBoolean var2_2) {
        block16 : {
            block15 : {
                block14 : {
                    block13 : {
                        block12 : {
                            var4_3 = Intrinsics.areEqual((Object)var1_1.getScheme(), (Object)"fbconnect");
                            var5_4 = "0";
                            if (!var4_3) break block12;
                            var1_1.setComponent(null);
                            var8_6 = var41_5 = new Pair((Object)var1_1, (Object)var5_4);
                            ** GOTO lbl30
                        }
                        try {
                            var36_7 = var1_1.getExtras();
                            if (var36_7 == null || (var37_8 = (Intent)var36_7.getParcelable("android.intent.extra.INTENT")) == null) break block13;
                            var38_9 = var36_7.getString(String.class.getName());
                            if (var38_9 != null) break block14;
                            break block15;
                        }
                        catch (Exception var6_12) {
                            // empty catch block
                        }
                    }
                    var7_11 = null;
                    break block16;
                }
                var5_4 = var38_9;
            }
            var7_11 = var39_10 = new Pair((Object)var37_8, (Object)var5_4);
        }
        if (var7_11 != null) ** GOTO lbl29
        this.\u8d4b\u80fd(var2_2);
        return;
lbl29: // 1 sources:
        var8_6 = var7_11;
lbl30: // 2 sources:
        var9_13 = (Intent)var8_6.getFirst();
        var10_14 = \u8fb9\u754c.\u6293\u624b;
        var11_15 = 0;
        var12_16 = var10_14.\u4e2d\u53f0(var9_13, null, 0);
        var13_17 = new ArrayList();
        var14_18 = new \u5e73\u53f0\u5316(8);
        if (!var12_16.isEmpty()) {
            var32_19 = var12_16.iterator();
            while (var32_19.hasNext()) {
                var33_20 = ((ResolveInfo)var32_19.next()).activityInfo;
                var14_18.\u8d4b\u80fd(\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)var33_20).hashCode());
                var13_17.add((Object)var33_20);
            }
        }
        var16_21 = new $ExternalSyntheticLambda1(var9_13, var14_18, this, var1_1, var13_17);
        \u98ce\u53e3.\u8d4b\u80fd((Function1)var16_21);
        if (var13_17.isEmpty()) {
            this.\u8d4b\u80fd(var2_2);
            return;
        }
        if (var13_17.size() == 1) {
            var30_22 = (ActivityInfo)var13_17.get(0);
            if (Intrinsics.areEqual((Object)((Intent)var8_6.getFirst()).getScheme(), (Object)"fbconnect")) {
                \u516c\u5173.\u6293\u624b.\u8d4b\u80fd(((Intent)var8_6.getFirst()).setComponent(\u6253\u78e8.\u8d4b\u80fd((ComponentInfo)var30_22)), (String)var8_6.getSecond());
                return;
            }
            var31_23 = \u8fb9\u754c.\u6293\u624b.\u5bf9\u6807(var30_22.packageName) == false ? null : (String)var8_6.getSecond();
            this.\u8d4b\u80fd(var9_13, var31_23, var30_22, var1_1, var2_2);
            return;
        }
        var18_24 = this.getPackageManager();
        var19_25 = var13_17.size();
        var20_26 = new String[var19_25];
        while (var11_15 < var19_25) {
            var21_27 = (ActivityInfo)var13_17.get(var11_15);
            var22_28 = var21_27.loadLabel(var18_24);
            var23_29 = var21_27.packageName;
            var20_26[var11_15] = (Object)var22_28 + " (" + var23_29 + ")";
            ++var11_15;
        }
        try {
            var24_30 = new AlertDialog.Builder((Context)this);
            var25_31 = var20_26;
            var26_32 = new MundoIntermediary$$ExternalSyntheticLambda2(var13_17, this, var9_13, var8_6, var1_1, var2_2);
            var24_30.setItems(var25_31, (DialogInterface.OnClickListener)var26_32);
            var24_30.setNegativeButton((CharSequence)"X", (DialogInterface.OnClickListener)new MundoIntermediary$$ExternalSyntheticLambda3(this, var2_2));
            var24_30.setOnDismissListener((DialogInterface.OnDismissListener)new MundoIntermediary$$ExternalSyntheticLambda4(this, var2_2));
            this.runOnUiThread((Runnable)new MundoIntermediary$$ExternalSyntheticLambda5(var24_30));
            return;
        }
        catch (Exception var3_33) {
            return;
        }
    }

    public final void \u8d4b\u80fd(AtomicBoolean atomicBoolean) {
        if (atomicBoolean.get() && !this.isFinishing()) {
            this.finish();
        }
    }
}

