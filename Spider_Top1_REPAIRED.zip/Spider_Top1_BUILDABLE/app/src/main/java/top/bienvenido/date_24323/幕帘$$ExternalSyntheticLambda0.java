/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5e55\u5e18
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e55\u5e18;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5e55\u5e18$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ ComponentName f$0;

    public /* synthetic */ \u5e55\u5e18$$ExternalSyntheticLambda0(ComponentName componentName) {
        this.f$0 = componentName;
    }

    public final Object invoke(Object object) {
        return \u5e55\u5e18.\u8d4b\u80fd((ComponentName)this.f$0, (\u94f8\u9020)((\u94f8\u9020)object));
    }
}

