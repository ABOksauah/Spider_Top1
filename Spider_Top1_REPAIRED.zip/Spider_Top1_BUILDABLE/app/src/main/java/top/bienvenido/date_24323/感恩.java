/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ProviderInfo
 *  android.os.BadParcelableException
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ProviderInfo;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u6bd4\u5fc3;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u9ad8\u5730;

public abstract class \u611f\u6069
extends Binder
implements \u7b14\u82af {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u611f\u6069() {
        this.attachInterface((IInterface)this, "MundoActivityManagerService");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        int n3;
        block26 : {
            int n4;
            block27 : {
                if (n >= 1 && n <= 16777215) {
                    parcel.enforceInterface("MundoActivityManagerService");
                }
                if (n == 1598968902) {
                    parcel2.writeString("MundoActivityManagerService");
                    return true;
                }
                Object object = null;
                switch (n) {
                    default: {
                        return super.onTransact(n, parcel, parcel2, n2);
                    }
                    case 19: {
                        String string = parcel.readString();
                        String string2 = parcel.readString();
                        String string3 = parcel.readString();
                        ((\u5408\u529b)this).\u8d4b\u80fd(string, string2, string3);
                        parcel2.writeNoException();
                        return true;
                    }
                    case 18: {
                        String string = parcel.readString();
                        ((\u5408\u529b)this).\u5e73\u53f0(string);
                        parcel2.writeNoException();
                        return true;
                    }
                    case 17: {
                        Intent intent = (Intent)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, Intent.CREATOR);
                        String string = parcel.readString();
                        IBinder iBinder = ((\u5408\u529b)this).\u95ed\u73af(intent, string);
                        parcel2.writeNoException();
                        parcel2.writeStrongBinder(iBinder);
                        return true;
                    }
                    case 16: {
                        \u9ad8\u5730.\u8d4b\u80fd();
                        return true;
                    }
                    case 15: {
                        String string = parcel.readString();
                        String string4 = parcel.readString();
                        int n5 = \u516c\u5173.\u6293\u624b.\u6f0f\u6597(string, string4);
                        parcel2.writeNoException();
                        parcel2.writeInt(n5);
                        return true;
                    }
                    case 14: {
                        String string = parcel.readString();
                        String string5 = parcel.readString();
                        ((\u5408\u529b)this).\u95ed\u73af(string, string5);
                        return true;
                    }
                    case 13: {
                        Intent intent = (Intent)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, Intent.CREATOR);
                        String string = parcel.readString();
                        int n6 = ((\u5408\u529b)this).\u6293\u624b(intent, string);
                        parcel2.writeNoException();
                        parcel2.writeInt(n6);
                        return true;
                    }
                    case 12: {
                        IBinder iBinder = parcel.readStrongBinder();
                        ((\u5408\u529b)this).\u6293\u624b(iBinder);
                        return true;
                    }
                    case 11: {
                        int n7 = parcel.readInt();
                        IBinder iBinder = parcel.readStrongBinder();
                        Parcelable.Creator creator = IntentFilter.CREATOR;
                        if (parcel.readInt() != 0) {
                            object = creator.createFromParcel(parcel);
                        }
                        IntentFilter intentFilter = (IntentFilter)object;
                        ((\u5408\u529b)this).\u8d4b\u80fd(n7, iBinder, intentFilter);
                        return true;
                    }
                    case 10: {
                        int n8 = parcel.readInt();
                        String[] arrstring = ((\u5408\u529b)this).\u95ed\u73af(n8);
                        parcel2.writeNoException();
                        parcel2.writeStringArray(arrstring);
                        return true;
                    }
                    case 9: {
                        int n9 = parcel.readInt();
                        ArrayList arrayList = ((\u5408\u529b)this).\u6f0f\u6597(n9);
                        parcel2.writeNoException();
                        int n10 = arrayList.size();
                        parcel2.writeInt(n10);
                        for (int i = 0; i < n10; ++i) {
                            \u6bd4\u5fc3.\u8d4b\u80fd(parcel2, (Parcelable)arrayList.get(i), 1);
                        }
                        break;
                    }
                    case 8: {
                        ComponentName componentName = (ComponentName)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, ComponentName.CREATOR);
                        String string = parcel.readString();
                        IBinder iBinder = ((\u5408\u529b)this).\u8d4b\u80fd(componentName, string);
                        parcel2.writeNoException();
                        parcel2.writeStrongBinder(iBinder);
                        return true;
                    }
                    case 7: {
                        IBinder iBinder = parcel.readStrongBinder();
                        Parcelable.Creator creator = Intent.CREATOR;
                        if (parcel.readInt() != 0) {
                            object = creator.createFromParcel(parcel);
                        }
                        Intent intent = (Intent)object;
                        IBinder iBinder2 = parcel.readStrongBinder();
                        int n11 = ((\u5408\u529b)this).\u8d4b\u80fd(iBinder, intent, iBinder2);
                        parcel2.writeNoException();
                        parcel2.writeInt(n11);
                        return true;
                    }
                    case 6: {
                        IBinder iBinder = parcel.readStrongBinder();
                        int n12 = ((\u5408\u529b)this).\u4e2d\u53f0(iBinder);
                        parcel2.writeNoException();
                        parcel2.writeInt(n12);
                        return true;
                    }
                    case 5: {
                        Intent intent = (Intent)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, Intent.CREATOR);
                        IBinder iBinder = parcel.readStrongBinder();
                        String string = parcel.readString();
                        int n13 = ((\u5408\u529b)this).\u6293\u624b(intent, iBinder, string);
                        parcel2.writeNoException();
                        parcel2.writeInt(n13);
                        return true;
                    }
                    case 4: {
                        ComponentName componentName = (ComponentName)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, ComponentName.CREATOR);
                        IBinder iBinder = parcel.readStrongBinder();
                        int n14 = parcel.readInt();
                        int n15 = ((\u5408\u529b)this).\u8d4b\u80fd(componentName, iBinder, n14);
                        parcel2.writeNoException();
                        parcel2.writeInt(n15);
                        return true;
                    }
                    case 3: {
                        Intent intent = (Intent)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, Intent.CREATOR);
                        String string = parcel.readString();
                        int n16 = ((\u5408\u529b)this).\u4e2d\u53f0(intent, string);
                        parcel2.writeNoException();
                        parcel2.writeInt(n16);
                        return true;
                    }
                    case 2: {
                        Intent intent = (Intent)\u6bd4\u5fc3.\u8d4b\u80fd(parcel, Intent.CREATOR);
                        String string = parcel.readString();
                        ComponentName componentName = ((\u5408\u529b)this).\u843d\u5730(intent, string);
                        parcel2.writeNoException();
                        \u6bd4\u5fc3.\u8d4b\u80fd(parcel2, (Parcelable)componentName, 1);
                        return true;
                    }
                    case 1: {
                        String string = parcel.readString();
                        String string6 = parcel.readString();
                        n3 = parcel.readInt();
                        if (n3 > 1000000) break block26;
                        ProviderInfo[] arrproviderInfo = n3 < 0 ? null : new ProviderInfo[n3];
                        n4 = parcel.readInt();
                        if (n4 > 1000000) break block27;
                        String[] arrstring = n4 < 0 ? null : new String[n4];
                        int n17 = parcel.readInt();
                        IBinder iBinder = ((\u5408\u529b)this).\u8d4b\u80fd(string, string6, arrproviderInfo, arrstring, n17);
                        parcel2.writeNoException();
                        parcel2.writeStrongBinder(iBinder);
                        parcel2.writeTypedArray((Parcelable[])arrproviderInfo, 1);
                        parcel2.writeStringArray(arrstring);
                    }
                }
                return true;
            }
            throw new BadParcelableException("Array too large: " + n4);
        }
        throw new BadParcelableException("Array too large: " + n3);
    }
}

