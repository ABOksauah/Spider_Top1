/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.UiModeManager
 *  android.app.WallpaperManager
 *  android.content.ComponentName
 *  android.media.AudioManager
 *  com.android.internal.net.VpnConfig
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u5236\u9ad8\u70b9
 *  top.bienvenido.date_24323.\u53ef\u7528\u6027
 *  top.bienvenido.date_24323.\u5403\u900f
 *  top.bienvenido.date_24323.\u6811\u7acb
 *  top.bienvenido.date_24323.\u6b7b\u78d5
 *  top.bienvenido.date_24323.\u7ea2\u6d77
 *  top.bienvenido.date_24323.\u7eb5\u5411
 */
package top.bienvenido.date_24323;

import android.app.UiModeManager;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.media.AudioManager;
import com.android.internal.net.VpnConfig;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u516c\u57df;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5236\u9ad8\u70b9;
import top.bienvenido.date_24323.\u53ef\u7528\u6027;
import top.bienvenido.date_24323.\u5403\u900f;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6811\u7acb;
import top.bienvenido.date_24323.\u6b7b\u78d5;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7ea2\u6d77;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u8de8\u754c
extends \u96c6\u6210 {
    public static final \u8de8\u754c \u6293\u624b = new \u8de8\u754c();

    @Override
    public final void \u8d4b\u80fd() {
        \u51fa\u51fb \u51fa\u51fb2;
        Object object;
        \u51fa\u51fb \u51fa\u51fb3;
        \u51fa\u51fb \u51fa\u51fb4;
        \u51fa\u51fb \u51fa\u51fb5;
        \u51fa\u51fb \u51fa\u51fb6;
        \u51fa\u51fb \u51fa\u51fb7;
        \u51fa\u51fb \u51fa\u51fb8;
        \u51fa\u51fb \u51fa\u51fb9;
        \u516c\u57df \u516c\u57df2 = \u672c\u6211.\u5e73\u53f0;
        this.\u8d4b\u80fd = \u516c\u57df2;
        \u6d1e\u81ea\u8eab.\u8d4b\u80fd("appwidget", \u516c\u57df2, null);
        this.\u8d4b\u80fd = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd("usb", "consumer_ir", "telecom", "lock_settings", "backup", "print", "launcherapps", "imms", "restrictions", "isms", "search", "media_router", "statusbar", "accessibility");
        \u51fa\u51fb \u51fa\u51fb10 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("alarm", this.\u8d4b\u80fd, null);
        if (\u51fa\u51fb10 != null) {
            \u516c\u57df \u516c\u57df3 = \u672c\u6211.\u54cd\u5e94;
            \u51fa\u51fb10.\u8d4b\u80fd.\u8d4b\u80fd(113762, \u516c\u57df3);
        }
        if ((\u51fa\u51fb4 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("audio", this.\u8d4b\u80fd, null)) != null) {
            \u771f\u9999.\u8d4b\u80fd(AudioManager.class, "sService", \u51fa\u51fb4.\u95ed\u73af);
        }
        if ((\u51fa\u51fb9 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("autofill", this.\u8d4b\u80fd, null)) != null) {
            \u51fa\u51fb9.\u8d4b\u80fd(new int[]{1850541012, -860784333, -464872500}, \u516c\u57df2);
        }
        if ((\u51fa\u51fb7 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("media.camera", this.\u8d4b\u80fd, null)) != null) {
            \u5403\u900f \u5403\u900f2 = new \u5403\u900f();
            \u51fa\u51fb7.\u8d4b\u80fd.\u8d4b\u80fd(-1581470752, (Object)\u5403\u900f2);
        }
        if ((\u51fa\u51fb8 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("connectivity", this.\u8d4b\u80fd, null)) != null) {
            if (!\u62bd\u8c61.\u7ed9\u5230) {
                try {
                    \u7eb5\u5411 \u7eb5\u54112 = new \u7eb5\u5411(VpnConfig.class, (Function2)new \u5236\u9ad8\u70b9((Object)\u53ef\u7528\u6027.\u8d4b\u80fd), "top.bienvenido.mundo.manifest.MundoService$Companion$STUB");
                    \u51fa\u51fb8.\u8d4b\u80fd.\u8d4b\u80fd(-1710356229, (Object)\u7eb5\u54112);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            \u6b7b\u78d5 \u6b7b\u78d52 = new \u6b7b\u78d5();
            \u51fa\u51fb8.\u8d4b\u80fd.\u8d4b\u80fd(-713968189, (Object)\u6b7b\u78d52);
            if (\u62bd\u8c61.\u6293\u624b) {
                \u6811\u7acb \u6811\u7acb2 = new \u6811\u7acb();
                \u51fa\u51fb8.\u8d4b\u80fd.\u8d4b\u80fd(1483925501, (Object)\u6811\u7acb2);
            }
        }
        if ((\u51fa\u51fb5 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("device_policy", this.\u8d4b\u80fd, null)) != null) {
            \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df((Object)new ComponentName(\u98ce\u53e3.\u6293\u624b, "main"));
            \u51fa\u51fb5.\u8d4b\u80fd.\u8d4b\u80fd(952007670, \u79c1\u57df2);
            \u51fa\u51fb5.\u8d4b\u80fd(new int[]{-1597971470, 613161899}, \u672c\u6211.\u7ed9\u5230);
        }
        if ((\u51fa\u51fb6 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("location", this.\u8d4b\u80fd, null)) != null) {
            try {
                if (\u62bd\u8c61.\u5bf9\u9f50) {
                    \u7eb5\u5411 \u7eb5\u54113 = new \u7eb5\u5411(Class.forName((String)"android.location.provider.ReverseGeocodeRequest"), (Function2)new \u7ea2\u6d77(new \u8d77\u98de("mCallingPackage")));
                    \u51fa\u51fb6.\u8d4b\u80fd.\u8d4b\u80fd(-1235628164, (Object)\u7eb5\u54113);
                    \u7eb5\u5411 \u7eb5\u54114 = new \u7eb5\u5411(Class.forName((String)"android.location.provider.ForwardGeocodeRequest"), (Function2)new \u7ea2\u6d77(new \u8d77\u98de("mCallingPackage")));
                    \u51fa\u51fb6.\u8d4b\u80fd.\u8d4b\u80fd(-1789232583, (Object)\u7eb5\u54114);
                } else {
                    \u51fa\u51fb6.\u8d4b\u80fd(new int[]{1102537717, 250564640}, (\u89e6\u8fbe)new \u7eb5\u5411(Class.forName((String)"android.location.GeocoderParams"), (Function2)new \u7ea2\u6d77(new \u8d77\u98de("mPackageName"))));
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if ((\u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("wallpaper", this.\u8d4b\u80fd, null)) != null && (object = \u771f\u9999.\u4e2d\u53f0(WallpaperManager.class, "sGlobals")) != null) {
            Object object2 = \u51fa\u51fb2.\u95ed\u73af;
            new \u8d77\u98de((String)"mService").\u6293\u624b.\u8d4b\u80fd(object, object2);
        }
        if ((\u51fa\u51fb3 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("uimode", this.\u8d4b\u80fd, null)) != null) {
            Object object3;
            if (\u62bd\u8c61.\u540c\u6b65 && (object3 = \u771f\u9999.\u8d4b\u80fd(UiModeManager.class, "sGlobals").\u8d4b\u80fd(null)) != null) {
                \u771f\u9999.\u8d4b\u80fd(object3.getClass(), "mService").\u8d4b\u80fd(object3, \u51fa\u51fb3.\u95ed\u73af);
            }
            \u79c1\u57df \u79c1\u57df3 = \u672c\u6211.\u7ed9\u5230;
            \u51fa\u51fb3.\u8d4b\u80fd.\u8d4b\u80fd(-1390053479, \u79c1\u57df3);
            \u51fa\u51fb3.\u8d4b\u80fd.\u8d4b\u80fd(1392133613, \u79c1\u57df3);
        }
    }
}

