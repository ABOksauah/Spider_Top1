/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.content.Context;

public abstract class \u653b\u575a {
    public static Context \u8d4b\u80fd;
}

