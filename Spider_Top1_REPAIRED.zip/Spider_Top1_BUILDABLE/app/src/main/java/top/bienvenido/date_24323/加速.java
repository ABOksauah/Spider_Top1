/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.servertransaction.ClientTransaction
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.app.servertransaction.ClientTransaction;
import java.lang.reflect.Method;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u52a0\u901f
implements Function1 {
    public final \u81ea\u6d3d \u8d4b\u80fd;

    public \u52a0\u901f() {
        \u81ea\u6d3d \u81ea\u6d3d2;
        Class[] arrclass = \u4e0b\u6c89.\u6293\u624b;
        try {
            Method method = ClientTransaction.class.getDeclaredMethod("getCallbacks", arrclass);
            method.setAccessible(true);
            \u81ea\u6d3d2 = new \u76ae\u5b9e(method);
        }
        catch (Exception exception) {
            \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
        }
        this.\u8d4b\u80fd = \u81ea\u6d3d2;
    }

    public final Object invoke(Object object) {
        ClientTransaction clientTransaction = (ClientTransaction)object;
        return (List)this.\u8d4b\u80fd.\u8d4b\u80fd((Object)clientTransaction, new Object[0]);
    }
}

