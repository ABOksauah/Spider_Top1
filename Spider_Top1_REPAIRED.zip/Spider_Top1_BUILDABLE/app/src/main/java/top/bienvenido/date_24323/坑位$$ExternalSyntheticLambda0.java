/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5751\u4f4d
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5751\u4f4d;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5751\u4f4d$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u5751\u4f4d$$ExternalSyntheticLambda0(String string) {
        this.f$0 = string;
    }

    public final Object invoke(Object object) {
        return \u5751\u4f4d.\u8d4b\u80fd((String)this.f$0, (\u94f8\u9020)((\u94f8\u9020)object));
    }
}

