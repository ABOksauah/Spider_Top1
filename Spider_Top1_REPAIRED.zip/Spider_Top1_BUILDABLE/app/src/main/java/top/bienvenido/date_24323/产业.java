/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ServiceInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ServiceInfo;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u4ea7\u4e1a
extends FunctionReferenceImpl
implements Function2 {
    public static final \u4ea7\u4e1a \u8d4b\u80fd = new \u4ea7\u4e1a();

    public \u4ea7\u4e1a() {
        super(2, \u94f8\u9020.class, "getServiceInfo", "getServiceInfo(Landroid/content/ComponentName;)Landroid/content/pm/ServiceInfo;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u843d\u5730((ComponentName)object2);
    }
}

