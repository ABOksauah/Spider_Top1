/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.common.reflection;

import kotlin.Metadata;

@Metadata(d1={"\u0000B\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010\n\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u001a\u0010\b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00078\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\b\u0010\tR\u0016\u0010\n\u001a\u0004\u0018\u00010\u00018\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0016\u0010\f\u001a\u0004\u0018\u00010\u00018\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\f\u0010\u000bR\u001c\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\r8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u001a\u0010\u0013\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00078\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0013\u0010\tR\u0016\u0010\u0014\u001a\u0004\u0018\u00010\u00018\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0014\u0010\u000bR\u0014\u0010\u0016\u001a\u00020\u00158\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\u00158\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0018\u0010\u0017R\u0014\u0010\u0019\u001a\u00020\u00158\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u0019\u0010\u0017R\u0014\u0010\u001b\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u001b\u0010\u001cR\u0014\u0010\u001d\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u001d\u0010\u001cR\u0014\u0010\u001e\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u001e\u0010\u001cR\u0014\u0010\u001f\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\u001f\u0010\u001cR\u0014\u0010 \u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b \u0010\u001cR\u0014\u0010!\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b!\u0010\u001cR\u0014\u0010\"\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b\"\u0010\u001cR\u0014\u0010#\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b#\u0010\u001cR\u0014\u0010$\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b$\u0010\u001cR\u0014\u0010%\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b%\u0010\u001cR\u0014\u0010&\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b&\u0010\u001cR\u0014\u0010'\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b'\u0010\u001cR\u0014\u0010(\u001a\u00020\u001a8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b(\u0010\u001cR\u0014\u0010*\u001a\u00020)8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b*\u0010+R\u0014\u0010,\u001a\u00020)8\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\b,\u0010+\u00a8\u0006-"}, d2={"top/bienvenido/mundo/common/reflection/MundoReflectionStub$Class", "", "<init>", "()V", "Ljava/lang/ClassLoader;", "classLoader", "Ljava/lang/ClassLoader;", "Ljava/lang/Class;", "componentType", "Ljava/lang/Class;", "dexCache", "Ljava/lang/Object;", "extData", "", "ifTable", "[Ljava/lang/Object;", "", "name", "Ljava/lang/String;", "superClass", "vtable", "", "iFields", "J", "methods", "sFields", "", "accessFlags", "I", "classFlags", "classSize", "clinitThreadId", "dexClassDefIndex", "dexTypeIndex", "numReferenceInstanceFields", "numReferenceStaticFields", "objectSize", "objectSizeAllocFastPath", "primitiveType", "referenceInstanceOffsets", "status", "", "copiedMethodsOffset", "S", "virtualMethodsOffset", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoReflectionStub$Class {
    private final transient int accessFlags;
    private final transient int classFlags;
    private final transient ClassLoader classLoader;
    private final transient int classSize;
    private final transient int clinitThreadId;
    private final transient Class<?> componentType;
    private final transient short copiedMethodsOffset;
    private final transient Object dexCache;
    private final transient int dexClassDefIndex;
    private final transient int dexTypeIndex;
    private final transient Object extData;
    private final transient long iFields;
    private final transient Object[] ifTable;
    private final transient long methods;
    private final transient String name;
    private final transient int numReferenceInstanceFields;
    private final transient int numReferenceStaticFields;
    private final transient int objectSize;
    private final transient int objectSizeAllocFastPath;
    private final transient int primitiveType;
    private final transient int referenceInstanceOffsets;
    private final transient long sFields;
    private final transient int status;
    private final transient Class<?> superClass;
    private final transient short virtualMethodsOffset;
    private final transient Object vtable;
}

