/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.window.IWindowContainerToken
 *  android.window.IWindowContainerToken$Stub
 */
package top.bienvenido.date_24323;

import android.window.IWindowContainerToken;

public final class \u5f3a\u4f9d\u8d56
extends IWindowContainerToken.Stub {
}

