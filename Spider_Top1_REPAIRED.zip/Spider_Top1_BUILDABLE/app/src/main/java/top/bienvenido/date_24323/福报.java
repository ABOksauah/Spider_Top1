/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  kotlin.io.FileTreeWalk
 *  kotlin.io.FilesKt
 *  kotlin.text.HexExtensionsKt
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.util.Iterator;
import kotlin.io.FileTreeWalk;
import kotlin.io.FilesKt;
import kotlin.text.HexExtensionsKt;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u8f6c\u5316;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u798f\u62a5 {
    public static final File \u8d4b\u80fd;

    static {
        Context context = \u98ce\u53e3.\u8d4b\u80fd;
        String string2 = \u98ce\u53e3.\u6293\u624b;
        String string3 = Build.MANUFACTURER;
        String string4 = Build.MODEL;
        String string5 = Build.BRAND;
        \u8d4b\u80fd = context.getDir(HexExtensionsKt.toHexString$default((int)(string2 + string3 + string4 + string5).hashCode(), null, (int)1, null), 0);
    }

    public static void \u8d4b\u80fd(String string2, String string3) {
        File file = string3 != null && string3.length() != 0 ? \u6253\u78e8.\u8d4b\u80fd(\u8d4b\u80fd, string2, string3) : \u6253\u78e8.\u8d4b\u80fd(\u8d4b\u80fd, string2);
        if (file.exists()) {
            FileTreeWalk fileTreeWalk = FilesKt.walkBottomUp((File)file);
            Iterator iterator = fileTreeWalk.iterator();
            while (iterator.hasNext()) {
                \u8f6c\u5316.\u8d4b\u80fd((File)iterator.next());
            }
            \u8f6c\u5316.\u4e2d\u53f0(file);
        }
    }
}

