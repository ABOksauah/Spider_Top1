/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.LinkProperties
 *  android.net.ProxyInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.net.URI
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 */
package top.bienvenido.date_24323;

import android.net.LinkProperties;
import android.net.ProxyInfo;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.List;
import kotlin.collections.CollectionsKt;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u6b7b\u78d5
extends \u89e6\u53d1 {
    public final \u81ea\u6d3d \u6293\u624b = \u771f\u9999.\u8d4b\u80fd(LinkProperties.class, "mHttpProxy");

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = super.\u8d4b\u80fd(object, method, arrobject);
        if (object2 != null) {
            String string = \u6c34\u4f4d.\u7ed9\u5230;
            if (string.length() > 0 && object2 instanceof LinkProperties) {
                try {
                    \u81ea\u6d3d \u81ea\u6d3d2 = this.\u6293\u624b;
                    URI uRI = URI.create((String)string);
                    \u81ea\u6d3d2.\u8d4b\u80fd(object2, (Object)ProxyInfo.buildDirectProxy((String)uRI.getHost(), (int)uRI.getPort(), (List)CollectionsKt.listOf((Object[])new String[]{"*.cn", "localhost", "127.*", "[::1]", "0.0.0.0", "[::0]"})));
                    return object2;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            return object2;
        }
        return null;
    }
}

