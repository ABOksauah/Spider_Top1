/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.os.Binder
 *  android.os.IBinder
 *  java.lang.String
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 *  java.util.Deque
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Binder;
import android.os.IBinder;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Deque;
import top.bienvenido.date_24323.\u54c1\u724c;

public final class \u5fc3\u529b
extends Binder {
    public final \u54c1\u724c \u4e2d\u53f0;
    public final Reference \u6293\u624b;
    public int \u6c89\u6dc0;
    public IBinder \u6f0f\u6597;
    public Deque \u7ed9\u5230;
    public final String \u843d\u5730;
    public final ActivityInfo \u8d4b\u80fd;
    public final Intent \u95ed\u73af;

    public \u5fc3\u529b(ActivityInfo activityInfo, WeakReference weakReference, \u54c1\u724c \u54c1\u724c2, Intent intent, String string2) {
        this.\u8d4b\u80fd = activityInfo;
        this.\u6293\u624b = weakReference;
        this.\u4e2d\u53f0 = \u54c1\u724c2;
        this.\u95ed\u73af = intent;
        this.\u843d\u5730 = string2;
        this.\u6c89\u6dc0 = -1;
    }
}

