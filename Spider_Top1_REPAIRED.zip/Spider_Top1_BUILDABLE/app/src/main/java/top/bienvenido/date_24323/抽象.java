/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u62bd\u8c61$
 *  top.bienvenido.date_24323.\u62bd\u8c61$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 */
package top.bienvenido.date_24323;

import android.os.Build;
import java.lang.reflect.Method;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u62bd\u8c61$;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public abstract class \u62bd\u8c61 {
    public static final boolean \u4e2d\u53f0;
    public static final boolean \u4ea4\u4ed8;
    public static final boolean \u4f18\u5316;
    public static final boolean \u5347\u7ea7;
    public static final boolean \u540c\u6b65;
    public static final boolean \u54cd\u5e94;
    public static final boolean \u5bf9\u6807;
    public static final boolean \u5bf9\u9f50;
    public static final boolean \u5e73\u53f0;
    public static final boolean \u6293\u624b;
    public static final boolean \u6c89\u6dc0;
    public static final boolean \u6f0f\u6597;
    public static final boolean \u7ed9\u5230;
    public static final boolean \u843d\u5730;
    public static final boolean \u8d4b\u80fd;
    public static final boolean \u8ddf\u8fdb;
    public static final boolean \u8fed\u4ee3;
    public static final boolean \u95ed\u73af;

    static {
        boolean bl;
        block10 : {
            block9 : {
                \u81ea\u6d3d \u81ea\u6d3d2;
                int n = Build.VERSION.SDK_INT;
                boolean bl2 = n >= 22;
                \u8d4b\u80fd = bl2;
                boolean bl3 = n >= 23;
                \u6293\u624b = bl3;
                boolean bl4 = n >= 24;
                \u4e2d\u53f0 = bl4;
                boolean bl5 = n >= 25;
                \u95ed\u73af = bl5;
                boolean bl6 = n >= 26;
                \u843d\u5730 = bl6;
                boolean bl7 = n >= 28;
                \u6f0f\u6597 = bl7;
                boolean bl8 = n >= 29;
                \u6c89\u6dc0 = bl8;
                boolean bl9 = n >= 30;
                \u7ed9\u5230 = bl9;
                boolean bl10 = n >= 31;
                \u5e73\u53f0 = bl10;
                boolean bl11 = n >= 33;
                \u54cd\u5e94 = bl11;
                boolean bl12 = n >= 34;
                \u540c\u6b65 = bl12;
                boolean bl13 = n >= 35;
                \u5bf9\u9f50 = bl13;
                boolean bl14 = n >= 36;
                \u5bf9\u6807 = bl14;
                boolean bl15 = n >= 37;
                \u8fed\u4ee3 = bl15;
                String string2 = Build.TYPE;
                if (!Intrinsics.areEqual((Object)"eng", (Object)string2)) {
                    Intrinsics.areEqual((Object)"userdebug", (Object)string2);
                }
                Class[] arrclass = new Class[]{String.class, String.class};
                Class class_ = Class.forName((String)"android.os.SystemProperties");
                try {
                    Method method = class_.getDeclaredMethod("get", arrclass);
                    method.setAccessible(true);
                    \u81ea\u6d3d2 = new \u76ae\u5b9e(method);
                }
                catch (Exception exception) {
                    try {
                        \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
                    }
                    catch (Exception exception2) {
                        \u81ea\u6d3d2 = \u81ea\u6d3d.\u8d4b\u80fd;
                    }
                }
                $ExternalSyntheticLambda0 externalSyntheticLambda0 = new $ExternalSyntheticLambda0(\u81ea\u6d3d2);
                boolean bl16 = ((Boolean)externalSyntheticLambda0.invoke((Object)"ro.build.version.oplusrom")).booleanValue() || ((Boolean)externalSyntheticLambda0.invoke((Object)"oplus.device.firstboot")).booleanValue();
                \u4f18\u5316 = bl16;
                boolean bl17 = bl6 && (Boolean)externalSyntheticLambda0.invoke((Object)"ro.huawei.build.version.security_patch") != false;
                \u4ea4\u4ed8 = bl17;
                boolean bl18 = (Boolean)externalSyntheticLambda0.invoke((Object)"ro.build.version.magic");
                boolean bl19 = bl18 && !bl17;
                \u8ddf\u8fdb = bl19;
                if (bl18 || bl17) break block9;
                boolean bl20 = (Boolean)externalSyntheticLambda0.invoke((Object)"ro.build.version.emui");
                bl = false;
                if (!bl20) break block10;
            }
            bl = true;
        }
        \u5347\u7ea7 = bl;
    }

    public static final boolean \u8d4b\u80fd(\u81ea\u6d3d \u81ea\u6d3d2, String string2) {
        boolean bl;
        block6 : {
            String string3;
            block5 : {
                Object object;
                try {
                    object = \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, string2, "");
                    string3 = null;
                    if (object == null) break block5;
                }
                catch (Exception exception) {
                    return false;
                }
                string3 = object.toString();
            }
            if (string3 != null) {
                int n = string3.length();
                bl = false;
                if (n != 0) break block6;
            }
            bl = true;
        }
        return bl ^ true;
    }
}

