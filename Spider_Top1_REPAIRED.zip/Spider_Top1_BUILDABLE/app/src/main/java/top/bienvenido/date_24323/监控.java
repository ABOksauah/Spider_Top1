/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u76d1\u63a7$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u76d1\u63a7
extends \u89e6\u8fbe {
    public static final String[] \u8d4b\u80fd(Object object, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u6c89\u6dc0(((Number)object).intValue());
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        block4 : {
            object2 = arrobject[0];
            if (!\u6c34\u4f4d.\u8d4b\u80fd || !(object2 instanceof Integer)) return method.invoke(object, arrobject);
            if (!Intrinsics.areEqual((Object)object2, (Object)\u98ce\u53e3.\u4e2d\u53f0)) break block4;
            String[] arrstring = new String[]{\u6c34\u4f4d.\u6293\u624b};
            return arrstring;
        }
        String[] arrstring = (String[])\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u76d1\u63a7$$ExternalSyntheticLambda0(object2));
        if (arrstring == null) return method.invoke(object, arrobject);
        try {
            int n = arrstring.length;
            if (n == 0) return method.invoke(object, arrobject);
            return arrstring;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

