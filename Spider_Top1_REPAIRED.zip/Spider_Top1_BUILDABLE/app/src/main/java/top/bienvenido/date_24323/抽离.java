/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Provider
 *  android.content.pm.ProviderInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageParser;
import android.content.pm.ProviderInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u62bd\u79bb
extends MutablePropertyReference1Impl {
    public static final \u62bd\u79bb \u8d4b\u80fd = new \u62bd\u79bb();

    public \u62bd\u79bb() {
        super(PackageParser.Provider.class, "info", "getInfo()Landroid/content/pm/ProviderInfo;", 0);
    }

    public final Object get(Object object) {
        return ((PackageParser.Provider)object).info;
    }

    public final void set(Object object, Object object2) {
        ((PackageParser.Provider)object).info = (ProviderInfo)object2;
    }
}

