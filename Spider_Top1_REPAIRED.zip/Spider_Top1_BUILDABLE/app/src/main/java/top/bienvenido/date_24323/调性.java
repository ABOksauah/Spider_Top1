/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManagerNative
 *  android.util.Singleton
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.app.ActivityManager;
import android.app.ActivityManagerNative;
import android.util.Singleton;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u771f\u9999;

public abstract class \u8c03\u6027 {
    public static final Singleton \u8d4b\u80fd;

    static {
        Singleton singleton = \u62bd\u8c61.\u843d\u5730 ? (Singleton)\u771f\u9999.\u4e2d\u53f0(ActivityManager.class, "IActivityManagerSingleton") : (Singleton)\u771f\u9999.\u4e2d\u53f0(ActivityManagerNative.class, "gDefault");
        \u8d4b\u80fd = singleton;
    }
}

