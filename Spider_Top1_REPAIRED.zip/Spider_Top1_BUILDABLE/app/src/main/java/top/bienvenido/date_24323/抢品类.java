/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ParceledListSlice
 *  android.content.pm.ResolveInfo
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ParceledListSlice;
import android.content.pm.ResolveInfo;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u62c9\u65b0;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public abstract class \u62a2\u54c1\u7c7b
extends \u89e6\u8fbe {
    public static final List \u8d4b\u80fd(\u62a2\u54c1\u7c7b \u62a2\u54c1\u7c7b2, Object object, Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Object object2;
        Function4 function4 = \u62a2\u54c1\u7c7b2.\u6293\u624b();
        Intent intent = object instanceof Intent ? (Intent)object : null;
        if (intent == null) {
            return null;
        }
        Object object3 = arrobject[1];
        String string = null;
        if (object3 != null) {
            string = object3.toString();
        }
        int n = (object2 = arrobject[2]) instanceof Number ? ((Number)object2).intValue() : 0;
        return (List)function4.invoke((Object)\u94f8\u90202, (Object)intent, (Object)string, (Object)n);
    }

    public abstract Function4 \u6293\u624b();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object var1_1, Method var2_2, Object[] var3_3) {
        block12 : {
            try {
                var6_4 = var3_3[0];
                var7_5 = (List)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u62a2\u54c1\u7c7b$$ExternalSyntheticLambda0(this, var6_4, var3_3));
                if (var7_5 == null) {
                    var7_5 = Collections.EMPTY_LIST;
                }
                if ((var9_6 = \u660e\u786e.\u8d4b\u80fd(var2_2.invoke(var1_1, var3_3))) == null) {
                    var9_6 = Collections.EMPTY_LIST;
                }
                var10_7 = new ArrayList();
                var10_7.addAll((Collection)var7_5);
                if (var6_4 instanceof Intent && Intrinsics.areEqual((Object)((Intent)var6_4).getScheme(), (Object)"fbconnect")) {
                    if (var9_6 != null) {
                        var18_8 = var9_6.iterator();
                        break block12;
                    }
                } else if (var9_6 != null) {
                    var10_7.addAll((Collection)var9_6);
                }
                do {
                    var13_12 = var10_7.iterator();
                    do {
                        if (!var13_12.hasNext()) {
                            if (ParceledListSlice.class.isAssignableFrom(var2_2.getReturnType()) == false) return var10_7;
                            return \u660e\u786e.\u8d4b\u80fd((List)var10_7);
                        }
                        var16_13 = (ResolveInfo)var13_12.next();
                        \u6269\u5c55.\u8d4b\u80fd(((ComponentInfo)this.\u8d4b\u80fd().invoke((Object)var16_13)).applicationInfo);
                    } while (true);
                    break;
                } while (true);
            }
            catch (Exception var4_15) {
                if (ParceledListSlice.class.isAssignableFrom(var2_2.getReturnType()) == false) return Collections.EMPTY_LIST;
                return \u62c9\u65b0.\u8d4b\u80fd;
            }
        }
        do {
            if (!var18_8.hasNext()) ** continue;
            var19_9 = (ResolveInfo)var18_8.next();
            var20_10 = var19_9.activityInfo;
            var21_11 = var20_10 != null ? var20_10.packageName : null;
            if (!Intrinsics.areEqual((Object)var21_11, (Object)\u6c34\u4f4d.\u6293\u624b) || var10_7.size() > 1) ** continue;
            var10_7.add((Object)var19_9);
        } while (true);
    }

    public abstract Function1 \u8d4b\u80fd();
}

