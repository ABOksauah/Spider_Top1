/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ActivityInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5c0f\u767d
extends FunctionReferenceImpl
implements Function2 {
    public static final \u5c0f\u767d \u8d4b\u80fd = new \u5c0f\u767d();

    public \u5c0f\u767d() {
        super(2, \u94f8\u9020.class, "getReceiverInfo", "getReceiverInfo(Landroid/content/ComponentName;)Landroid/content/pm/ActivityInfo;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u95ed\u73af((ComponentName)object2);
    }
}

