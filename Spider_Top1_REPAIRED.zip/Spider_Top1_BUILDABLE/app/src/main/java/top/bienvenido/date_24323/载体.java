/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import java.util.ArrayList;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u8f7d\u4f53
extends FunctionReferenceImpl
implements Function2 {
    public static final \u8f7d\u4f53 \u8d4b\u80fd = new \u8f7d\u4f53();

    public \u8f7d\u4f53() {
        super(2, \u94f8\u9020.class, "getInstalledApplications", "getInstalledApplications(I)Ljava/util/List;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u843d\u5730(((Number)object2).intValue());
    }
}

