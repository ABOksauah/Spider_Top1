/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.manifest;

import kotlin.Metadata;
import top.bienvenido.date_24323.\u6d3c\u5730;

@Metadata(d1={"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"top/bienvenido/mundo/manifest/MundoProvider$Companion$STUB5", "Ltop/bienvenido/date_24323/\u6d3c\u5730;", "<init>", "()V", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MundoProvider$Companion$STUB5
extends \u6d3c\u5730 {
}

