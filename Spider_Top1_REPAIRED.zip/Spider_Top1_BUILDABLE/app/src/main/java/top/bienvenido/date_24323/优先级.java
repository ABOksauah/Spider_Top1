/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.UserHandle
 *  android.os.storage.StorageVolume
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function3
 *  kotlin.jvm.internal.Intrinsics
 *  sun.misc.Unsafe
 */
package top.bienvenido.date_24323;

import android.os.UserHandle;
import android.os.storage.StorageVolume;
import java.io.File;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u4f18\u5148\u7ea7
extends \u89e6\u53d1 {
    public static Function3 \u4e2d\u53f0;
    public static final \u4f18\u5148\u7ea7 \u6293\u624b;

    static {
        \u6293\u624b = new \u4f18\u5148\u7ea7();
        \u4e2d\u53f0 = new \u4f18\u5148\u7ea7$$ExternalSyntheticLambda2();
    }

    public static final Object \u6293\u624b(Object object, Method method, Object[] arrobject) {
        Object object2;
        block5 : {
            StorageVolume[] arrstorageVolume;
            block6 : {
                object2 = super.\u8d4b\u80fd(object, method, arrobject);
                if (!\u6c34\u4f4d.\u8d4b\u80fd || !(object2 instanceof Object[])) break block5;
                arrstorageVolume = (StorageVolume[])object2;
                if (arrstorageVolume.length != 0) break block6;
                return object2;
            }
            \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mPath");
            int n = arrstorageVolume.length;
            for (int i = 0; i < n; ++i) {
                try {
                    StorageVolume storageVolume = arrstorageVolume[i];
                    if (!Intrinsics.areEqual((Object)storageVolume.getState(), (Object)"mounted")) continue;
                    StorageVolume[] arrstorageVolume2 = new StorageVolume[]{storageVolume};
                    \u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u4f18\u5148\u7ea7$$ExternalSyntheticLambda0(\u81ea\u6d3d2, storageVolume, arrstorageVolume2));
                    return arrstorageVolume2;
                }
                catch (Throwable throwable) {
                    // empty catch block
                    break;
                }
            }
        }
        return object2;
    }

    public static final StorageVolume[] \u6293\u624b(StorageVolume[] arrstorageVolume, Object object, Method method, Object[] arrobject) {
        return arrstorageVolume;
    }

    public static final Unit \u8d4b\u80fd(\u81ea\u6d3d \u81ea\u6d3d2, StorageVolume storageVolume, StorageVolume[] arrstorageVolume, \u94f8\u9020 \u94f8\u90202) {
        String string = \u94f8\u90202.\u8fed\u4ee3(\u6c34\u4f4d.\u6293\u624b);
        if (string != null) {
            File file = new File(string);
            file.mkdirs();
            \u81ea\u6d3d2.\u8d4b\u80fd((Object)storageVolume, (Object)file);
            \u4e2d\u53f0 = new \u4f18\u5148\u7ea7$$ExternalSyntheticLambda3(arrstorageVolume);
        }
        return Unit.INSTANCE;
    }

    public static void \u8d4b\u80fd(String string) {
        try {
            Object object = \u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(StorageVolume.class);
            File file = new File(string);
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mPath").\u8d4b\u80fd(object, (Object)file);
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mInternalPath").\u8d4b\u80fd(object, (Object)file);
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mDescription").\u8d4b\u80fd(object, (Object)"external");
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mId").\u8d4b\u80fd(object, (Object)"0");
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mState").\u8d4b\u80fd(object, (Object)"mounted");
            \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mOwner").\u8d4b\u80fd(object, (Object)UserHandle.getUserHandleForUid((int)0));
            \u4e2d\u53f0 = new \u4f18\u5148\u7ea7$$ExternalSyntheticLambda1(new StorageVolume[]{object});
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final StorageVolume[] \u8d4b\u80fd(StorageVolume[] arrstorageVolume, Object object, Method method, Object[] arrobject) {
        return arrstorageVolume;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u4e2d\u53f0.invoke(object, (Object)method, (Object)arrobject);
    }
}

