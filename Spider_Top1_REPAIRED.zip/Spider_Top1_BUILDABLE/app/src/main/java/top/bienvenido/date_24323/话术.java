/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6784\u5efa;
import top.bienvenido.date_24323.\u6784\u7b51;

public final class \u8bdd\u672f
extends FunctionReferenceImpl
implements Function1 {
    public static final \u8bdd\u672f \u8d4b\u80fd = new \u8bdd\u672f();

    public \u8bdd\u672f() {
        super(1, \u6784\u5efa.class, "asInterface", "asInterface(Landroid/os/IBinder;)Ltop/bienvenido/mundo/IMundoWindowManagerService;", 0);
    }

    public final Object invoke(Object object) {
        IBinder iBinder = (IBinder)object;
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("MundoWindowManagerService");
        if (iInterface != null && iInterface instanceof \u5e03\u5c40) {
            return (\u5e03\u5c40)iInterface;
        }
        return new \u6784\u7b51(iBinder);
    }
}

