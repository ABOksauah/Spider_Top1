/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityClient
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RecentTaskInfo
 *  android.app.ActivityManager$RunningTaskInfo
 *  android.app.ActivityTaskManager
 *  android.app.IActivityManager
 *  android.app.TaskInfo
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.ConditionVariable
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.IInterface
 *  android.os.Parcelable
 *  android.util.Singleton
 *  android.widget.Toast
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.ref.Reference
 *  java.lang.ref.WeakReference
 *  java.lang.reflect.Constructor
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Deque
 *  java.util.Enumeration
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u8bae\u7a0b
 *  top.bienvenido.mundo.manifest.MundoService
 *  top.bienvenido.mundo.manifest.MundoService$Companion
 */
package top.bienvenido.date_24323;

import android.app.ActivityClient;
import android.app.ActivityManager;
import android.app.ActivityTaskManager;
import android.app.IActivityManager;
import android.app.TaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Binder;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcelable;
import android.util.Singleton;
import android.widget.Toast;
import java.io.Serializable;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0d\u53ef\u63a7;
import top.bienvenido.date_24323.\u4f53\u7cfb;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda10;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda11;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda12;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda13;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda14;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda15;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda16;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda17;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda18;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda19;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda20;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda21;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda4;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda5;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda6;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda7;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda8;
import top.bienvenido.date_24323.\u516c\u5173$$ExternalSyntheticLambda9;
import top.bienvenido.date_24323.\u52a9\u529b;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u5fc3\u529b;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6784\u5efa;
import top.bienvenido.date_24323.\u6fc0\u6d3b;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u805a\u5408;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u84dd\u6d77;
import top.bienvenido.date_24323.\u8bae\u7a0b;
import top.bienvenido.date_24323.\u8bb2\u6545\u4e8b;
import top.bienvenido.date_24323.\u8c03\u6027;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u9635\u5730;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u9ad8\u5730;
import top.bienvenido.mundo.common.initialize.MNative;
import top.bienvenido.mundo.manifest.MundoIntermediary;
import top.bienvenido.mundo.manifest.MundoService;
import top.bienvenido.mundo.manifest.MundoService$Companion$STUB;

public final class \u516c\u5173
extends \u6784\u5efa {
    public static final ConcurrentHashMap \u4e2d\u53f0;
    public static final Function1 \u54cd\u5e94;
    public static Function0 \u5e73\u53f0;
    public static final \u516c\u5173 \u6293\u624b;
    public static Function0 \u6c89\u6dc0;
    public static final Function1 \u6f0f\u6597;
    public static Function0 \u7ed9\u5230;
    public static final ActivityManager \u843d\u5730;
    public static final \u78b0\u4e00\u4e0b \u95ed\u73af;

    static {
        \u6293\u624b = new \u516c\u5173();
        \u4e2d\u53f0 = new ConcurrentHashMap();
        \u95ed\u73af = new \u78b0\u4e00\u4e0b();
        \u843d\u5730 = (ActivityManager)\u98ce\u53e3.\u8d4b\u80fd.getSystemService("activity");
        boolean bl = \u62bd\u8c61.\u5e73\u53f0;
        Object object = bl ? new \u516c\u5173$$ExternalSyntheticLambda17() : (\u62bd\u8c61.\u6c89\u6dc0 ? new \u516c\u5173$$ExternalSyntheticLambda18() : (\u62bd\u8c61.\u4e2d\u53f0 ? new \u516c\u5173$$ExternalSyntheticLambda19() : new \u516c\u5173$$ExternalSyntheticLambda20()));
        \u6f0f\u6597 = object;
        \u6c89\u6dc0 = new \u516c\u5173$$ExternalSyntheticLambda21();
        \u7ed9\u5230 = new \u516c\u5173$$ExternalSyntheticLambda1();
        \u5e73\u53f0 = new \u516c\u5173$$ExternalSyntheticLambda2();
        Object object2 = bl ? new \u516c\u5173$$ExternalSyntheticLambda3() : (\u62bd\u8c61.\u6c89\u6dc0 ? new \u516c\u5173$$ExternalSyntheticLambda4() : new \u516c\u5173$$ExternalSyntheticLambda5());
        \u54cd\u5e94 = object2;
    }

    public static final int \u4f18\u5316(IBinder iBinder) {
        return ActivityTaskManager.getService().getTaskForActivity(iBinder, false);
    }

    public static final Unit \u540c\u6b65(IBinder iBinder) {
        ((IActivityManager)\u8c03\u6027.\u8d4b\u80fd.get()).finishActivity(iBinder, 0, null, 0);
        return Unit.INSTANCE;
    }

    public static final void \u540c\u6b65() {
        try {
            Toast.makeText((Context)\u98ce\u53e3.\u8d4b\u80fd, (CharSequence)"SDK a\u00fan no est\u00e1 bien preparado, por favor espere hasta que est\u00e9 bien preparado. Puede ponerse en contacto con nuestro servicio de atenci\u00f3n al cliente para obtener m\u00e1s informaci\u00f3n. Correo electr\u00f3nico: help@62v.net", (int)1).show();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final Class \u54cd\u5e94() {
        Object object;
        try {
            object = MNative.\u8d4b\u80fd(61188, (Serializable)"5cc986ddbe0bc13f88e24c504b96d1110c503676f005773c2651c932582ec87d757531a0a2b970616faf54e0c9d95991");
        }
        catch (Throwable throwable) {
            object = null;
        }
        Class class_ = (Class)object;
        if (class_ != null) {
            \u5e73\u53f0 = new \u516c\u5173$$ExternalSyntheticLambda11(class_);
            return class_;
        }
        return IBinder.class;
    }

    public static final Unit \u54cd\u5e94(IBinder iBinder) {
        ActivityTaskManager.getService().finishActivity(iBinder, 0, null, 0);
        return Unit.INSTANCE;
    }

    public static final Unit \u5bf9\u6807(IBinder iBinder) {
        ActivityClient.getInstance().finishActivity(iBinder, 0, null, 0);
        return Unit.INSTANCE;
    }

    public static final Object \u5bf9\u9f50() {
        Object object;
        try {
            object = MNative.\u8d4b\u80fd(61188, (Serializable)"b80f5549d3fb49cbb5ced644e77f218fdb73df2526105f90deb5295bc9da52c4e0d82a382c4cbcc393c400008638ea7786be7d9dd0e4383cec1329bf07188c0080fc583c9b9606d90003e7f97ef971e767835806c3441d66322e947d1d77b60b");
        }
        catch (Throwable throwable) {
            object = null;
        }
        Serializable serializable = (Serializable)object;
        if (serializable != null) {
            \u7ed9\u5230 = new \u516c\u5173$$ExternalSyntheticLambda6(serializable);
            return serializable;
        }
        return new WeakReference(null);
    }

    public static final Unit \u5bf9\u9f50(IBinder iBinder) {
        ((IActivityManager)\u8c03\u6027.\u8d4b\u80fd.get()).finishActivity(iBinder, 0, null, false);
        return Unit.INSTANCE;
    }

    public static final Object \u5e73\u53f0() {
        Object object;
        try {
            object = MNative.\u8d4b\u80fd(61188, (Serializable)"b80f5549d3fb49cbb5ced644e77f218f6d0b5f1c2ea9534923e4d3dff02aad443131aea202790a307b4cc4f26563a722");
        }
        catch (Throwable throwable) {
            object = null;
        }
        Serializable serializable = (Serializable)object;
        if (serializable != null) {
            \u6c89\u6dc0 = new \u516c\u5173$$ExternalSyntheticLambda8(serializable);
            return serializable;
        }
        return new WeakReference(null);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u5e73\u53f0(IBinder iBinder) {
        \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)\u4e2d\u53f0.remove((Object)iBinder));
        if (\u5fc3\u529b2 == null) return;
        try {
            \u5fc3\u529b2.\u4e2d\u53f0.\u8fed\u4ee3.remove((Object)\u5fc3\u529b2);
            \u6293\u624b.getClass();
            \u516c\u5173.\u8d4b\u80fd(\u5fc3\u529b2);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static ActivityManager.RunningTaskInfo \u6293\u624b(Deque deque) {
        ActivityManager.RunningTaskInfo runningTaskInfo = new ActivityManager.RunningTaskInfo();
        \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)deque.peekFirst());
        runningTaskInfo.id = \u5fc3\u529b2.\u6c89\u6dc0;
        runningTaskInfo.baseActivity = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u5fc3\u529b2.\u8d4b\u80fd);
        runningTaskInfo.topActivity = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)((\u5fc3\u529b)deque.peekLast()).\u8d4b\u80fd);
        runningTaskInfo.numActivities = 1;
        if (\u62bd\u8c61.\u6c89\u6dc0) {
            runningTaskInfo.taskId = \u5fc3\u529b2.\u6c89\u6dc0;
            runningTaskInfo.baseIntent = \u5fc3\u529b2.\u95ed\u73af;
            runningTaskInfo.isRunning = true;
            if (\u62bd\u8c61.\u7ed9\u5230) {
                \u4e0d\u53ef\u63a7.\u6293\u624b.\u8d4b\u80fd((Object)runningTaskInfo, \u4e0d\u53ef\u63a7.\u8d4b\u80fd.invoke());
                if (\u62bd\u8c61.\u5e73\u53f0) {
                    \u4e0d\u53ef\u63a7.\u4e2d\u53f0.\u8d4b\u80fd((Object)runningTaskInfo, (Object)Boolean.TRUE);
                }
            }
        }
        return runningTaskInfo;
    }

    public static final Serializable \u6293\u624b(Serializable serializable) {
        return serializable;
    }

    public static String \u6293\u624b(ActivityInfo activityInfo) {
        int n = activityInfo.launchMode;
        if (n != 3 && n != 4) {
            String string = activityInfo.taskAffinity;
            if (string == null && (string = activityInfo.applicationInfo.taskAffinity) == null) {
                return activityInfo.packageName;
            }
            return string;
        }
        return activityInfo.name;
    }

    public static Pair \u6293\u624b(List list) {
        ActivityInfo activityInfo;
        boolean bl;
        block1 : {
            bl = false;
            ResolveInfo resolveInfo = (ResolveInfo)list.get(0);
            activityInfo = resolveInfo.activityInfo;
            if (list.size() == 1) break block1;
            ResolveInfo resolveInfo2 = (ResolveInfo)list.get(1);
            if (resolveInfo.priority == resolveInfo2.priority && resolveInfo.isDefault == resolveInfo2.isDefault) {
                bl = true;
            }
        }
        return TuplesKt.to((Object)activityInfo, (Object)bl);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u6293\u624b(ActivityInfo activityInfo, String string, String string2) {
        try {
            if (!\u4f53\u7cfb.\u8d4b\u80fd()) {
                if (!\u62bd\u8c61.\u6f0f\u6597) return;
                {
                    \u98ce\u53e3.\u8d4b\u80fd.getMainExecutor().execute((Runnable)new \u516c\u5173$$ExternalSyntheticLambda0());
                    return;
                }
            } else {
                \u6293\u624b.getClass();
                Class class_ = (Class)\u5e73\u53f0.invoke();
                if (activityInfo == null && (activityInfo = \u84dd\u6d77.\u8d4b\u80fd(string)) == null) {
                    return;
                }
                \u54c1\u724c \u54c1\u724c2 = \u9ad8\u5730.\u6293\u624b(string, activityInfo.processName, string2);
                if (\u54c1\u724c2 == null) {
                    return;
                }
                Constructor constructor = class_.getConstructor(new Class[]{class_});
                Intent intent = ((Intent)class_.getConstructor(new Class[]{String.class}).newInstance(new Object[]{(Serializable)\u4f53\u7cfb.\u95ed\u73af("0276a1615185e03ac1af12b79a0d34ed572f5ae2f997205e08683daf2dc45b54570d4b0a8c17ebd26fd2ea20b9819401")})).addCategory(String.valueOf((Object)\u4f53\u7cfb.\u8d4b\u80fd("86042823c6197eb33d7d6a65a627469dbc3e90f2e24632ce62e945fd50b021f349739fa7459ed5d10d2846c028afe34d")));
                Serializable serializable = (Serializable)\u4f53\u7cfb.\u95ed\u73af("b80f5549d3fb49cbb5ced644e77f218fdb73df2526105f90deb5295bc9da52c4e0d82a382c4cbcc393c400008638ea7786be7d9dd0e4383cec1329bf07188c009d4ed1f8ad2b0d8541431e54471f051367835806c3441d66322e947d1d77b60b");
                int n = serializable instanceof Number ? ((Number)serializable).intValue() : 0;
                Intent intent2 = \u516c\u5173.\u8d4b\u80fd(null, (Intent)constructor.newInstance(new Object[]{intent.addFlags(n)}), \u54c1\u724c2, activityInfo, false);
                if (intent2 == null || !\u54c1\u724c2.\u6c89\u6dc0) return;
                {
                    Context context = \u98ce\u53e3.\u8d4b\u80fd;
                    Serializable serializable2 = (Serializable)\u4f53\u7cfb.\u95ed\u73af("b80f5549d3fb49cbb5ced644e77f218fdb73df2526105f90deb5295bc9da52c4e0d82a382c4cbcc393c400008638ea7786be7d9dd0e4383cec1329bf07188c005b9514b07755c8993b66363890079bd567835806c3441d66322e947d1d77b60b");
                    boolean bl = serializable2 instanceof Number;
                    int n2 = 0;
                    if (bl) {
                        n2 = ((Number)serializable2).intValue();
                    }
                    context.startActivity(intent2.addFlags(n2));
                    return;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static final void \u6293\u624b(IBinder iBinder, IBinder iBinder2) {
        Object object;
        ((\u5fc3\u529b)iBinder).\u4e2d\u53f0.\u8fed\u4ee3.add((Object)iBinder);
        boolean bl = iBinder2 != null;
        if (!Intrinsics.areEqual((Object)bl, (Object)\u6c89\u6dc0.invoke())) return;
        ((\u5fc3\u529b)iBinder).\u6f0f\u6597 = iBinder2;
        ConcurrentHashMap concurrentHashMap = \u4e2d\u53f0;
        if (iBinder2 == null) {
            return;
        }
        concurrentHashMap.put((Object)iBinder2, (Object)iBinder);
        int n = ((\u5fc3\u529b)iBinder).\u6c89\u6dc0;
        if (n == -1) {
            \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)iBinder;
            Object object2 = \u54cd\u5e94.invoke((Object)iBinder2);
            int n2 = ((Number)object2).intValue();
            \u5fc3\u529b2.\u6c89\u6dc0 = ((Number)object2).intValue();
            if (n2 == -1) {
                return;
            }
            n = n2;
        }
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u95ed\u73af;
        \u8bae\u7a0b \u8bae\u7a0b2 = \u8bae\u7a0b.\u8d4b\u80fd;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd;
        int[] arrn = \u6241\u5e73\u53162.\u8d4b\u80fd;
        int n3 = \u6241\u5e73\u53162.\u4e2d\u53f0;
        int n4 = \u753b\u997c.\u8d4b\u80fd(arrn, n3, n);
        if (n4 >= 0) {
            object = \u6241\u5e73\u53162.\u6293\u624b[n4];
        } else {
            int n5;
            int n6 = n4;
            \u6241\u5e73\u53162.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n3, n6, n);
            \u6241\u5e73\u53162.\u4e2d\u53f0 = n5 = n3 + 1;
            Object object3 = \u8bae\u7a0b2.invoke();
            Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
            if (n5 <= arrobject.length) {
                System.arraycopy((Object)arrobject, (int)n6, (Object)arrobject, (int)(n6 + 1), (int)(n3 - n6));
                arrobject[n6] = object3;
            } else {
                Object[] arrobject2 = new Object[(n3 | 1) << 1];
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n6);
                arrobject2[n6] = object3;
                System.arraycopy((Object)arrobject, (int)n6, (Object)arrobject2, (int)(n6 + 1), (int)(arrobject.length - n6));
                arrobject = arrobject2;
            }
            \u6241\u5e73\u53162.\u6293\u624b = arrobject;
            object = object3;
        }
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        try {
            Deque deque;
            ((\u5fc3\u529b)iBinder).\u7ed9\u5230 = deque = (Deque)object;
            ((Deque)object).addLast((Object)iBinder);
            return;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u6293\u624b(\u54c1\u724c \u54c1\u724c2) {
        try {
            Iterator iterator = \u54c1\u724c2.\u8fed\u4ee3.iterator();
            while (iterator.hasNext()) {
                \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)iterator.next());
                IBinder iBinder = \u5fc3\u529b2.\u6f0f\u6597;
                if (iBinder != null) {
                    (\u5fc3\u529b)((Object)\u4e2d\u53f0.remove((Object)iBinder));
                }
                \u6293\u624b.getClass();
                \u516c\u5173.\u8d4b\u80fd(\u5fc3\u529b2);
            }
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u6f0f\u6597(Intent intent, String string) {
        Context context;
        Intent intent2;
        Object object;
        block9 : {
            try {
                \u6293\u624b.getClass();
                Pair pair = \u516c\u5173.\u8d4b\u80fd(intent);
                if (pair == null) {
                    return;
                }
                context = \u98ce\u53e3.\u8d4b\u80fd;
                boolean bl = (Boolean)pair.getSecond();
                object = null;
                if (bl) {
                    Intent intent3 = (Intent)((Class)\u5e73\u53f0.invoke()).getConstructor(new Class[]{(Class)\u5e73\u53f0.invoke()}).newInstance(new Object[]{intent});
                    Intent intent4 = new Intent(context, MundoIntermediary.class);
                    Bundle bundle = new Bundle();
                    bundle.putParcelable("android.intent.extra.INTENT", (Parcelable)intent3);
                    if (string != null) {
                        bundle.putString(String.class.getName(), string);
                    }
                    intent2 = intent4.putExtras(bundle);
                    break block9;
                }
                intent2 = \u516c\u5173.\u8d4b\u80fd(intent, string, null, (ActivityInfo)pair.getFirst());
                if (intent2 != null) break block9;
                return;
            }
            catch (Exception exception) {
                return;
            }
        }
        try {
            object = MNative.\u8d4b\u80fd(61188, (Serializable)"b80f5549d3fb49cbb5ced644e77f218fdb73df2526105f90deb5295bc9da52c4e0d82a382c4cbcc393c400008638ea7786be7d9dd0e4383cec1329bf07188c005b9514b07755c8993b66363890079bd567835806c3441d66322e947d1d77b60b");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        Serializable serializable = (Serializable)object;
        boolean bl = serializable instanceof Number;
        int n = 0;
        if (bl) {
            n = ((Number)serializable).intValue();
        }
        context.startActivity(intent2.addFlags(n));
    }

    public static ActivityManager.RecentTaskInfo \u8d4b\u80fd(Deque deque) {
        int n;
        ActivityManager.RecentTaskInfo recentTaskInfo = new ActivityManager.RecentTaskInfo();
        \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)deque.peekFirst());
        recentTaskInfo.id = n = \u5fc3\u529b2.\u6c89\u6dc0;
        recentTaskInfo.persistentId = n;
        recentTaskInfo.affiliatedTaskId = n;
        recentTaskInfo.baseIntent = \u5fc3\u529b2.\u95ed\u73af;
        if (\u62bd\u8c61.\u6293\u624b) {
            recentTaskInfo.numActivities = 1;
            recentTaskInfo.baseActivity = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u5fc3\u529b2.\u8d4b\u80fd);
            recentTaskInfo.topActivity = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)((\u5fc3\u529b)deque.peekLast()).\u8d4b\u80fd);
            if (\u62bd\u8c61.\u6c89\u6dc0) {
                recentTaskInfo.isRunning = true;
                if (\u62bd\u8c61.\u7ed9\u5230) {
                    \u4e0d\u53ef\u63a7.\u6293\u624b.\u8d4b\u80fd((Object)recentTaskInfo, \u4e0d\u53ef\u63a7.\u8d4b\u80fd.invoke());
                    if (\u62bd\u8c61.\u5e73\u53f0) {
                        \u4e0d\u53ef\u63a7.\u4e2d\u53f0.\u8d4b\u80fd((Object)recentTaskInfo, (Object)Boolean.TRUE);
                    }
                }
            }
        }
        return recentTaskInfo;
    }

    public static Intent \u8d4b\u80fd(Intent intent, String string, IBinder iBinder, ActivityInfo activityInfo) {
        block13 : {
            ActivityInfo activityInfo2;
            \u54c1\u724c \u54c1\u724c2;
            block14 : {
                Class class_;
                Object object;
                boolean bl;
                block12 : {
                    block11 : {
                        Object object2 = MNative.\u8d4b\u80fd(61181, null);
                        if (object2 == null) break block11;
                        try {
                            bl = Boolean.parseBoolean((String)object2.toString());
                            break block12;
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    bl = false;
                }
                if (!bl) {
                    return null;
                }
                try {
                    object = MNative.\u8d4b\u80fd(61188, (Serializable)"9250221494edbb8ddfe1dbf7cfaadd434a4998ebe11d84b8fcf5af24b0b335eb4f9c545fa077c370ded70f3ff9b6d60681a71ac9e4c8be08955f57aaa83f011e");
                }
                catch (Throwable throwable) {
                    object = null;
                }
                try {
                    class_ = (Class)object;
                    if (class_ == null) break block13;
                }
                catch (Exception exception) {
                    return null;
                }
                activityInfo2 = (ActivityInfo)class_.getConstructor(new Class[]{class_}).newInstance(new Object[]{activityInfo});
                if (activityInfo2 == null) break block13;
                \u54c1\u724c2 = \u9ad8\u5730.\u6293\u624b(activityInfo2.packageName, activityInfo2.processName, string);
                if (\u54c1\u724c2 != null) break block14;
                return null;
            }
            Class class_ = (Class)\u5e73\u53f0.invoke();
            Intent intent2 = (Intent)class_.getConstructor(new Class[]{class_}).newInstance(new Object[]{\u516c\u5173.\u8d4b\u80fd(iBinder, intent, \u54c1\u724c2, activityInfo2, false)});
            return intent2;
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    public static Intent \u8d4b\u80fd(IBinder var0, Intent var1_1, \u54c1\u724c var2_2, ActivityInfo var3_3, boolean var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 34[SIMPLE_IF_TAKEN]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        // java.lang.Thread.run(Thread.java:1571)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Intent \u8d4b\u80fd(IBinder iBinder, Intent intent, \u54c1\u724c \u54c1\u724c2, boolean bl) {
        Pair pair;
        block4 : {
            try {
                pair = \u516c\u5173.\u8d4b\u80fd(intent);
                if (pair != null) break block4;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        if ((Boolean)pair.getSecond() == false) return \u516c\u5173.\u8d4b\u80fd(iBinder, intent, \u54c1\u724c2, (ActivityInfo)pair.getFirst(), bl);
        String string = \u54c1\u724c2.\u4e2d\u53f0;
        Intent intent2 = new Intent(\u98ce\u53e3.\u8d4b\u80fd, MundoIntermediary.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.intent.extra.INTENT", (Parcelable)intent);
        if (string == null) return intent2.putExtras(bundle);
        bundle.putString(String.class.getName(), string);
        return intent2.putExtras(bundle);
    }

    public static final ActivityInfo \u8d4b\u80fd(ComponentName componentName, PackageManager packageManager) {
        return packageManager.getActivityInfo(componentName, 512);
    }

    public static final Serializable \u8d4b\u80fd(Serializable serializable) {
        return serializable;
    }

    public static final Class \u8d4b\u80fd(Class class_) {
        return class_;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static ArrayList \u8d4b\u80fd(int n, boolean bl, int n2) {
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        int n3;
        \u54c1\u724c \u54c1\u724c2;
        ArrayList arrayList;
        block9 : {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
            arrayList = new ArrayList();
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
            Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
            // MONITOREXIT : \u78b0\u4e00\u4e0b3
            try {
                \u54c1\u724c2 = (\u54c1\u724c)object;
                if (\u54c1\u724c2 == null) {
                    return arrayList;
                }
                \u6241\u5e73\u53162 = \u516c\u5173.\u95ed\u73af.\u8d4b\u80fd;
                n3 = 0;
                break block9;
            }
            catch (Exception exception) {
                // empty catch block
            }
            return arrayList;
        }
        do {
            boolean bl2 = n3 < \u6241\u5e73\u53162.\u4e2d\u53f0;
            if (!bl2) return arrayList;
            Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
            int n4 = n3 + 1;
            Deque deque = (Deque)arrobject[n3];
            \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)deque.peekFirst());
            if (\u5fc3\u529b2 != null && Intrinsics.areEqual((Object)\u54c1\u724c2.\u4e2d\u53f0, (Object)\u5fc3\u529b2.\u4e2d\u53f0.\u4e2d\u53f0) && Intrinsics.areEqual((Object)\u54c1\u724c2.\u8d4b\u80fd, (Object)\u5fc3\u529b2.\u4e2d\u53f0.\u8d4b\u80fd) && (bl || !\u6253\u78e8.\u8d4b\u80fd(\u5fc3\u529b2.\u95ed\u73af.getFlags(), 8388608))) {
                arrayList.add((Object)deque);
                if (arrayList.size() >= n2) {
                    return arrayList;
                }
            }
            n3 = n4;
        } while (true);
    }

    public static final List \u8d4b\u80fd(Intent intent, PackageManager packageManager) {
        return packageManager.queryIntentActivities(intent, 65536);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Pair \u8d4b\u80fd(Intent intent) {
        try {
            Object object = intent.getComponent();
            if (object == null) {
                Intent intent2 = intent.getSelector();
                object = intent2 != null ? intent2.getComponent() : null;
            }
            if (object != null) {
                \u8fb9\u754c.\u6293\u624b.getClass();
                ActivityInfo activityInfo = (ActivityInfo)\u8fb9\u754c.\u6f0f\u6597(object);
                if (activityInfo == null) {
                    String string = object.getPackageName();
                    if (!\u8fb9\u754c.\u95ed\u73af.containsKey(string)) return null;
                    activityInfo = (ActivityInfo)\u98ce\u53e3.\u8d4b\u80fd(new \u516c\u5173$$ExternalSyntheticLambda10((ComponentName)object));
                }
                if (activityInfo == null) return null;
                return TuplesKt.to((Object)activityInfo, (Object)Boolean.FALSE);
            }
            List list = \u8fb9\u754c.\u6293\u624b.\u4e2d\u53f0(intent, null, 65536);
            if (!list.isEmpty()) {
                \u516c\u5173 \u516c\u51732 = \u6293\u624b;
                List list2 = \u6253\u78e8.\u8d4b\u80fd(list);
                \u516c\u51732.getClass();
                return \u516c\u5173.\u6293\u624b(list2);
            }
            List list3 = (List)\u98ce\u53e3.\u8d4b\u80fd(new \u516c\u5173$$ExternalSyntheticLambda12(intent));
            if (list3 == null) return null;
            Iterator iterator = list3.iterator();
            while (iterator.hasNext()) {
                ResolveInfo resolveInfo = (ResolveInfo)iterator.next();
                \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
                String string = resolveInfo.activityInfo.packageName;
                \u8fb9\u754c2.getClass();
                if (\u8fb9\u754c.\u95ed\u73af.containsKey(string)) continue;
                iterator.remove();
            }
            if (list3.isEmpty()) return null;
            \u6293\u624b.getClass();
            return \u516c\u5173.\u6293\u624b(list3);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static void \u8d4b\u80fd(ActivityInfo activityInfo, String string, String string2) {
        \u516c\u5173$$ExternalSyntheticLambda9 \u516c\u5173$$ExternalSyntheticLambda9 = new \u516c\u5173$$ExternalSyntheticLambda9(activityInfo, string, string2);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda9);
    }

    public static final void \u8d4b\u80fd(String string, ActivityInfo activityInfo, String string2) {
        try {
            \u9ad8\u5730.\u8d4b\u80fd(string, activityInfo.processName, string2);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static void \u8d4b\u80fd(ArrayList arrayList) {
        try {
            for (\u5fc3\u529b \u5fc3\u529b2 : arrayList) {
                \u6f0f\u6597.invoke((Object)\u5fc3\u529b2.\u6f0f\u6597);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static void \u8d4b\u80fd(\u54c1\u724c \u54c1\u724c2) {
        \u516c\u5173$$ExternalSyntheticLambda14 \u516c\u5173$$ExternalSyntheticLambda14 = new \u516c\u5173$$ExternalSyntheticLambda14(\u54c1\u724c2);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda14);
    }

    public static void \u8d4b\u80fd(\u5fc3\u529b \u5fc3\u529b2) {
        Deque deque = \u5fc3\u529b2.\u7ed9\u5230;
        if (deque != null && deque.removeLastOccurrence((Object)\u5fc3\u529b2) && deque.isEmpty()) {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u95ed\u73af;
            int n = \u5fc3\u529b2.\u6c89\u6dc0;
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2;
            synchronized (\u78b0\u4e00\u4e0b3) {
                \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u6293\u624b(n);
                return;
            }
        }
    }

    public static boolean \u8d4b\u80fd(ActivityInfo activityInfo) {
        int n = activityInfo.launchMode;
        boolean bl = 2 <= n && n < 5;
        return Intrinsics.areEqual((Object)bl, (Object)\u6c89\u6dc0.invoke());
    }

    public static final int \u8ddf\u8fdb(IBinder iBinder) {
        return ((IActivityManager)\u8c03\u6027.\u8d4b\u80fd.get()).getTaskForActivity(iBinder, false);
    }

    public static final int \u8fed\u4ee3(IBinder iBinder) {
        return ActivityClient.getInstance().getTaskForActivity(iBinder, false);
    }

    @Override
    public final void \u4e2d\u53f0(String string) {
        if (string != null) {
            if (string.length() == 0) {
                return;
            }
            \u4f53\u7cfb.\u6293\u624b(string);
        }
    }

    @Override
    public final boolean \u4e2d\u53f0() {
        Object object;
        block3 : {
            try {
                object = MNative.\u8d4b\u80fd(61181, null);
                if (object != null) break block3;
                return false;
            }
            catch (Throwable throwable) {
                return false;
            }
        }
        boolean bl = Boolean.parseBoolean((String)object.toString());
        return bl;
    }

    @Override
    public final boolean \u6293\u624b(String string, String string2) {
        ActivityInfo activityInfo;
        boolean bl;
        block10 : {
            block9 : {
                block8 : {
                    try {
                        activityInfo = \u84dd\u6d77.\u8d4b\u80fd(string);
                        if (activityInfo != null) break block8;
                        return false;
                    }
                    catch (Exception exception) {
                        return false;
                    }
                }
                String string3 = activityInfo.processName;
                try {
                    \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u95ed\u73af;
                    int n = string3.hashCode() + string2.hashCode();
                    \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd;
                    int n2 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n);
                    if (n2 < 0) break block9;
                    bl = true;
                    break block10;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            bl = false;
        }
        if (bl) {
            \u516c\u5173.\u8d4b\u80fd(activityInfo, string, string2);
            return true;
        }
        \u516c\u5173$$ExternalSyntheticLambda7 \u516c\u5173$$ExternalSyntheticLambda7 = new \u516c\u5173$$ExternalSyntheticLambda7(string, activityInfo, string2);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda7);
        return false;
    }

    @Override
    public final void \u6c89\u6dc0(String string, String string2) {
        \u516c\u5173.\u8d4b\u80fd(null, string, string2);
    }

    @Override
    public final void \u6f0f\u6597(IBinder iBinder) {
        \u516c\u5173$$ExternalSyntheticLambda15 \u516c\u5173$$ExternalSyntheticLambda15 = new \u516c\u5173$$ExternalSyntheticLambda15(iBinder);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda15);
    }

    public final boolean \u6f0f\u6597(String string, String string2) {
        ActivityInfo activityInfo;
        block6 : {
            try {
                activityInfo = \u84dd\u6d77.\u8d4b\u80fd(string);
                if (activityInfo != null) break block6;
                return false;
            }
            catch (Exception exception) {
                return false;
            }
        }
        String string3 = activityInfo.processName;
        try {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u95ed\u73af;
            int n = string3.hashCode() + string2.hashCode();
            \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd;
            int n2 = \u753b\u997c.\u8d4b\u80fd(\u6241\u5e73\u53162.\u8d4b\u80fd, \u6241\u5e73\u53162.\u4e2d\u53f0, n);
            if (n2 >= 0) {
                return true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return false;
    }

    @Override
    public final String \u7ed9\u5230(IBinder iBinder) {
        block5 : {
            \u5fc3\u529b \u5fc3\u529b2;
            try {
                \u5fc3\u529b2 = (\u5fc3\u529b)((Object)\u4e2d\u53f0.get((Object)iBinder));
                if (\u5fc3\u529b2 == null) break block5;
            }
            catch (Exception exception) {
                return null;
            }
            Reference reference = \u5fc3\u529b2.\u6293\u624b;
            if (reference == null) break block5;
            \u5fc3\u529b \u5fc3\u529b3 = (\u5fc3\u529b)((Object)reference.get());
            if (\u5fc3\u529b3 == null) break block5;
            String string = \u5fc3\u529b3.\u4e2d\u53f0.\u8d4b\u80fd;
            return string;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void \u843d\u5730(String string, String string2) {
        try {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = CollectionsKt.iterator((Enumeration)\u4e2d\u53f0.elements());
            do {
                if (!iterator.hasNext()) {
                    \u516c\u5173.\u8d4b\u80fd(arrayList);
                    return;
                }
                \u5fc3\u529b \u5fc3\u529b2 = (\u5fc3\u529b)((Object)iterator.next());
                if (string != null && !Intrinsics.areEqual((Object)\u5fc3\u529b2.\u4e2d\u53f0.\u8d4b\u80fd, (Object)string) || string2 != null && string2.length() != 0 && !Intrinsics.areEqual((Object)string2, (Object)\u5fc3\u529b2.\u8d4b\u80fd.name)) continue;
                arrayList.add((Object)\u5fc3\u529b2);
            } while (true);
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public final ComponentName \u8d4b\u80fd(IBinder iBinder) {
        block6 : {
            \u5fc3\u529b \u5fc3\u529b2;
            block5 : {
                try {
                    \u5fc3\u529b2 = (\u5fc3\u529b)((Object)\u4e2d\u53f0.get((Object)iBinder));
                    if (\u5fc3\u529b2 != null) break block5;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            Reference reference = \u5fc3\u529b2.\u6293\u624b;
            if (reference == null) break block6;
            \u5fc3\u529b \u5fc3\u529b3 = (\u5fc3\u529b)((Object)reference.get());
            if (\u5fc3\u529b3 == null) break block6;
            ComponentName componentName = \u6253\u78e8.\u8d4b\u80fd((ComponentInfo)\u5fc3\u529b3.\u8d4b\u80fd);
            return componentName;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final Intent \u8d4b\u80fd(long l, Intent intent) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        int n = (int)((-4294967296L & l) >>> 32);
        int n2 = (int)(l & 0xFFFFFFFFL);
        try {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return null;
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n2);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        String string = \u54c1\u724c2 != null ? \u54c1\u724c2.\u4e2d\u53f0 : null;
        if (n == 1) return \u805a\u5408.\u8d4b\u80fd(intent, string);
        if (n == 2) {
            Intent intent2 = new Intent(\u98ce\u53e3.\u8d4b\u80fd, MundoIntermediary.class);
            Bundle bundle = new Bundle();
            bundle.putParcelable("android.intent.extra.INTENT", (Parcelable)intent);
            if (string == null) return intent2.putExtras(bundle);
            bundle.putString(String.class.getName(), string);
            return intent2.putExtras(bundle);
        }
        if (n != 4) {
            if (n != 5) return null;
        }
        Intent intent3 = new Intent().setComponent(new ComponentName(\u98ce\u53e3.\u6293\u624b, MundoService.Companion.STUB.class.getName())).putExtra("android.intent.extra.INTENT", (Parcelable)intent);
        if (string == null) return intent3;
        intent3.putExtra("user", string);
        return intent3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Intent \u8d4b\u80fd(IBinder iBinder, Intent intent, int n, boolean bl) {
        Object object;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
        synchronized (\u78b0\u4e00\u4e0b3) {
            object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        }
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        if (\u54c1\u724c2 == null) {
            return null;
        }
        return \u516c\u5173.\u8d4b\u80fd(iBinder, intent, \u54c1\u724c2, bl);
    }

    @Override
    public final String \u8d4b\u80fd() {
        try {
            String string = String.valueOf((Object)MNative.\u8d4b\u80fd(61186, null));
            return string;
        }
        catch (Throwable throwable) {
            return "";
        }
    }

    @Override
    public final List \u8d4b\u80fd(long l) {
        int n = (int)((-4294967296L & l) >>> 32);
        int n2 = (int)(l & 0xFFFFFFFFL);
        try {
            ArrayList arrayList = \u516c\u5173.\u8d4b\u80fd(n2, true, n);
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                arrayList2.add((Object)\u516c\u5173.\u6293\u624b((Deque)iterator.next()));
            }
            return arrayList2;
        }
        catch (Exception exception) {
            return Collections.EMPTY_LIST;
        }
    }

    @Override
    public final List \u8d4b\u80fd(long l, int n) {
        int n2 = (int)((-4294967296L & l) >>> 32);
        boolean bl = (8388608 & (int)(l & 0xFFFFFFFFL)) != 0;
        try {
            ArrayList arrayList = \u516c\u5173.\u8d4b\u80fd(n, bl, n2);
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                arrayList2.add((Object)\u516c\u5173.\u8d4b\u80fd((Deque)iterator.next()));
            }
            return arrayList2;
        }
        catch (Exception exception) {
            return Collections.EMPTY_LIST;
        }
    }

    @Override
    public final void \u8d4b\u80fd(Intent intent, String string) {
        \u516c\u5173$$ExternalSyntheticLambda16 \u516c\u5173$$ExternalSyntheticLambda16 = new \u516c\u5173$$ExternalSyntheticLambda16(intent, string);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda16);
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, IBinder iBinder2) {
        if (!(iBinder2 instanceof \u5fc3\u529b)) {
            return;
        }
        \u516c\u5173$$ExternalSyntheticLambda13 \u516c\u5173$$ExternalSyntheticLambda13 = new \u516c\u5173$$ExternalSyntheticLambda13(iBinder2, iBinder);
        \u964d\u7ea7.\u8d4b\u80fd.execute((Runnable)\u516c\u5173$$ExternalSyntheticLambda13);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, String string2, String string3, int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        if (object != null) return;
        try {
            void var16_16;
            int n2 = Binder.getCallingPid();
            \u8fb9\u754c.\u6293\u624b.getClass();
            boolean bl = \u8fb9\u754c.\u4e2d\u53f0.containsKey(string);
            int n3 = \u84dd\u6d77.\u8d4b\u80fd(string, bl);
            \u54c1\u724c \u54c1\u724c2 = new \u54c1\u724c(string, string2, string3, bl, n, n3);
            iBinder.linkToDeath((IBinder.DeathRecipient)new \u9635\u5730(iBinder, \u54c1\u724c2), 0);
            \u78b0\u4e00\u4e0b2.\u8d4b\u80fd(n, \u54c1\u724c2);
            \u54c1\u724c2.\u5e73\u53f0 = n2;
            \u9ad8\u5730.\u4e2d\u53f0.\u8d4b\u80fd(n2, \u54c1\u724c2);
            \u9ad8\u5730.\u95ed\u73af.\u8d4b\u80fd(string2.hashCode() + string3.hashCode(), \u54c1\u724c2);
            \u54c1\u724c2.\u54cd\u5e94.open();
            IInterface iInterface = iBinder.queryLocalInterface("MundoAppThread");
            if (iInterface != null && iInterface instanceof \u6fc0\u6d3b) {
                \u6fc0\u6d3b \u6fc0\u6d3b2 = (\u6fc0\u6d3b)iInterface;
            } else {
                \u52a9\u529b \u52a9\u529b2 = new \u52a9\u529b(iBinder);
            }
            \u54c1\u724c2.\u7ed9\u5230 = var16_16;
            if (\u9ad8\u5730.\u6f0f\u6597 != n) return;
            \u9ad8\u5730.\u6f0f\u6597 = 0;
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final Intent[] \u8d4b\u80fd(IBinder iBinder, Intent[] arrintent, int n) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        if (arrintent == null) {
            return null;
        }
        try {
            \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u6293\u624b;
            // MONITORENTER : \u78b0\u4e00\u4e0b3
        }
        catch (Exception exception) {
            return null;
        }
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        \u54c1\u724c \u54c1\u724c2 = (\u54c1\u724c)object;
        if (\u54c1\u724c2 == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(arrintent.length);
        int n2 = arrintent.length;
        int n3 = 0;
        while (n3 < n2) {
            Intent intent = \u516c\u5173.\u8d4b\u80fd(iBinder, arrintent[n3], \u54c1\u724c2, false);
            if (intent != null) {
                arrayList.add((Object)intent);
            }
            ++n3;
        }
        return (Intent[])arrayList.toArray((Object[])new Intent[0]);
    }

    @Override
    public final boolean \u95ed\u73af(IBinder iBinder) {
        if (iBinder != null) {
            \u5fc3\u529b \u5fc3\u529b2;
            ArrayList arrayList;
            Deque deque;
            block10 : {
                block9 : {
                    \u5fc3\u529b2 = (\u5fc3\u529b)((Object)\u4e2d\u53f0.get((Object)iBinder));
                    if (\u5fc3\u529b2 != null) break block9;
                    return false;
                }
                arrayList = new ArrayList();
                deque = \u5fc3\u529b2.\u7ed9\u5230;
                if (deque != null) break block10;
                return false;
            }
            try {
                Iterator iterator = deque.descendingIterator();
                while (iterator.hasNext()) {
                    \u5fc3\u529b \u5fc3\u529b3 = (\u5fc3\u529b)((Object)iterator.next());
                    if (arrayList.isEmpty()) {
                        if (!Intrinsics.areEqual((Object)((Object)\u5fc3\u529b3), (Object)((Object)\u5fc3\u529b2))) {
                            continue;
                        }
                    } else if (!Intrinsics.areEqual((Object)\u516c\u5173.\u6293\u624b(\u5fc3\u529b3.\u8d4b\u80fd), (Object)\u516c\u5173.\u6293\u624b(\u5fc3\u529b2.\u8d4b\u80fd))) break;
                    arrayList.add((Object)\u5fc3\u529b3);
                }
                \u516c\u5173.\u8d4b\u80fd(arrayList);
            }
            catch (Exception exception) {
                // empty catch block
            }
            return true;
        }
        return false;
    }
}

