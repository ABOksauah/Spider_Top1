/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u8111\u6d1e;

public final class \u8111\u6d1e$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u8111\u6d1e.\u8d4b\u80fd(object);
    }
}

