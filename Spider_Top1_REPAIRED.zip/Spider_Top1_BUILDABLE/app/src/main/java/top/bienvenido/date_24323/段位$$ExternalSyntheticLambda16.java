/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.LoadedApk
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import android.app.LoadedApk;
import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda16
implements Function0 {
    public final /* synthetic */ LoadedApk f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda16(LoadedApk loadedApk) {
        this.f$0 = loadedApk;
    }

    public final Object invoke() {
        return \u6bb5\u4f4d.\u8d4b\u80fd(this.f$0);
    }
}

