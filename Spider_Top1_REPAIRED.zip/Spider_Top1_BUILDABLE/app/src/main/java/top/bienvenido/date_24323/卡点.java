/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u59ff\u6001;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.common.initialize.MNative;

public abstract class \u5361\u70b9 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void \u8d4b\u80fd() {
        ContentResolver contentResolver = \u98ce\u53e3.\u8d4b\u80fd.getContentResolver();
        String string2 = \u98ce\u53e3.\u6293\u624b;
        Bundle bundle = contentResolver.call(Uri.parse((String)("content://" + string2 + ".service.provider")), "method", null, null);
        if (bundle == null) return;
        try {
            \u5361\u70b9.\u8d4b\u80fd(bundle);
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void \u8d4b\u80fd(Bundle bundle) {
        Object[] arrobject;
        try {
            Iterator iterator = \u5361\u4f4d.\u95ed\u73af.iterator();
            while (iterator.hasNext()) {
                ((Function1)iterator.next()).invoke((Object)bundle);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            ArrayList arrayList;
            IBinder iBinder = bundle.getBinder("https://www.62v.net/jnative/binder");
            if (iBinder == null) return;
            iBinder.linkToDeath((IBinder.DeathRecipient)new \u59ff\u6001(iBinder), 0);
            arrobject = new Object[]{iBinder, String.valueOf((int)bundle.getInt(Integer.TYPE.getName(), 0))};
            ArrayList arrayList2 = arrayList = \u5361\u4f4d.\u95ed\u73af;
            // MONITORENTER : arrayList2
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        MNative.\u8d4b\u80fd(1001, (Serializable)arrobject);
        // MONITOREXIT : arrayList2
        return;
    }
}

