/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.concurrent.ExecutorService
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6253\u901a$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6253\u901a$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u964d\u7ea7;

public final class \u6253\u901a
extends \u89e6\u53d1 {
    public static final int \u8d4b\u80fd(Intent intent, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u6293\u624b(intent, \u6c34\u4f4d.\u95ed\u73af);
    }

    public static final void \u8d4b\u80fd(Intent intent) {
        \u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u6253\u901a$$ExternalSyntheticLambda1(intent));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Intent intent;
        if (!\u6c34\u4f4d.\u8d4b\u80fd || (intent = (Intent)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Intent.class)) == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            if (intent.getPackage() == null && intent.getComponent() == null) return super.\u8d4b\u80fd(object, method, arrobject);
            \u6253\u901a$$ExternalSyntheticLambda0 \u6253\u901a$$ExternalSyntheticLambda0 = new \u6253\u901a$$ExternalSyntheticLambda0(intent);
            \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u6253\u901a$$ExternalSyntheticLambda0);
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

