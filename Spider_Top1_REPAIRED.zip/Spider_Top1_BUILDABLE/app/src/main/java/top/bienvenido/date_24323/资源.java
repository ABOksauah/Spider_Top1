/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IClipboardManagerExt
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 *  system.ext.loader.core.ExtCreator
 *  system.ext.loader.core.ExtRegistry
 */
package top.bienvenido.date_24323;

import android.content.IClipboardManagerExt;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import system.ext.loader.core.ExtCreator;
import system.ext.loader.core.ExtRegistry;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6d6e\u5c42;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d44\u6e90$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u8d44\u6e90
extends \u96c6\u6210 {
    public static final \u8d44\u6e90 \u6293\u624b = new \u8d44\u6e90();

    public static final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return new \u6d6e\u5c42();
    }

    @Override
    public final void \u8d4b\u80fd() {
        if (\u62bd\u8c61.\u54cd\u5e94) {
            ExtRegistry.registerExt(IClipboardManagerExt.class, (ExtCreator)((ExtCreator)Proxy.newProxyInstance((ClassLoader)IClipboardManagerExt.class.getClassLoader(), (Class[])new Class[]{ExtCreator.class}, (InvocationHandler)new \u8d44\u6e90$$ExternalSyntheticLambda0())));
            return;
        }
        Object object = null;
        try {
            object = \u771f\u9999.\u8d4b\u80fd("android.content.ClipboardManagerExtPlugin", "constructor").\u8d4b\u80fd(null);
        }
        catch (Exception exception) {
            // empty catch block
        }
        Constructor constructor = \u6d6e\u5c42.class.getDeclaredConstructor(\u4e0b\u6c89.\u6293\u624b);
        constructor.setAccessible(true);
        new \u8d77\u98de((String)"ctor").\u6293\u624b.\u8d4b\u80fd(object, (Object)constructor);
    }
}

