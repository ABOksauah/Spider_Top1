/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u56e0\u5b50;
import top.bienvenido.date_24323.\u5e03\u5c40;

public final class \u56e0\u5b50$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;

    public /* synthetic */ \u56e0\u5b50$$ExternalSyntheticLambda0(Object[] arrobject) {
        this.f$0 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u56e0\u5b50.\u8d4b\u80fd(this.f$0, (\u5e03\u5c40)object);
    }
}

