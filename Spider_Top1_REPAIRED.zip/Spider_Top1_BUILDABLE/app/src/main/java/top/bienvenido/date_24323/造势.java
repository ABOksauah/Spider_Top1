/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Locale
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.Bundle;
import java.util.Locale;

public abstract class \u9020\u52bf {
    public static void \u6293\u624b(Bundle bundle) {
        String string2 = bundle.getString("android:query-arg-sql-sort-order");
        int n = string2 != null ? string2.toUpperCase(Locale.ROOT).indexOf(" LIMIT ") : -1;
        if (n != -1) {
            String string3 = string2.substring(0, n);
            String string4 = string2.substring(n + 7);
            bundle.putString("android:query-arg-sql-sort-order", string3);
            bundle.putString("android:query-arg-sql-limit", string4);
        }
    }

    public static String \u8d4b\u80fd(String string2) {
        int n = 0;
        char c = '\u0000';
        for (int i = 0; i < string2.length(); ++i) {
            char c2 = string2.charAt(i);
            if (c2 == '\'' || c2 == '\"') {
                if (c == '\u0000') {
                    c = c2;
                } else if (c == c2) {
                    c = '\u0000';
                }
            }
            if (c != '\u0000') continue;
            if (c2 == '(') {
                ++n;
                continue;
            }
            if (c2 != ')') continue;
            --n;
        }
        if (n != 0) {
            StringBuilder stringBuilder = new StringBuilder(string2.length() + Math.abs((int)n));
            stringBuilder.append(string2);
            while (n > 0) {
                stringBuilder.append(')');
                --n;
            }
            while (n < 0) {
                stringBuilder.insert(0, '(');
                ++n;
            }
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    public static void \u8d4b\u80fd(Uri uri, Bundle bundle) {
        String string2 = uri.getQueryParameter("limit");
        if (string2 != null && !string2.isEmpty()) {
            bundle.putString("android:query-arg-sql-limit", string2);
        }
    }

    public static void \u8d4b\u80fd(Bundle bundle) {
        String string2 = bundle.getString("android:query-arg-sql-selection");
        int n = string2 != null ? string2.toUpperCase(Locale.ROOT).indexOf(" GROUP BY ") : -1;
        if (n != -1) {
            String string3 = string2.substring(0, n);
            String string4 = string2.substring(n + 10);
            String string5 = \u9020\u52bf.\u8d4b\u80fd(string3);
            String string6 = \u9020\u52bf.\u8d4b\u80fd(string4);
            bundle.putString("android:query-arg-sql-selection", string5);
            bundle.putString("android:query-arg-sql-group-by", string6);
        }
    }
}

