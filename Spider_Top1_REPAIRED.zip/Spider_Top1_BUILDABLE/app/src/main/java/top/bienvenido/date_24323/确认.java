/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u786e\u8ba4
implements Function1 {
    public final \u8d77\u98de \u8d4b\u80fd = new \u8d77\u98de("mList");

    public final Object invoke(Object object) {
        ParceledListSlice parceledListSlice = (ParceledListSlice)object;
        return (List)this.\u8d4b\u80fd.\u6293\u624b.\u8d4b\u80fd((Object)parceledListSlice);
    }
}

