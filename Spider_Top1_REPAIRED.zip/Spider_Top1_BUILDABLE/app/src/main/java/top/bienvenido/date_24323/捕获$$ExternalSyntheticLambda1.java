/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6355\u83b7;

public final class \u6355\u83b7$$ExternalSyntheticLambda1
implements Function1 {
    public final Object invoke(Object object) {
        return \u6355\u83b7.\u8d4b\u80fd(object);
    }
}

