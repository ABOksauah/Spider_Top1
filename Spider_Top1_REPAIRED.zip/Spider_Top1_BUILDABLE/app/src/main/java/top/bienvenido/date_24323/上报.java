/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0a\u62a5$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u4e0a\u62a5
extends \u89e6\u8fbe {
    public static final int \u8d4b\u80fd(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u6f0f\u6597(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            String string = object2 != null ? object2.toString() : null;
            if (!\u6c34\u4f4d.\u8d4b\u80fd) return method.invoke(object, arrobject);
            if (string == null) return method.invoke(object, arrobject);
            Integer n = (Integer)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u4e0a\u62a5$$ExternalSyntheticLambda0(string));
            if (n == null) return method.invoke(object, arrobject);
            int n2 = n;
            if (n2 < 0) return method.invoke(object, arrobject);
            return n2;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

