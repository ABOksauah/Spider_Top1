/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u52a1\u5b9e;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u52a1\u5b9e$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ \u52a1\u5b9e f$0;
    public final /* synthetic */ Object[] f$1;

    public /* synthetic */ \u52a1\u5b9e$$ExternalSyntheticLambda0(\u52a1\u5b9e \u52a1\u5b9e2, Object[] arrobject) {
        this.f$0 = \u52a1\u5b9e2;
        this.f$1 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u52a1\u5b9e.\u8d4b\u80fd(this.f$0, this.f$1, (\u94f8\u9020)object);
    }
}

