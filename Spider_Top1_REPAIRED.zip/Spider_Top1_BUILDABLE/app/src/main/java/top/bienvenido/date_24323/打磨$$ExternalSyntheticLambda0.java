/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ResolveInfo
 *  java.lang.Object
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import android.content.pm.ResolveInfo;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u6253\u78e8;

public final class \u6253\u78e8$$ExternalSyntheticLambda0
implements Function2 {
    public final Object invoke(Object object, Object object2) {
        return \u6253\u78e8.\u8d4b\u80fd((ResolveInfo)object, (ResolveInfo)object2);
    }
}

