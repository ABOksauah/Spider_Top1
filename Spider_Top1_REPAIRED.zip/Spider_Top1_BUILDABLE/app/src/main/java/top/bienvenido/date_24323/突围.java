/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Service
 *  android.content.pm.ServiceInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageParser;
import android.content.pm.ServiceInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u7a81\u56f4
extends MutablePropertyReference1Impl {
    public static final \u7a81\u56f4 \u8d4b\u80fd = new \u7a81\u56f4();

    public \u7a81\u56f4() {
        super(PackageParser.Service.class, "info", "getInfo()Landroid/content/pm/ServiceInfo;", 0);
    }

    public final Object get(Object object) {
        return ((PackageParser.Service)object).info;
    }

    public final void set(Object object, Object object2) {
        ((PackageParser.Service)object).info = (ServiceInfo)object2;
    }
}

