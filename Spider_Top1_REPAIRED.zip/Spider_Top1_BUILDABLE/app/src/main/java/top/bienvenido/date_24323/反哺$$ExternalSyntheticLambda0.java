/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.IContentObserver
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.database.IContentObserver;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u53cd\u54fa;
import top.bienvenido.date_24323.\u8ba2\u9605;

public final class \u53cd\u54fa$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ IContentObserver f$0;

    public /* synthetic */ \u53cd\u54fa$$ExternalSyntheticLambda0(IContentObserver iContentObserver) {
        this.f$0 = iContentObserver;
    }

    public final Object invoke(Object object) {
        return \u53cd\u54fa.\u8d4b\u80fd(this.f$0, (\u8ba2\u9605)object);
    }
}

