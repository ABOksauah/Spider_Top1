/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u57fa\u56e0$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u57fa\u56e0
extends \u89e6\u8fbe {
    public static final List \u8d4b\u80fd(Object[] arrobject, \u5e03\u5c40 \u5e03\u5c402) {
        Object object = arrobject[0];
        boolean bl = object instanceof Number;
        int n = 0;
        if (bl) {
            n = ((Number)object).intValue();
        }
        return \u5e03\u5c402.\u8d4b\u80fd(0xFFFFFFFFL & (long)\u6c34\u4f4d.\u6c89\u6dc0 | -4294967296L & (long)n << 32);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        List list;
        if (\u6c34\u4f4d.\u8d4b\u80fd && (list = (List)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u57fa\u56e0$$ExternalSyntheticLambda0(arrobject))) != null) {
            return list;
        }
        return method.invoke(object, arrobject);
    }
}

