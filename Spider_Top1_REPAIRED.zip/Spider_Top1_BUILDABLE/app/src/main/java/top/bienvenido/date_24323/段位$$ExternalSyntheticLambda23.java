/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda23
implements Runnable {
    public final void run() {
        \u6bb5\u4f4d.\u5bf9\u6807();
    }
}

