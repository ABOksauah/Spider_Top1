/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u83b7\u5ba2;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u83b7\u5ba2$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ int f$0;
    public final /* synthetic */ \u89e6\u8fbe f$1;

    public /* synthetic */ \u83b7\u5ba2$$ExternalSyntheticLambda0(int n, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.f$0 = n;
        this.f$1 = \u89e6\u8fbe2;
    }

    public final Object invoke(Object object) {
        return \u83b7\u5ba2.\u8d4b\u80fd(this.f$0, this.f$1, object);
    }
}

