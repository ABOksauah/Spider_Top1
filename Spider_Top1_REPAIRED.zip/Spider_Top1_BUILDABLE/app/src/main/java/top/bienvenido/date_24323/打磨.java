/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ResolveInfo
 *  java.io.File
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Comparator
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u6253\u78e8$
 *  top.bienvenido.date_24323.\u6253\u78e8$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ComponentInfo;
import android.content.pm.ResolveInfo;
import java.io.File;
import java.util.Comparator;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u6253\u78e8$;
import top.bienvenido.date_24323.\u6253\u78e8$$ExternalSyntheticLambda1;

public abstract class \u6253\u78e8 {
    public static final int \u8d4b\u80fd(ResolveInfo resolveInfo, ResolveInfo resolveInfo2) {
        int n = resolveInfo.priority;
        int n2 = resolveInfo2.priority;
        if (n != n2) {
            if (n > n2) {
                return -1;
            }
            return 1;
        }
        boolean bl = resolveInfo.isDefault;
        if (bl != resolveInfo2.isDefault) {
            if (bl) {
                return -1;
            }
            return 1;
        }
        return 0;
    }

    public static final int \u8d4b\u80fd(Function2 function2, Object object, Object object2) {
        return ((Number)function2.invoke(object, object2)).intValue();
    }

    public static final ComponentName \u8d4b\u80fd(ComponentInfo componentInfo) {
        return new ComponentName(componentInfo.packageName, componentInfo.name);
    }

    public static final /* varargs */ File \u8d4b\u80fd(File file, String ... arrstring) {
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            File file2 = new File(file, arrstring[i]);
            file = file2;
        }
        return file;
    }

    public static final List \u8d4b\u80fd(List list) {
        CollectionsKt.sortWith((List)list, (Comparator)new \u6253\u78e8$$ExternalSyntheticLambda1((Function2)new $ExternalSyntheticLambda0()));
        return list;
    }

    public static final boolean \u8d4b\u80fd(int n, int n2) {
        return (n & n2) == n2;
    }
}

