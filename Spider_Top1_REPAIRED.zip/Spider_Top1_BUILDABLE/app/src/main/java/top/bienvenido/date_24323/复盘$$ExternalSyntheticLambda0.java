/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u590d\u76d8;

public final class \u590d\u76d8$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u590d\u76d8.\u8d4b\u80fd((\u589e\u957f)object);
    }
}

