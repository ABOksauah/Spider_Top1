/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u6a21\u578b
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6a21\u578b;

public final class \u6a21\u578b$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ Object[] f$2;

    public /* synthetic */ \u6a21\u578b$$ExternalSyntheticLambda0(IBinder iBinder, Intent intent, Object[] arrobject) {
        this.f$0 = iBinder;
        this.f$1 = intent;
        this.f$2 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u6a21\u578b.\u8d4b\u80fd((IBinder)this.f$0, (Intent)this.f$1, (Object[])this.f$2, (\u5e03\u5c40)((\u5e03\u5c40)object));
    }
}

