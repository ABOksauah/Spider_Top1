/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Activity
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageParser;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u601d\u8003
extends MutablePropertyReference1Impl {
    public static final \u601d\u8003 \u8d4b\u80fd = new \u601d\u8003();

    public \u601d\u8003() {
        super(PackageParser.Activity.class, "info", "getInfo()Landroid/content/pm/ActivityInfo;", 0);
    }

    public final Object get(Object object) {
        return ((PackageParser.Activity)object).info;
    }

    public final void set(Object object, Object object2) {
        ((PackageParser.Activity)object).info = (ActivityInfo)object2;
    }
}

