/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import top.bienvenido.date_24323.\u6a2a\u5411;

public final class \u6a2a\u5411$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ Intent f$1;

    public /* synthetic */ \u6a2a\u5411$$ExternalSyntheticLambda0(IBinder iBinder, Intent intent) {
        this.f$0 = iBinder;
        this.f$1 = intent;
    }

    public final void run() {
        \u6a2a\u5411.\u6293\u624b(this.f$0, this.f$1);
    }
}

