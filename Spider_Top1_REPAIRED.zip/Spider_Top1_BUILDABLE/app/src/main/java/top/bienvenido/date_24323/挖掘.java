/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6316\u6398$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u94fe\u8def;

public final class \u6316\u6398
extends \u89e6\u53d1 {
    public static final IBinder \u8d4b\u80fd(Object[] arrobject, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u95ed\u73af((Intent)arrobject[0], \u6c34\u4f4d.\u95ed\u73af);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IBinder iBinder;
        if (\u6c34\u4f4d.\u8d4b\u80fd && (iBinder = (IBinder)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u6316\u6398$$ExternalSyntheticLambda0(arrobject))) != null) {
            return iBinder;
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

