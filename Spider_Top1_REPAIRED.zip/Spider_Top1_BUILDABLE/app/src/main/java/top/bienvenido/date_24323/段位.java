/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityThread
 *  android.app.AppComponentFactory
 *  android.app.Application
 *  android.app.IActivityManager
 *  android.app.Instrumentation
 *  android.app.LoadedApk
 *  android.app.Service
 *  android.content.AttributionSource
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ProviderInfo
 *  android.ddm.DdmHandleAppName
 *  android.os.ConditionVariable
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  android.os.Process
 *  android.security.net.config.NetworkSecurityConfigProvider
 *  android.system.Os
 *  android.util.Singleton
 *  java.io.File
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.net.Authenticator
 *  java.net.InetSocketAddress
 *  java.net.Proxy
 *  java.net.Proxy$Type
 *  java.net.ProxySelector
 *  java.net.SocketAddress
 *  java.net.URI
 *  java.util.ArrayList
 *  java.util.Comparator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Future
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package top.bienvenido.date_24323;

import android.app.ActivityThread;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.IActivityManager;
import android.app.Instrumentation;
import android.app.LoadedApk;
import android.app.Service;
import android.content.AttributionSource;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.ddm.DdmHandleAppName;
import android.os.ConditionVariable;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Process;
import android.security.net.config.NetworkSecurityConfigProvider;
import android.system.Os;
import android.util.Singleton;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net_62v.external.IMundoProcessCallback;
import net_62v.external.\u8d4b\u80fd;
import top.bienvenido.date_24323.\u4e0a\u9650;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u4e0b\u9650;
import top.bienvenido.date_24323.\u4f17\u7b79;
import top.bienvenido.date_24323.\u5171\u5efa;
import top.bienvenido.date_24323.\u534f\u8c03;
import top.bienvenido.date_24323.\u56de\u6eaf;
import top.bienvenido.date_24323.\u5708\u5c42;
import top.bienvenido.date_24323.\u592f\u5b9e;
import top.bienvenido.date_24323.\u5c42\u7ea7;
import top.bienvenido.date_24323.\u5e38\u6001\u5316;
import top.bienvenido.date_24323.\u5e74\u6846;
import top.bienvenido.date_24323.\u5f71\u54cd\u529b;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u62a5\u5907;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u63d0\u8c03\u5b50;
import top.bienvenido.date_24323.\u652f\u6301;
import top.bienvenido.date_24323.\u6613\u7528\u6027;
import top.bienvenido.date_24323.\u6a2a\u5411;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda10;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda11;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda12;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda13;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda14;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda15;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda16;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda17;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda18;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda19;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda2;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda20;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda21;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda22;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda23;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda24;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda3;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda4;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda5;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda6;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda7;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda8;
import top.bienvenido.date_24323.\u6bb5\u4f4d$$ExternalSyntheticLambda9;
import top.bienvenido.date_24323.\u6bcd\u4f53;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u6d3b\u8dc3;
import top.bienvenido.date_24323.\u6d41\u91cf;
import top.bienvenido.date_24323.\u6fc0\u52b1;
import top.bienvenido.date_24323.\u7559\u5b58;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u77ed\u5e73\u5feb;
import top.bienvenido.date_24323.\u798f\u62a5;
import top.bienvenido.date_24323.\u7a7f\u68ad;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u7ec4\u5c40;
import top.bienvenido.date_24323.\u8026\u5408;
import top.bienvenido.date_24323.\u8026\u5408\u6027;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8585\u7f8a\u6bdb;
import top.bienvenido.date_24323.\u8bc4\u5ba1;
import top.bienvenido.date_24323.\u8bd5\u70b9;
import top.bienvenido.date_24323.\u8c03\u6027;
import top.bienvenido.date_24323.\u8d44\u6e90\u4f4d;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u8de8\u754c;
import top.bienvenido.date_24323.\u8f6c\u5316;
import top.bienvenido.date_24323.\u901a\u6652;
import top.bienvenido.date_24323.\u9020\u4e8b;
import top.bienvenido.date_24323.\u9020\u8840;
import top.bienvenido.date_24323.\u9080\u8bf7;
import top.bienvenido.date_24323.\u914d\u79f0;
import top.bienvenido.date_24323.\u94f6\u5f39;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u964d\u7ea7;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.common.initialize.MNative;

public final class \u6bb5\u4f4d
extends \u6fc0\u52b1 {
    public static final Map \u4e0a\u5347;
    public static final ActivityThread \u4e2d\u53f0;
    public static final Map \u4ea4\u4ed8;
    public static Function0 \u4f18\u5316;
    public static final Class \u5012\u903c;
    public static final Constructor \u5305\u88c5;
    public static Function0 \u5347\u7ea7;
    public static final \u81ea\u6d3d \u540c\u6b65;
    public static final \u81ea\u6d3d \u54cd\u5e94;
    public static final \u81ea\u6d3d \u590d\u76d8;
    public static final \u81ea\u6d3d \u5bf9\u6807;
    public static final \u81ea\u6d3d \u5bf9\u9f50;
    public static final \u81ea\u6d3d \u5e73\u53f0;
    public static final \u6bb5\u4f4d \u6293\u624b;
    public static final \u81ea\u6d3d \u63d0\u70bc;
    public static final \u8d77\u98de \u65b9\u6848;
    public static final \u81ea\u6d3d \u68b3\u7406;
    public static final \u81ea\u6d3d \u6c89\u6dc0;
    public static final Object \u6f0f\u6597;
    public static final \u81ea\u6d3d \u7ed9\u5230;
    public static final \u81ea\u6d3d \u805a\u7126;
    public static final \u81ea\u6d3d \u843d\u5730;
    public static final \u81ea\u6d3d \u8ddf\u8fdb;
    public static final \u81ea\u6d3d \u8f93\u51fa;
    public static final ConditionVariable \u8fed\u4ee3;
    public static final Handler \u95ed\u73af;

    static {
        ActivityThread activityThread;
        Class<Context> class_;
        Object object;
        Handler handler;
        Constructor constructor;
        \u6293\u624b = new \u6bb5\u4f4d();
        \u4e2d\u53f0 = activityThread = ActivityThread.currentActivityThread();
        try {
            handler = \u62bd\u8c61.\u5e73\u53f0 ? activityThread.getHandler() : (Handler)\u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "mH").\u8d4b\u80fd((Object)activityThread);
        }
        catch (Throwable throwable) {
            handler = new Handler(Looper.getMainLooper());
        }
        \u95ed\u73af = handler;
        \u843d\u5730 = \u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "installContentProviders", new Class[]{Context.class, List.class});
        ActivityThread activityThread2 = \u4e2d\u53f0;
        \u6f0f\u6597 = object = new \u8d77\u98de((String)"mBoundApplication").\u6293\u624b.\u8d4b\u80fd((Object)activityThread2);
        Class class_2 = object.getClass();
        \u6c89\u6dc0 = \u771f\u9999.\u8d4b\u80fd(class_2, "providers");
        \u7ed9\u5230 = \u771f\u9999.\u8d4b\u80fd(class_2, "restrictedBackupMode");
        \u5e73\u53f0 = \u771f\u9999.\u8d4b\u80fd(class_2, "appInfo");
        \u54cd\u5e94 = \u771f\u9999.\u8d4b\u80fd(class_2, "info");
        \u540c\u6b65 = \u771f\u9999.\u8d4b\u80fd(class_2, "processName");
        String string = \u62bd\u8c61.\u54cd\u5e94 ? "makeApplicationInner" : "makeApplication";
        Class[] arrclass = new Class[]{Boolean.TYPE, Instrumentation.class};
        \u5bf9\u9f50 = \u771f\u9999.\u8d4b\u80fd(LoadedApk.class, string, arrclass);
        \u5bf9\u6807 = \u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "mInitialApplication");
        \u8fed\u4ee3 = new ConditionVariable();
        \u4f18\u5316 = new \u6bb5\u4f4d$$ExternalSyntheticLambda9();
        \u8ddf\u8fdb = \u771f\u9999.\u8d4b\u80fd(Process.class, "setArgV0", new Class[]{String.class});
        \u5347\u7ea7 = new \u6bb5\u4f4d$$ExternalSyntheticLambda10();
        \u4ea4\u4ed8 = (Map)\u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "mServices").\u8d4b\u80fd((Object)activityThread2);
        \u805a\u7126 = \u771f\u9999.\u8d4b\u80fd(Service.class, "attach", new Class[]{Context.class, ActivityThread.class, String.class, IBinder.class, Application.class, Object.class});
        try {
            class_ = Class.forName((String)"android.app.ContextImpl");
        }
        catch (Exception exception) {
            class_ = Context.class;
        }
        \u5012\u903c = class_;
        \u590d\u76d8 = \u771f\u9999.\u8d4b\u80fd(class_, "createAppContext", new Class[]{ActivityThread.class, LoadedApk.class});
        \u68b3\u7406 = \u771f\u9999.\u8d4b\u80fd(class_, "setOuterContext", new Class[]{Context.class});
        \u8f93\u51fa = \u771f\u9999.\u8d4b\u80fd(class_, "scheduleFinalCleanup", new Class[]{String.class, String.class});
        \u63d0\u70bc = \u771f\u9999.\u8d4b\u80fd(Service.class, "mToken");
        try {
            String string2 = ActivityThread.class.getName();
            Class class_3 = Class.forName((String)(string2 + "$ProviderKey"));
            Class[] arrclass2 = new Class[]{String.class, Integer.TYPE};
            constructor = class_3.getDeclaredConstructor(arrclass2);
            constructor.setAccessible(true);
        }
        catch (Exception exception) {
            constructor = null;
        }
        \u5305\u88c5 = constructor;
        \u4e0a\u5347 = (Map)\u771f\u9999.\u8d4b\u80fd(ActivityThread.class, "mProviderMap").\u8d4b\u80fd((Object)\u4e2d\u53f0);
        \u65b9\u6848 = new \u8d77\u98de("mProvider");
    }

    public static final void \u4e2d\u53f0(IBinder iBinder, Intent intent) {
        Service service;
        block3 : {
            try {
                service = (Service)\u4ea4\u4ed8.get((Object)iBinder);
                if (service != null) break block3;
                return;
            }
            catch (Exception exception) {
                return;
            }
        }
        intent.setExtrasClassLoader(service.getClassLoader());
        IBinder iBinder2 = service.onBind(intent);
        \u94fe\u8def.\u843d\u5730.\u8d4b\u80fd(new \u6bb5\u4f4d$$ExternalSyntheticLambda14(iBinder, intent, iBinder2));
    }

    public static final LoadedApk \u4ea4\u4ed8() {
        Context context = \u98ce\u53e3.\u8d4b\u80fd.createPackageContext(\u6c34\u4f4d.\u6293\u624b, 3);
        LoadedApk loadedApk = (LoadedApk)new \u8d77\u98de((String)"mPackageInfo").\u6293\u624b.\u8d4b\u80fd((Object)context);
        \u5347\u7ea7 = new \u6bb5\u4f4d$$ExternalSyntheticLambda16(loadedApk);
        if (\u62bd\u8c61.\u6f0f\u6597) {
            try {
                NetworkSecurityConfigProvider.install((Context)context);
                return loadedApk;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return loadedApk;
    }

    public static final void \u4ea4\u4ed8(String string) {
        \u6293\u624b.getClass();
        \u6bb5\u4f4d.\u5347\u7ea7(string);
    }

    public static final void \u4f18\u5316() {
        \u96c6\u6210[] arr\u96c6\u6210 = new \u96c6\u6210[20];
        \u652f\u6301 \u652f\u63012 = \u652f\u6301.\u6293\u624b;
        arr\u96c6\u6210[0] = \u652f\u63012;
        arr\u96c6\u6210[1] = \u5e74\u6846.\u6293\u624b;
        arr\u96c6\u6210[2] = \u77ed\u5e73\u5feb.\u6293\u624b;
        arr\u96c6\u6210[3] = \u63d0\u8c03\u5b50.\u6293\u624b;
        arr\u96c6\u6210[4] = \u6d41\u91cf.\u6293\u624b;
        arr\u96c6\u6210[5] = \u8026\u5408\u6027.\u6293\u624b;
        arr\u96c6\u6210[6] = \u8bc4\u5ba1.\u6293\u624b;
        arr\u96c6\u6210[7] = \u62a5\u5907.\u6293\u624b;
        arr\u96c6\u6210[8] = \u7a7f\u68ad.\u6293\u624b;
        arr\u96c6\u6210[9] = \u8026\u5408.\u6293\u624b;
        arr\u96c6\u6210[10] = \u56de\u6eaf.\u6293\u624b;
        arr\u96c6\u6210[11] = \u9020\u8840.\u6293\u624b;
        arr\u96c6\u6210[12] = \u9020\u4e8b.\u6293\u624b;
        arr\u96c6\u6210[13] = \u4f17\u7b79.\u6293\u624b;
        arr\u96c6\u6210[14] = \u6d3b\u8dc3.\u6293\u624b;
        arr\u96c6\u6210[15] = \u914d\u79f0.\u6293\u624b;
        arr\u96c6\u6210[16] = \u6bcd\u4f53.\u6293\u624b;
        arr\u96c6\u6210[17] = \u8bd5\u70b9.\u6293\u624b;
        arr\u96c6\u6210[18] = \u5f71\u54cd\u529b.\u6293\u624b;
        arr\u96c6\u6210[19] = \u6613\u7528\u6027.\u6293\u624b;
        for (int i = 0; i < 20; ++i) {
            \u96c6\u6210 \u96c6\u62102 = arr\u96c6\u6210[i];
            try {
                \u96c6\u62102.\u8d4b\u80fd();
                continue;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u5347\u7ea7() {
        void var2_2;
        block4 : {
            block5 : {
                try {
                    if (\u62bd\u8c61.\u5e73\u53f0) {
                        AttributionSource attributionSource = \u98ce\u53e3.\u8d4b\u80fd.getAttributionSource();
                        break block4;
                    }
                    if (\u62bd\u8c61.\u6f0f\u6597) break block5;
                    \u4e0a\u9650 \u4e0a\u96502 = new \u4e0a\u9650();
                    break block4;
                }
                catch (Throwable throwable) {
                    return;
                }
            }
            Object var2_3 = null;
        }
        \u4e0b\u9650 \u4e0b\u96502 = new \u4e0b\u9650();
        Object[] arrobject = new Object[]{\u98ce\u53e3.\u6293\u624b, var2_2, \u4e0b\u96502};
        MNative.\u8d4b\u80fd(1003, (Serializable)arrobject);
        if (\u62bd\u8c61.\u4ea4\u4ed8) {
            Thread.setDefaultUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)new \u6bb5\u4f4d$$ExternalSyntheticLambda11(Thread.getDefaultUncaughtExceptionHandler()));
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void \u5347\u7ea7(String var0) {
        block22 : {
            block21 : {
                block20 : {
                    try {
                        var2_1 = var0.length();
                        if (var2_1 != 0) ** GOTO lbl21
                    }
                    catch (Exception var1_12) {
                        return;
                    }
                    try {
                        if (!\u62bd\u8c61.\u4e2d\u53f0) break block20;
                        var12_2 = (ProxySelector)Class.forName((String)"sun.net.spi.DefaultProxySelector").newInstance();
                        break block21;
                    }
                    catch (Exception var11_3) {
                        // empty catch block
                    }
                }
                var12_2 = null;
            }
            if (var12_2 != null) ** GOTO lbl18
            var12_2 = new \u94f6\u5f39(Proxy.NO_PROXY);
lbl18: // 2 sources:
            ProxySelector.setDefault((ProxySelector)var12_2);
            \u94f6\u5f39.\u8d4b\u80fd(null, null);
            return;
lbl21: // 1 sources:
            var3_4 = URI.create((String)var0);
            var4_5 = var3_4.getScheme();
            if (var4_5 == null) {
                return;
            }
            switch (var4_5.hashCode()) {
                case 109610287: {
                    if (!var4_5.equals((Object)"socks")) {
                        return;
                    }
                    ** GOTO lbl46
                }
                case 99617003: {
                    if (!var4_5.equals((Object)"https")) {
                        return;
                    }
                    ** GOTO lbl37
                }
                case 3213448: {
                    if (!var4_5.equals((Object)"http")) {
                        return;
                    }
lbl37: // 3 sources:
                    var5_6 = Proxy.Type.HTTP;
                    ** GOTO lbl47
                }
                case -897048346: {
                    if (!var4_5.equals((Object)"socks5")) {
                        return;
                    }
                    ** GOTO lbl46
                }
                case -2038694846: {
                    if (!var4_5.equals((Object)"socks5h")) {
                        return;
                    }
lbl46: // 4 sources:
                    var5_6 = Proxy.Type.SOCKS;
lbl47: // 2 sources:
                    var6_7 = var3_4.getUserInfo();
                    if (var6_7 != null && var6_7.length() != 0) {
                        Authenticator.setDefault((Authenticator)new \u5c42\u7ea7(StringsKt.substringBefore$default((String)var6_7, (char)':', null, (int)2, null), StringsKt.substringAfter$default((String)var6_7, (char)':', null, (int)2, null).toCharArray()));
                    }
                    var7_8 = var3_4.getHost();
                    var8_9 = var3_4.getPort();
                    if (var7_8 == null) {
                        return;
                    }
                    break block22;
                }
            }
            return;
        }
        var9_10 = var8_9 == -1 ? 443 : var8_9;
        var10_11 = new Proxy(var5_6, (SocketAddress)InetSocketAddress.createUnresolved((String)var7_8, (int)var9_10));
        \u94f6\u5f39.\u8d4b\u80fd(var7_8, String.valueOf((int)var8_9));
        ProxySelector.setDefault((ProxySelector)new \u94f6\u5f39(var10_11));
    }

    public static final Unit \u540c\u6b65() {
        \u4f18\u5316 = new \u6bb5\u4f4d$$ExternalSyntheticLambda22();
        try {
            \u6bb5\u4f4d$$ExternalSyntheticLambda23 \u6bb5\u4f4d$$ExternalSyntheticLambda23 = new \u6bb5\u4f4d$$ExternalSyntheticLambda23();
            ExecutorService executorService = \u964d\u7ea7.\u6293\u624b;
            Future[] arrfuture = new Future[]{executorService.submit((Runnable)\u6bb5\u4f4d$$ExternalSyntheticLambda23), executorService.submit((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda24()), executorService.submit((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda1()), executorService.submit((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda2()), executorService.submit((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda3())};
            \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda4(arrfuture));
        }
        catch (Exception exception) {
            // empty catch block
        }
        return Unit.INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u54cd\u5e94() {
        try {
            \u8d4b\u80fd \u8d4b\u80fd2;
            \u8d4b\u80fd \u8d4b\u80fd3 = \u7ec4\u5c40.\u8d4b\u80fd;
            boolean bl = \u8d4b\u80fd3 != null ? \u8d4b\u80fd3.\u8d4b\u80fd.shouldInterpretFacebookBrowser() : false;
            if (bl) {
                \u7559\u5b58.\u8d4b\u80fd();
            }
            if ((\u8d4b\u80fd2 = \u7ec4\u5c40.\u8d4b\u80fd) == null) return;
            {
                String string = \u6c34\u4f4d.\u6293\u624b;
                String string2 = \u6c34\u4f4d.\u4e2d\u53f0;
                String string3 = \u6c34\u4f4d.\u95ed\u73af;
                \u8d4b\u80fd2.\u8d4b\u80fd.onCreate(string, string2, string3);
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static final void \u5bf9\u6807() {
        \u8de8\u754c \u8de8\u754c2 = \u8de8\u754c.\u6293\u624b;
        try {
            \u8de8\u754c2.\u8d4b\u80fd();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public static final Unit \u5bf9\u9f50() {
        return Unit.INSTANCE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u5e73\u53f0(IBinder iBinder) {
        Service service = (Service)\u4ea4\u4ed8.remove((Object)iBinder);
        if (service == null) return;
        try {
            service.onDestroy();
            \u63d0\u70bc.\u8d4b\u80fd((Object)service, (Object)null);
            Context context = service.getBaseContext();
            if (!\u5012\u903c.isInstance((Object)context)) return;
            \u8f93\u51fa.\u8d4b\u80fd((Object)context, service.getClass().getName(), "Service");
            return;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static final String \u6293\u624b(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u8fed\u4ee3(string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u6293\u624b(IBinder iBinder, Intent intent, int n) {
        Service service;
        try {
            service = (Service)\u4ea4\u4ed8.get((Object)iBinder);
            if (service == null) return;
        }
        catch (Exception exception) {
            return;
        }
        intent.setExtrasClassLoader(service.getClassLoader());
        service.onStartCommand(intent, 0, n);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final void \u6293\u624b(String string, Intent intent, IBinder iBinder, int n) {
        Service service;
        LoadedApk loadedApk = (LoadedApk)\u5347\u7ea7.invoke();
        \u81ea\u6d3d \u81ea\u6d3d2 = \u5bf9\u9f50;
        ActivityThread activityThread = \u4e2d\u53f0;
        Instrumentation instrumentation = activityThread.getInstrumentation();
        Object[] arrobject = new Object[]{Boolean.FALSE, instrumentation};
        Object object = \u81ea\u6d3d2.\u8d4b\u80fd((Object)loadedApk, arrobject);
        ClassLoader classLoader = loadedApk.getClassLoader();
        if (\u62bd\u8c61.\u6f0f\u6597) {
            service = loadedApk.getAppFactory().instantiateService(classLoader, string, intent);
        } else {
            Constructor constructor = classLoader.loadClass(string).getDeclaredConstructor(\u4e0b\u6c89.\u6293\u624b);
            constructor.setAccessible(true);
            service = (Service)constructor.newInstance(\u4e0b\u6c89.\u4e2d\u53f0);
        }
        Object object2 = \u590d\u76d8.\u8d4b\u80fd((Object)null, new Object[]{activityThread, loadedApk});
        \u68b3\u7406.\u8d4b\u80fd(object2, new Object[]{service});
        \u805a\u7126.\u8d4b\u80fd((Object)service, new Object[]{object2, activityThread, string, iBinder, object, (IActivityManager)\u8c03\u6027.\u8d4b\u80fd.get()});
        service.onCreate();
        \u4ea4\u4ed8.put((Object)iBinder, (Object)service);
        if (n <= 0 || intent == null) return;
        try {
            \u6293\u624b.getClass();
            \u6bb5\u4f4d.\u8d4b\u80fd(iBinder, intent, n);
            return;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static final LoadedApk \u8d4b\u80fd(LoadedApk loadedApk) {
        return loadedApk;
    }

    public static final PackageInfo \u8d4b\u80fd(String string, PackageManager packageManager) {
        return packageManager.getPackageInfo(string, 520);
    }

    public static final PackageInfo \u8d4b\u80fd(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u4e2d\u53f0(string, 8);
    }

    public static void \u8d4b\u80fd(Application application) {
        List list;
        \u81ea\u6d3d \u81ea\u6d3d2 = \u7ed9\u5230;
        Object object = \u6f0f\u6597;
        if (!Intrinsics.areEqual((Object)\u81ea\u6d3d2.\u8d4b\u80fd(object), (Object)Boolean.TRUE) && (list = (List)\u6c89\u6dc0.\u8d4b\u80fd(object)) != null) {
            if (list.isEmpty()) {
                return;
            }
            \u843d\u5730.\u8d4b\u80fd((Object)\u4e2d\u53f0, new Object[]{application, list});
        }
    }

    public static void \u8d4b\u80fd(IBinder iBinder, Intent intent, int n) {
        \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda15(iBinder, intent, n));
    }

    public static final void \u8d4b\u80fd(Thread.UncaughtExceptionHandler uncaughtExceptionHandler, Thread thread, Throwable throwable) {
        if (Intrinsics.areEqual((Object)thread.getName(), (Object)"application-accelerate-Thread") && thread instanceof HandlerThread) {
            ((HandlerThread)thread).getLooper().quit();
            return;
        }
        if (uncaughtExceptionHandler != null) {
            uncaughtExceptionHandler.uncaughtException(thread, throwable);
            return;
        }
        throw throwable;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u8d4b\u80fd(Future[] arrfuture) {
        try {
            int n = arrfuture.length;
            for (int i = 0; i < n; ++i) {
                arrfuture[i].get();
            }
            \u8d4b\u80fd \u8d4b\u80fd2 = \u7ec4\u5c40.\u8d4b\u80fd;
            if (\u8d4b\u80fd2 != null) {
                \u8d4b\u80fd2.\u8d4b\u80fd.onInitialized();
            }
            \u6d1e\u81ea\u8eab.\u8d4b\u80fd();
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static final boolean \u8d4b\u80fd(IBinder iBinder, Intent intent, IBinder iBinder2, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u8d4b\u80fd(iBinder, intent, iBinder2);
    }

    public static final void \u8ddf\u8fdb() {
        if (\u62bd\u8c61.\u95ed\u73af) {
            \u8585\u7f8a\u6bdb \u8585\u7f8a\u6bdb2 = \u8585\u7f8a\u6bdb.\u6293\u624b;
            try {
                \u8585\u7f8a\u6bdb2.\u8d4b\u80fd();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (\u62bd\u8c61.\u6f0f\u6597) {
                \u5171\u5efa \u5171\u5efa2 = \u5171\u5efa.\u6293\u624b;
                try {
                    \u5171\u5efa2.\u8d4b\u80fd();
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                if (\u62bd\u8c61.\u6c89\u6dc0) {
                    \u534f\u8c03 \u534f\u8c032 = \u534f\u8c03.\u6293\u624b;
                    try {
                        \u534f\u8c032.\u8d4b\u80fd();
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    if (\u62bd\u8c61.\u8ddf\u8fdb && \u62bd\u8c61.\u5e73\u53f0) {
                        \u9080\u8bf7 \u9080\u8bf72 = \u9080\u8bf7.\u6293\u624b;
                        try {
                            \u9080\u8bf72.\u8d4b\u80fd();
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                }
            }
        }
        \u5e38\u6001\u5316.\u8d4b\u80fd();
    }

    public static final void \u8fed\u4ee3() {
        \u901a\u6652 \u901a\u66522 = \u901a\u6652.\u6293\u624b;
        try {
            \u901a\u66522.\u8d4b\u80fd();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final void \u95ed\u73af(IBinder iBinder, Intent intent) {
        Service service;
        block4 : {
            block3 : {
                try {
                    service = (Service)\u4ea4\u4ed8.get((Object)iBinder);
                    if (service == null) {
                        return;
                    }
                    if (intent == null) break block3;
                    intent.setExtrasClassLoader(service.getClassLoader());
                    break block4;
                }
                catch (Exception exception) {
                    return;
                }
            }
            intent = null;
        }
        service.onUnbind(intent);
    }

    @Override
    public final void \u54cd\u5e94(String string) {
        \u6c34\u4f4d.\u7ed9\u5230 = string;
        \u6bb5\u4f4d$$ExternalSyntheticLambda8 \u6bb5\u4f4d$$ExternalSyntheticLambda8 = new \u6bb5\u4f4d$$ExternalSyntheticLambda8(string);
        \u964d\u7ea7.\u6293\u624b.execute((Runnable)\u6bb5\u4f4d$$ExternalSyntheticLambda8);
    }

    @Override
    public final IBinder \u5bf9\u9f50(String string) {
        IInterface iInterface;
        block5 : {
            \u8d77\u98de \u8d77\u98de2;
            Object object;
            block4 : {
                try {
                    \u8fed\u4ee3.block(10000L);
                    \u8d77\u98de2 = \u65b9\u6848;
                    object = \u4e0a\u5347.get(\u5305\u88c5.newInstance(new Object[]{string, \u98ce\u53e3.\u95ed\u73af}));
                    if (object != null) break block4;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            iInterface = (IInterface)\u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd(object);
            if (iInterface != null) break block5;
            return null;
        }
        IBinder iBinder = iInterface.asBinder();
        return iBinder;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void \u5e73\u53f0() {
        var4_1 = new \u6bb5\u4f4d$$ExternalSyntheticLambda5(this);
        var5_2 = \u964d\u7ea7.\u6293\u624b.submit((Runnable)var4_1);
        var6_3 = (LoadedApk)\u6bb5\u4f4d.\u5347\u7ea7.invoke();
        var7_4 = \u6bb5\u4f4d.\u5e73\u53f0;
        var8_5 = \u6bb5\u4f4d.\u6f0f\u6597;
        var7_4.\u8d4b\u80fd(var8_5, (Object)var6_3.getApplicationInfo());
        \u6bb5\u4f4d.\u54cd\u5e94.\u8d4b\u80fd(var8_5, (Object)var6_3);
        var5_2.get();
        var10_6 = \u6bb5\u4f4d.\u5bf9\u9f50;
        var11_7 = new Object[]{Boolean.FALSE, null};
        var12_8 = (Application)var10_6.\u8d4b\u80fd((Object)var6_3, var11_7);
        var13_9 = \u6bb5\u4f4d.\u5bf9\u6807;
        var14_10 = \u6bb5\u4f4d.\u4e2d\u53f0;
        var13_9.\u8d4b\u80fd((Object)var14_10, (Object)var12_8);
        \u6bb5\u4f4d.\u8d4b\u80fd(var12_8);
        var15_11 = var14_10.getInstrumentation();
        try {
            var15_11.callApplicationOnCreate(var12_8);
            ** GOTO lbl24
        }
        catch (Throwable var16_12) {
            try {
                var15_11.onException((Object)var12_8, var16_12);
lbl24: // 2 sources:
                var19_13 = new \u6bb5\u4f4d$$ExternalSyntheticLambda6();
                \u964d\u7ea7.\u6293\u624b.execute((Runnable)var19_13);
            }
            catch (Throwable var2_14) {
                \u6bb5\u4f4d.\u8fed\u4ee3.open();
                throw var2_14;
            }
            catch (Exception var1_15) {
                // empty catch block
            }
        }
        \u6bb5\u4f4d.\u8fed\u4ee3.open();
    }

    @Override
    public final void \u6293\u624b(IBinder iBinder, Intent intent) {
        \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda13(iBinder, intent));
    }

    @Override
    public final void \u6c89\u6dc0(IBinder iBinder) {
        \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda0(iBinder));
    }

    @Override
    public final void \u6f0f\u6597() {
        Process.killProcess((int)Process.myPid());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void \u805a\u7126() {
        block17 : {
            try {
                var3_1 = new \u6bb5\u4f4d$$ExternalSyntheticLambda18(\u592f\u5b9e.\u8d4b\u80fd);
                \u964d\u7ea7.\u6293\u624b.execute((Runnable)var3_1);
                var4_2 = \u6c34\u4f4d.\u4e2d\u53f0;
                "Creating process for " + var4_2;
                var6_3 = \u6c34\u4f4d.\u6293\u624b;
                var7_4 = new ArrayList();
                var9_5 = \u6c34\u4f4d.\u6f0f\u6597 != false ? (PackageInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u6bb5\u4f4d$$ExternalSyntheticLambda19(var6_3)) : (PackageInfo)\u98ce\u53e3.\u8d4b\u80fd(new \u6bb5\u4f4d$$ExternalSyntheticLambda20(var6_3));
                if (var9_5 != null) {
                    var10_6 = var9_5.applicationInfo;
                    \u8d44\u6e90\u4f4d.\u4e2d\u53f0.\u8d4b\u80fd(\u8d44\u6e90\u4f4d.\u8d4b\u80fd, new Object[]{var10_6.targetSdkVersion});
                    var12_7 = var9_5.providers;
                    if (var12_7 != null) {
                        \u6269\u5c55.\u8d4b\u80fd(var10_6);
                        var14_8 = var12_7.length;
                        var15_9 = 0;
                        break block17;
                    }
                }
                ** GOTO lbl33
            }
            catch (Throwable var1_21) {
                // empty catch block
            }
            return;
        }
        do {
            if (var15_9 < var14_8) {
                var16_10 = var12_7[var15_9];
                if (var16_10.authority != null && Intrinsics.areEqual((Object)var16_10.processName, (Object)var4_2) && var16_10.enabled) {
                    var16_10.applicationInfo = var10_6;
                    var7_4.add((Object)var16_10);
                }
            } else {
                if (var7_4.size() > 1) {
                    CollectionsKt.sortWith((List)var7_4, (Comparator)new \u5708\u5c42());
                }
lbl33: // 4 sources:
                var18_11 = \u6bb5\u4f4d.\u6c89\u6dc0;
                var19_12 = \u6bb5\u4f4d.\u6f0f\u6597;
                var18_11.\u8d4b\u80fd(var19_12, (Object)var7_4);
                \u6bb5\u4f4d.\u540c\u6b65.\u8d4b\u80fd(var19_12, (Object)var4_2);
                \u6bb5\u4f4d.\u8ddf\u8fdb.\u8d4b\u80fd((Object)null, new Object[]{var4_2});
                if (\u62bd\u8c61.\u7ed9\u5230) {
                    DdmHandleAppName.setAppName((String)var4_2, (String)var6_3, (int)\u98ce\u53e3.\u95ed\u73af);
                } else {
                    DdmHandleAppName.setAppName((String)var4_2, (int)\u98ce\u53e3.\u95ed\u73af);
                }
                \u6bb5\u4f4d.\u5bf9\u6807.\u8d4b\u80fd((Object)\u6bb5\u4f4d.\u4e2d\u53f0, (Object)null);
                if (\u62bd\u8c61.\u6f0f\u6597) {
                    \u8d44\u6e90\u4f4d.\u6293\u624b.\u8d4b\u80fd((Object)null, new Object[]{var6_3});
                    if (\u62bd\u8c61.\u6c89\u6dc0) {
                        var29_13 = \u8d44\u6e90\u4f4d.\u95ed\u73af;
                        var30_14 = new Object[]{\u6c34\u4f4d.\u843d\u5730};
                        var29_13.\u8d4b\u80fd((Object)null, var30_14);
                    }
                } else if (!\u62bd\u8c61.\u6293\u624b && (var22_15 = (String)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u6bb5\u4f4d$$ExternalSyntheticLambda21(var6_3))) != null && var22_15.length() != 0) {
                    Os.setenv((String)"EXTERNAL_STORAGE", (String)var22_15, (boolean)true);
                    Os.unsetenv((String)"EMULATED_STORAGE_TARGET");
                    Os.unsetenv((String)"SECONDARY_STORAGE");
                    var23_16 = \u4e0b\u6c89.\u6293\u624b;
                    try {
                        var27_17 = Environment.class.getDeclaredMethod("initForCurrentUser", var23_16);
                        var27_17.setAccessible(true);
                        var25_18 = new \u76ae\u5b9e(var27_17);
                    }
                    catch (Exception var24_19) {
                        var25_18 = \u81ea\u6d3d.\u8d4b\u80fd;
                    }
                    var25_18.\u8d4b\u80fd((Object)null, new Object[0]);
                }
                if ((var21_20 = \u6c34\u4f4d.\u7ed9\u5230).length() <= 0) return;
                \u6bb5\u4f4d.\u5347\u7ea7(var21_20);
                return;
            }
            ++var15_9;
        } while (true);
    }

    @Override
    public final void \u8d4b\u80fd(Intent intent, IBinder iBinder, String string) {
        if (string != null) {
            \u6a2a\u5411.\u8d4b\u80fd(intent, string);
            return;
        }
        \u6a2a\u5411.\u8d4b\u80fd(iBinder, intent);
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Intent intent) {
        \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda17(iBinder, intent));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void \u8d4b\u80fd(String string, Intent intent, IBinder iBinder, int n) {
        try {
            if (!\u6c34\u4f4d.\u8d4b\u80fd) {
                return;
            }
            if (\u4ea4\u4ed8.containsKey((Object)iBinder)) {
                if (n > 0 && intent != null) {
                    \u6bb5\u4f4d.\u8d4b\u80fd(iBinder, intent, n);
                }
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda12(string, intent, iBinder, n));
    }

    @Override
    public final void \u8d4b\u80fd(String string, String string2, String string3, boolean bl, String string4) {
        try {
            \u6c34\u4f4d.\u6293\u624b = string;
            \u6c34\u4f4d.\u4e2d\u53f0 = string2;
            \u6c34\u4f4d.\u95ed\u73af = string3;
            \u6c34\u4f4d.\u6f0f\u6597 = bl;
            File file = \u6253\u78e8.\u8d4b\u80fd(\u798f\u62a5.\u8d4b\u80fd, string, string3);
            if (file.mkdirs()) {
                \u8f6c\u5316.\u8d4b\u80fd(file);
            }
            \u6c34\u4f4d.\u843d\u5730 = file.getAbsolutePath();
            \u6c34\u4f4d.\u8d4b\u80fd = true;
            \u6c34\u4f4d.\u7ed9\u5230 = string4;
            \u95ed\u73af.post((Runnable)new \u6bb5\u4f4d$$ExternalSyntheticLambda7(this));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

