/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import java.io.Serializable;
import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda8
implements Function0 {
    public final /* synthetic */ Serializable f$0;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda8(Serializable serializable) {
        this.f$0 = serializable;
    }

    public final Object invoke() {
        return \u516c\u5173.\u8d4b\u80fd(this.f$0);
    }
}

