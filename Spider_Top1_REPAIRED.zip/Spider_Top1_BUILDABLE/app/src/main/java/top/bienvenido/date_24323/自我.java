/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.storage.StorageManager
 *  android.os.storage.StorageVolume
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.jvm.internal.ArrayIteratorKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.HexExtensionsKt
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u76ae\u5b9e
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.os.Build;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.ArrayIteratorKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.HexExtensionsKt;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u76ae\u5b9e;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u81ea\u6211 {
    public static File \u8d4b\u80fd;

    static {
        Context context = \u98ce\u53e3.\u8d4b\u80fd;
        File file = context.getObbDir();
        if (file == null) {
            file = context.getCodeCacheDir();
        }
        String string2 = \u98ce\u53e3.\u6293\u624b;
        String string3 = Build.MANUFACTURER;
        String string4 = Build.MODEL;
        String string5 = Build.BRAND;
        \u8d4b\u80fd = new File(file, HexExtensionsKt.toHexString$default((int)(string2 + "c1st" + string3 + string4 + string5).hashCode(), null, (int)1, null));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static void \u8d4b\u80fd() {
        block8 : {
            var1 = \u98ce\u53e3.\u8d4b\u80fd;
            var2_1 = (StorageManager)var1.getSystemService("storage");
            var3_2 = var1.getObbDirs();
            if (!\u62bd\u8c61.\u4e2d\u53f0) break block8;
            var7_3 = var2_1.getStorageVolumes().iterator();
            ** GOTO lbl19
        }
        var4_4 = \u4e0b\u6c89.\u6293\u624b;
        try {
            var18_5 = StorageManager.class.getDeclaredMethod("getVolumeList", var4_4);
            var18_5.setAccessible(true);
            var6_6 = new \u76ae\u5b9e(var18_5);
            ** GOTO lbl18
        }
        catch (Exception var5_7) {
            var6_6 = \u81ea\u6d3d.\u8d4b\u80fd;
lbl18: // 2 sources:
            var7_3 = ArrayIteratorKt.iterator((Object[])((StorageVolume[])var6_6.\u8d4b\u80fd((Object)var2_1, new Object[0])));
lbl19: // 2 sources:
            var8_8 = \u771f\u9999.\u8d4b\u80fd(StorageVolume.class, "mPath");
            while (var7_3.hasNext()) {
                var9_9 = (StorageVolume)var7_3.next();
                if (!var9_9.isRemovable() || !Intrinsics.areEqual((Object)var9_9.getState(), (Object)"mounted") || (var10_10 = (File)var8_8.\u8d4b\u80fd((Object)var9_9)) == null) continue;
                var11_11 = var3_2.length;
                var12_12 = 0;
lbl25: // 2 sources:
                while (var12_12 < var11_11) {
                    var13_13 = var3_2[var12_12];
                    if (StringsKt.startsWith$default((String)var13_13.getAbsolutePath(), (String)var10_10.getAbsolutePath(), (boolean)false, (int)2, null)) {
                        var14_14 = \u98ce\u53e3.\u6293\u624b;
                        var15_15 = Build.MANUFACTURER;
                        var16_16 = Build.MODEL;
                        var17_17 = Build.BRAND;
                        \u81ea\u6211.\u8d4b\u80fd = new File(var13_13, HexExtensionsKt.toHexString$default((int)(var14_14 + "c1st" + var15_15 + var16_16 + var17_17).hashCode(), null, (int)1, null));
                        return;
                    }
                }
            }
        }
        {
            ++var12_12;
            ** GOTO lbl25
            break;
        }
        {
            catch (Exception var0_18) {
                // empty catch block
            }
        }
    }
}

