/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationManager
 *  android.widget.Toast
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u8425\u6536
 *  top.bienvenido.date_24323.\u89e6\u70b9
 *  top.bienvenido.date_24323.\u9b54\u65b9
 */
package top.bienvenido.date_24323;

import android.app.NotificationManager;
import android.widget.Toast;
import top.bienvenido.date_24323.\u516c\u57df;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u529b\u573a;
import top.bienvenido.date_24323.\u52bf\u80fd;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8425\u6536;
import top.bienvenido.date_24323.\u89e6\u70b9;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.date_24323.\u9b54\u65b9;

public final class \u6d41\u91cf
extends \u96c6\u6210 {
    public static final \u6d41\u91cf \u6293\u624b = new \u6d41\u91cf();

    @Override
    public final void \u8d4b\u80fd() {
        \u8425\u6536 \u8425\u65362 = \u8425\u6536.\u6293\u624b;
        this.\u8d4b\u80fd = \u8425\u65362;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("notification", (\u89e6\u8fbe)\u8425\u65362, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u771f\u9999.\u8d4b\u80fd(NotificationManager.class, "sService", \u51fa\u51fb2.\u95ed\u73af);
        \u771f\u9999.\u8d4b\u80fd(Toast.class, "sService", \u51fa\u51fb2.\u95ed\u73af);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{396339264, 1115161719}, \u672c\u6211.\u5e73\u53f0);
        if (\u62bd\u8c61.\u843d\u5730) {
            \u529b\u573a \u529b\u573a2 = new \u529b\u573a();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1035691422, \u529b\u573a2);
            \u9b54\u65b9 \u9b54\u65b92 = new \u9b54\u65b9();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-282102537, (Object)\u9b54\u65b92);
            \u89e6\u70b9 \u89e6\u70b92 = new \u89e6\u70b9();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-2041662895, (Object)\u89e6\u70b92);
            \u52bf\u80fd \u52bf\u80fd2 = new \u52bf\u80fd();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1008472557, \u52bf\u80fd2);
        }
    }
}

