/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import top.bienvenido.date_24323.\u75d2\u70b9;
import top.bienvenido.date_24323.\u8ba2\u9605;

public abstract class \u81f4\u656c
extends Binder
implements \u8ba2\u9605 {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u81f4\u656c() {
        this.attachInterface((IInterface)this, "MundoContentService");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        if (n >= 1 && n <= 16777215) {
            parcel.enforceInterface("MundoContentService");
        }
        if (n == 1598968902) {
            parcel2.writeString("MundoContentService");
            return true;
        }
        Object object = null;
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                Parcelable.Creator creator = Uri.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Uri uri = (Uri)object;
                IBinder iBinder = parcel.readStrongBinder();
                int n3 = parcel.readInt();
                boolean bl = false;
                if (n3 != 0) {
                    bl = true;
                }
                ((\u75d2\u70b9)this).\u8d4b\u80fd(uri, iBinder, bl);
                parcel2.writeNoException();
                return true;
            }
            IBinder iBinder = parcel.readStrongBinder();
            ((\u75d2\u70b9)this).\u843d\u5730(iBinder);
            parcel2.writeNoException();
            return true;
        }
        Parcelable.Creator creator = Uri.CREATOR;
        if (parcel.readInt() != 0) {
            object = creator.createFromParcel(parcel);
        }
        Uri uri = (Uri)object;
        int n4 = parcel.readInt();
        boolean bl = false;
        if (n4 != 0) {
            bl = true;
        }
        IBinder iBinder = parcel.readStrongBinder();
        ((\u75d2\u70b9)this).\u6293\u624b(uri, iBinder, bl);
        parcel2.writeNoException();
        return true;
    }
}

