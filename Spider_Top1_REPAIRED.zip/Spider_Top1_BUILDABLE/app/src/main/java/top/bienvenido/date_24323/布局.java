/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import java.util.List;

public interface \u5e03\u5c40
extends IInterface {
    public void \u4e2d\u53f0(String var1);

    public boolean \u4e2d\u53f0();

    public boolean \u6293\u624b(String var1, String var2);

    public void \u6c89\u6dc0(String var1, String var2);

    public void \u6f0f\u6597(IBinder var1);

    public String \u7ed9\u5230(IBinder var1);

    public void \u843d\u5730(String var1, String var2);

    public ComponentName \u8d4b\u80fd(IBinder var1);

    public Intent \u8d4b\u80fd(long var1, Intent var3);

    public Intent \u8d4b\u80fd(IBinder var1, Intent var2, int var3, boolean var4);

    public String \u8d4b\u80fd();

    public List \u8d4b\u80fd(long var1);

    public List \u8d4b\u80fd(long var1, int var3);

    public void \u8d4b\u80fd(Intent var1, String var2);

    public void \u8d4b\u80fd(IBinder var1, IBinder var2);

    public void \u8d4b\u80fd(IBinder var1, String var2, String var3, String var4, int var5);

    public void \u8d4b\u80fd(String var1);

    public Intent[] \u8d4b\u80fd(IBinder var1, Intent[] var2, int var3);

    public boolean \u95ed\u73af(IBinder var1);
}

