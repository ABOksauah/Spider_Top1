/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  java.io.File
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageManager;
import java.io.File;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u9884\u5224;

public final class \u9884\u5224$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ File f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ \u9884\u5224$$ExternalSyntheticLambda0(File file, int n) {
        this.f$0 = file;
        this.f$1 = n;
    }

    public final Object invoke(Object object) {
        return \u9884\u5224.\u8d4b\u80fd(this.f$0, this.f$1, (PackageManager)object);
    }
}

