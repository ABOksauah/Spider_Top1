/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.util.AbstractSet
 *  java.util.Iterator
 *  top.bienvenido.date_24323.\u5f00\u62d3
 */
package top.bienvenido.date_24323;

import java.util.AbstractSet;
import java.util.Iterator;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u5f00\u62d3;
import top.bienvenido.date_24323.\u6301\u7eed;
import top.bienvenido.date_24323.\u7075\u6d3b;

public final class \u7cbe\u51c6
extends AbstractSet {
    public final /* synthetic */ \u7075\u6d3b \u8d4b\u80fd;

    public \u7cbe\u51c6(\u7075\u6d3b \u7075\u6d3b2) {
        this.\u8d4b\u80fd = \u7075\u6d3b2;
    }

    public final Iterator iterator() {
        return new \u6301\u7eed(this.\u8d4b\u80fd);
    }

    public final int size() {
        return ((\u5f00\u62d3)this.\u8d4b\u80fd).\u6293\u624b.\u4e2d\u53f0;
    }
}

