/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.android.internal.infra.AndroidFuture
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import com.android.internal.infra.AndroidFuture;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u79c0\u808c\u8089
extends \u89e6\u53d1 {
    public final AndroidFuture \u6293\u624b = AndroidFuture.completedFuture(null);

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (AndroidFuture.class.isAssignableFrom(method.getReturnType())) {
            return this.\u6293\u624b;
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

