/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.collections.ArraysKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$ObjectRef
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Ref;
import top.bienvenido.date_24323.\u57fa\u77f3$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u57fa\u77f3
extends \u89e6\u53d1 {
    public static final Intent[] \u8d4b\u80fd(Ref.ObjectRef objectRef, Intent[] arrintent, \u5e03\u5c40 \u5e03\u5c402) {
        return \u5e03\u5c402.\u8d4b\u80fd((IBinder)objectRef.element, arrintent, \u6c34\u4f4d.\u6c89\u6dc0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        int n;
        int n2;
        Ref.ObjectRef objectRef;
        block8 : {
            int n3;
            block7 : {
                if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
                try {
                    n = ArraysKt.indexOf((Object[])method.getParameterTypes(), IBinder.class);
                    objectRef = new Ref.ObjectRef();
                    if (n >= 0) {
                        objectRef.element = (IBinder)arrobject[n];
                    }
                    n3 = arrobject.length;
                    break block7;
                }
                catch (Exception exception) {
                    // empty catch block
                }
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            for (n2 = 0; n2 < n3; ++n2) {
                if (!Intent[].class.isInstance(arrobject[n2])) {
                    continue;
                }
                break block8;
            }
            n2 = -1;
        }
        if (n2 < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        Intent[] arrintent = (Intent[])arrobject[n2];
        IBinder[] arriBinder = new IBinder[1];
        Intent[] arrintent2 = (Intent[])\u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u57fa\u77f3$$ExternalSyntheticLambda0(objectRef, arrintent));
        if (arrintent2 == null) return super.\u8d4b\u80fd(object, method, arrobject);
        if (arrintent2.length == 0) {
            return 0;
        }
        IBinder iBinder = arriBinder[0];
        if (iBinder != null && n >= 0) {
            arrobject[n] = iBinder;
        }
        arrobject[n2] = arrintent2;
        if (arrintent2.length == arrintent.length) return super.\u8d4b\u80fd(object, method, arrobject);
        int n4 = n2 + 1;
        if (!String[].class.isInstance(arrobject[n4])) return super.\u8d4b\u80fd(object, method, arrobject);
        arrobject[n4] = new String[arrintent2.length];
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

