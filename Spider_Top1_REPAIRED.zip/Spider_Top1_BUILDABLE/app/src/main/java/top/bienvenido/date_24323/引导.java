/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityClient
 *  android.app.ActivityTaskManager
 *  android.app.ActivityThread
 *  android.app.ActivityThread$ActivityClientRecord
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.IBinder
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.Set
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.app.ActivityClient;
import android.app.ActivityTaskManager;
import android.app.ActivityThread;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import java.lang.reflect.Method;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u5f15\u5bfc
extends \u89e6\u8fbe {
    public static final \u5f15\u5bfc \u8d4b\u80fd = new \u5f15\u5bfc();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = arrobject[0];
        if (!\u6c34\u4f4d.\u8d4b\u80fd || !(object2 instanceof IBinder)) return method.invoke(object, arrobject);
        \u6bb5\u4f4d.\u6293\u624b.getClass();
        ActivityThread.ActivityClientRecord activityClientRecord = \u6bb5\u4f4d.\u4e2d\u53f0.getActivityClient((IBinder)object2);
        if (activityClientRecord == null) return method.invoke(object, arrobject);
        Intent intent = (Intent)\u51b7\u542f\u52a8.\u843d\u5730.\u6293\u624b.\u8d4b\u80fd((Object)activityClientRecord);
        if (intent == null) return method.invoke(object, arrobject);
        try {
            if (!Intrinsics.areEqual((Object)"android.intent.action.MAIN", (Object)intent.getAction()) || !intent.hasCategory("android.intent.category.LAUNCHER") || intent.getCategories().size() != 1 || intent.getData() != null || intent.getType() != null) return method.invoke(object, arrobject);
            if (\u62bd\u8c61.\u5e73\u53f0) {
                ActivityClient.getInstance().moveActivityTaskToBack((IBinder)object2, false);
                return null;
            } else {
                ActivityTaskManager.getService().moveActivityTaskToBack((IBinder)object2, false);
            }
            return null;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

