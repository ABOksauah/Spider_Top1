/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5171\u521b;
import top.bienvenido.date_24323.\u5e03\u5c40;

public final class \u5171\u521b$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u5171\u521b$$ExternalSyntheticLambda0(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final Object invoke(Object object) {
        return \u5171\u521b.\u8d4b\u80fd(this.f$0, (\u5e03\u5c40)object);
    }
}

