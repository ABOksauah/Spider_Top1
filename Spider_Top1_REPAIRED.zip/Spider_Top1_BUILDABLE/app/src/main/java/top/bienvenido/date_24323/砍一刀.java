/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.Signature
 *  android.os.Binder
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcelable$Creator
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Proxy
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcelable;
import java.lang.reflect.Proxy;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8d77\u98de;

public abstract class \u780d\u4e00\u5200 {
    public static final \u8d77\u98de \u8d4b\u80fd = new \u8d77\u98de("mPM");

    public static Object \u8d4b\u80fd(Context context) {
        Object object;
        block14 : {
            IBinder iBinder;
            block15 : {
                block13 : {
                    \u8d77\u98de \u8d77\u98de2;
                    PackageManager packageManager;
                    block12 : {
                        block11 : {
                            block10 : {
                                try {
                                    if (Intrinsics.areEqual((Object)PackageInfo.CREATOR.getClass().getClassLoader(), (Object)PackageInfo.class.getClassLoader())) break block10;
                                    return null;
                                }
                                catch (Exception exception) {
                                    return null;
                                }
                            }
                            if (Intrinsics.areEqual((Object)Signature.CREATOR.getClass().getClassLoader(), (Object)Signature.class.getClassLoader())) break block11;
                            return null;
                        }
                        \u8d77\u98de2 = \u8d4b\u80fd;
                        try {
                            packageManager = context.getApplicationContext().getPackageManager();
                            boolean bl = Intrinsics.areEqual((Object)packageManager.getClass().getClassLoader(), (Object)PackageManager.class.getClassLoader());
                            if (bl) break block12;
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                        packageManager = null;
                    }
                    if (packageManager == null) {
                        return null;
                    }
                    object = \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)packageManager);
                    if (object != null) break block13;
                    return null;
                }
                if (!(object instanceof IInterface)) break block14;
                iBinder = ((IInterface)object).asBinder();
                if (Intrinsics.areEqual((Object)iBinder.getClass().getClassLoader(), (Object)Binder.class.getClassLoader())) break block15;
                return null;
            }
            boolean bl = Proxy.isProxyClass((Class)iBinder.getClass());
            if (!bl) break block14;
            return null;
        }
        return object;
    }
}

