/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import net_62v.external.\u8d4b\u80fd;

public final class \u7ec4\u5c40 {
    public static \u8d4b\u80fd \u8d4b\u80fd;
}

