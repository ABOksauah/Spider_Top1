/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda16
implements Runnable {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda16(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final void run() {
        \u5408\u529b.\u5e73\u53f0((IBinder)this.f$0);
    }
}

