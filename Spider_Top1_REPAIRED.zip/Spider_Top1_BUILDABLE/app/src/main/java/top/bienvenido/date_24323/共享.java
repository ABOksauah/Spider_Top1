/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.net.Uri
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.Set
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u6536\u5272
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u5c01\u88c5;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6536\u5272;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u8bb2\u6545\u4e8b;

public abstract class \u5171\u4eab {
    public final \u6241\u5e73\u5316 \u4e2d\u53f0 = new \u6241\u5e73\u5316(0);
    public final \u6241\u5e73\u5316 \u6293\u624b = new \u6241\u5e73\u5316(0);
    public final \u6241\u5e73\u5316 \u6f0f\u6597 = new \u6241\u5e73\u5316(0);
    public final \u6241\u5e73\u5316 \u843d\u5730 = new \u6241\u5e73\u5316(0);
    public final \u6241\u5e73\u5316 \u8d4b\u80fd = new \u6241\u5e73\u5316(0);
    public final \u6241\u5e73\u5316 \u95ed\u73af = new \u6241\u5e73\u5316(0);

    public static void \u8d4b\u80fd(\u6241\u5e73\u5316 \u6241\u5e73\u53162, String string2, IntentFilter intentFilter) {
        int n = string2.hashCode();
        \u6241\u5e73\u5316 \u6241\u5e73\u53163 = (\u6241\u5e73\u5316)\u6241\u5e73\u53162.\u8d4b\u80fd(n);
        if (\u6241\u5e73\u53163 != null && \u6241\u5e73\u53163.\u6293\u624b(intentFilter.hashCode()) && \u6241\u5e73\u53163.\u4e2d\u53f0 == 0) {
            \u6241\u5e73\u53162.\u6293\u624b(n);
        }
    }

    public final int \u4e2d\u53f0(IntentFilter intentFilter) {
        Iterator iterator = intentFilter.typesIterator();
        if (iterator == null) {
            return 0;
        }
        int n = 0;
        while (iterator.hasNext()) {
            Object object;
            Object object2;
            String string2;
            String string3 = (String)iterator.next();
            ++n;
            int n2 = StringsKt.indexOf$default((CharSequence)string3, (char)'/', (int)0, (boolean)false, (int)6, null);
            if (n2 > 0) {
                string2 = StringsKt.take((String)string3, (int)n2).intern();
            } else {
                String string4 = string3 + "/*";
                string2 = string3;
                string3 = string4;
            }
            \u6241\u5e73\u5316 \u6241\u5e73\u53162 = this.\u8d4b\u80fd;
            int n3 = string3.hashCode();
            \u6536\u5272 \u6536\u52722 = \u6536\u5272.\u8d4b\u80fd;
            int[] arrn = \u6241\u5e73\u53162.\u8d4b\u80fd;
            int n4 = \u6241\u5e73\u53162.\u4e2d\u53f0;
            int n5 = \u753b\u997c.\u8d4b\u80fd(arrn, n4, n3);
            if (n5 >= 0) {
                object2 = \u6241\u5e73\u53162.\u6293\u624b[n5];
            } else {
                int n6;
                int n7 = n5;
                \u6241\u5e73\u53162.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n4, n7, n3);
                \u6241\u5e73\u53162.\u4e2d\u53f0 = n6 = n4 + 1;
                Object object3 = \u6536\u52722.invoke();
                Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
                if (n6 <= arrobject.length) {
                    System.arraycopy((Object)arrobject, (int)n7, (Object)arrobject, (int)(n7 + 1), (int)(n4 - n7));
                    arrobject[n7] = object3;
                } else {
                    Object[] arrobject2 = new Object[(n4 | 1) << 1];
                    System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n7);
                    arrobject2[n7] = object3;
                    System.arraycopy((Object)arrobject, (int)n7, (Object)arrobject2, (int)(n7 + 1), (int)(arrobject.length - n7));
                    arrobject = arrobject2;
                }
                \u6241\u5e73\u53162.\u6293\u624b = arrobject;
                object2 = object3;
            }
            ((\u6241\u5e73\u5316)object2).\u8d4b\u80fd(intentFilter.hashCode(), (Object)intentFilter);
            \u6241\u5e73\u5316 \u6241\u5e73\u53163 = n2 > 0 ? this.\u6293\u624b : this.\u4e2d\u53f0;
            int n8 = string2.hashCode();
            int[] arrn2 = \u6241\u5e73\u53163.\u8d4b\u80fd;
            int n9 = \u6241\u5e73\u53163.\u4e2d\u53f0;
            int n10 = \u753b\u997c.\u8d4b\u80fd(arrn2, n9, n8);
            if (n10 >= 0) {
                object = \u6241\u5e73\u53163.\u6293\u624b[n10];
            } else {
                int n11;
                int n12 = n10;
                \u6241\u5e73\u53163.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn2, n9, n12, n8);
                \u6241\u5e73\u53163.\u4e2d\u53f0 = n11 = n9 + 1;
                Object object4 = \u6536\u52722.invoke();
                Object[] arrobject = \u6241\u5e73\u53163.\u6293\u624b;
                if (n11 <= arrobject.length) {
                    System.arraycopy((Object)arrobject, (int)n12, (Object)arrobject, (int)(n12 + 1), (int)(n9 - n12));
                    arrobject[n12] = object4;
                } else {
                    Object[] arrobject3 = new Object[(n9 | 1) << 1];
                    System.arraycopy((Object)arrobject, (int)0, (Object)arrobject3, (int)0, (int)n12);
                    arrobject3[n12] = object4;
                    System.arraycopy((Object)arrobject, (int)n12, (Object)arrobject3, (int)(n12 + 1), (int)(arrobject.length - n12));
                    arrobject = arrobject3;
                }
                \u6241\u5e73\u53163.\u6293\u624b = arrobject;
                object = object4;
            }
            ((\u6241\u5e73\u5316)object).\u8d4b\u80fd(intentFilter.hashCode(), (Object)intentFilter);
        }
        return n;
    }

    public abstract int \u6293\u624b(IntentFilter var1);

    public abstract Object \u8d4b\u80fd(IntentFilter var1, int var2, int var3);

    public final ArrayList \u8d4b\u80fd(Intent intent, String string2, boolean bl, int n) {
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        \u6241\u5e73\u5316 \u6241\u5e73\u53163;
        String string3;
        \u5e73\u53f0\u5316 \u5e73\u53f0\u53162;
        \u6241\u5e73\u5316 \u6241\u5e73\u53164;
        \u6241\u5e73\u5316 \u6241\u5e73\u53165;
        \u6241\u5e73\u5316 \u6241\u5e73\u53166;
        ArrayList arrayList;
        String string4;
        block11 : {
            block9 : {
                int n2;
                block10 : {
                    string4 = intent.getScheme();
                    arrayList = new ArrayList();
                    string3 = intent.getAction();
                    if (string2 == null || (n2 = StringsKt.indexOf$default((CharSequence)string2, (char)'/', (int)0, (boolean)false, (int)6, null)) <= 0) break block9;
                    if (n2 != 1 || string2.charAt(0) != '*') break block10;
                    if (string3 == null) break block9;
                    \u6241\u5e73\u53166 = (\u6241\u5e73\u5316)this.\u6f0f\u6597.\u8d4b\u80fd(string3.hashCode());
                    \u6241\u5e73\u53163 = null;
                    \u6241\u5e73\u53164 = null;
                    break block11;
                }
                int n3 = StringsKt.take((String)string2, (int)n2).hashCode();
                \u6241\u5e73\u53166 = string2.length() == n2 + 2 && string2.charAt(n2 + 1) == '*' ? (\u6241\u5e73\u5316)this.\u6293\u624b.\u8d4b\u80fd(n3) : (\u6241\u5e73\u5316)this.\u8d4b\u80fd.\u8d4b\u80fd(string2.hashCode());
                \u6241\u5e73\u5316 \u6241\u5e73\u53167 = (\u6241\u5e73\u5316)this.\u4e2d\u53f0.\u8d4b\u80fd(n3);
                \u6241\u5e73\u5316 \u6241\u5e73\u53168 = (\u6241\u5e73\u5316)this.\u4e2d\u53f0.\u8d4b\u80fd(42);
                \u6241\u5e73\u53163 = \u6241\u5e73\u53167;
                \u6241\u5e73\u53164 = \u6241\u5e73\u53168;
                break block11;
            }
            \u6241\u5e73\u53166 = null;
            \u6241\u5e73\u53163 = null;
            \u6241\u5e73\u53164 = null;
        }
        if (string4 != null) {
            \u6241\u5e73\u5316 \u6241\u5e73\u53169 = (\u6241\u5e73\u5316)this.\u95ed\u73af.\u8d4b\u80fd(string4.hashCode());
            \u6241\u5e73\u53165 = \u6241\u5e73\u53166;
            \u6241\u5e73\u53162 = \u6241\u5e73\u53169;
        } else if (string2 == null && string3 != null) {
            \u6241\u5e73\u53165 = (\u6241\u5e73\u5316)this.\u843d\u5730.\u8d4b\u80fd(string3.hashCode());
            \u6241\u5e73\u53162 = null;
        } else {
            \u6241\u5e73\u53165 = \u6241\u5e73\u53166;
            \u6241\u5e73\u53162 = null;
        }
        Set set = intent.getCategories();
        \u5e73\u53f0\u5316 \u5e73\u53f0\u53163 = new \u5e73\u53f0\u5316(8);
        if (\u6241\u5e73\u53165 != null) {
            \u5e73\u53f0\u53162 = \u5e73\u53f0\u53163;
            this.\u8d4b\u80fd(intent, set, bl, string2, string4, \u6241\u5e73\u53165, arrayList, n, \u5e73\u53f0\u53163);
        } else {
            \u5e73\u53f0\u53162 = \u5e73\u53f0\u53163;
        }
        if (\u6241\u5e73\u53163 != null) {
            this.\u8d4b\u80fd(intent, set, bl, string2, string4, \u6241\u5e73\u53163, arrayList, n, \u5e73\u53f0\u53162);
        }
        if (\u6241\u5e73\u53164 != null) {
            this.\u8d4b\u80fd(intent, set, bl, string2, string4, \u6241\u5e73\u53164, arrayList, n, \u5e73\u53f0\u53162);
        }
        if (\u6241\u5e73\u53162 != null) {
            this.\u8d4b\u80fd(intent, set, bl, string2, string4, \u6241\u5e73\u53162, arrayList, n, \u5e73\u53f0\u53162);
        }
        return arrayList;
    }

    public final void \u8d4b\u80fd(Intent intent, Set set, boolean bl, String string2, String string3, \u6241\u5e73\u5316 \u6241\u5e73\u53162, ArrayList arrayList, int n, \u5e73\u53f0\u5316 \u5e73\u53f0\u53162) {
        String string4 = intent.getAction();
        Uri uri = intent.getData();
        String string5 = intent.getPackage();
        int n2 = 0;
        while (n2 < \u6241\u5e73\u53162.\u4e2d\u53f0) {
            int n3;
            int n4;
            Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
            int n5 = n2 + 1;
            IntentFilter intentFilter = (IntentFilter)arrobject[n2];
            if (this.\u8d4b\u80fd(string5, intentFilter) && (n4 = \u753b\u997c.\u8d4b\u80fd(\u5e73\u53f0\u53162.\u8d4b\u80fd, \u5e73\u53f0\u53162.\u6293\u624b, n3 = this.\u6293\u624b(intentFilter))) < 0 && (!bl || intentFilter.hasCategory("android.intent.category.DEFAULT"))) {
                Object object;
                int n6 = intentFilter.match(string4, string2, string3, uri, set, null);
                if (n6 >= 0 && (object = this.\u8d4b\u80fd(intentFilter, n6, n)) != null) {
                    arrayList.add(object);
                    int n7 = \u5e73\u53f0\u53162.\u6293\u624b;
                    int[] arrn = \u5e73\u53f0\u53162.\u8d4b\u80fd;
                    int n8 = n4;
                    int n9 = n7 + 1;
                    if (n9 <= arrn.length) {
                        System.arraycopy((Object)arrn, (int)n8, (Object)arrn, (int)(n8 + 1), (int)(n7 - n8));
                        arrn[n8] = n3;
                    } else {
                        int[] arrn2 = new int[(n7 | 1) << 1];
                        System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)n8);
                        arrn2[n8] = n3;
                        System.arraycopy((Object)arrn, (int)n8, (Object)arrn2, (int)(n8 + 1), (int)(arrn.length - n8));
                        arrn = arrn2;
                    }
                    \u5e73\u53f0\u53162.\u8d4b\u80fd = arrn;
                    \u5e73\u53f0\u53162.\u6293\u624b = n9;
                }
            }
            n2 = n5;
        }
    }

    public void \u8d4b\u80fd(IntentFilter intentFilter) {
        Iterator iterator = intentFilter.schemesIterator();
        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = this.\u95ed\u73af;
        int n = 0;
        if (iterator == null) {
            n = 0;
        } else {
            while (iterator.hasNext()) {
                Object object;
                String string2 = (String)iterator.next();
                ++n;
                int n2 = string2.hashCode();
                \u6536\u5272 \u6536\u52722 = \u6536\u5272.\u8d4b\u80fd;
                int[] arrn = \u6241\u5e73\u53162.\u8d4b\u80fd;
                int n3 = \u6241\u5e73\u53162.\u4e2d\u53f0;
                int n4 = \u753b\u997c.\u8d4b\u80fd(arrn, n3, n2);
                if (n4 >= 0) {
                    object = \u6241\u5e73\u53162.\u6293\u624b[n4];
                } else {
                    int n5;
                    int n6 = n4;
                    \u6241\u5e73\u53162.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n3, n6, n2);
                    \u6241\u5e73\u53162.\u4e2d\u53f0 = n5 = n3 + 1;
                    Object object2 = \u6536\u52722.invoke();
                    Object[] arrobject = \u6241\u5e73\u53162.\u6293\u624b;
                    if (n5 <= arrobject.length) {
                        System.arraycopy((Object)arrobject, (int)n6, (Object)arrobject, (int)(n6 + 1), (int)(n3 - n6));
                        arrobject[n6] = object2;
                    } else {
                        Object[] arrobject2 = new Object[(n3 | 1) << 1];
                        System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n6);
                        arrobject2[n6] = object2;
                        System.arraycopy((Object)arrobject, (int)n6, (Object)arrobject2, (int)(n6 + 1), (int)(arrobject.length - n6));
                        arrobject = arrobject2;
                    }
                    \u6241\u5e73\u53162.\u6293\u624b = arrobject;
                    object = object2;
                }
                ((\u6241\u5e73\u5316)object).\u8d4b\u80fd(intentFilter.hashCode(), (Object)intentFilter);
            }
        }
        int n7 = this.\u4e2d\u53f0(intentFilter);
        if (n == 0 && n7 == 0) {
            Iterator iterator2 = intentFilter.actionsIterator();
            \u6241\u5e73\u5316 \u6241\u5e73\u53163 = this.\u843d\u5730;
            if (iterator2 != null) {
                while (iterator2.hasNext()) {
                    Object object;
                    int n8 = ((String)iterator2.next()).hashCode();
                    \u6536\u5272 \u6536\u52723 = \u6536\u5272.\u8d4b\u80fd;
                    int[] arrn = \u6241\u5e73\u53163.\u8d4b\u80fd;
                    int n9 = \u6241\u5e73\u53163.\u4e2d\u53f0;
                    int n10 = \u753b\u997c.\u8d4b\u80fd(arrn, n9, n8);
                    if (n10 >= 0) {
                        object = \u6241\u5e73\u53163.\u6293\u624b[n10];
                    } else {
                        int n11;
                        int n12 = n10;
                        \u6241\u5e73\u53163.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n9, n12, n8);
                        \u6241\u5e73\u53163.\u4e2d\u53f0 = n11 = n9 + 1;
                        Object object3 = \u6536\u52723.invoke();
                        Object[] arrobject = \u6241\u5e73\u53163.\u6293\u624b;
                        if (n11 <= arrobject.length) {
                            System.arraycopy((Object)arrobject, (int)n12, (Object)arrobject, (int)(n12 + 1), (int)(n9 - n12));
                            arrobject[n12] = object3;
                        } else {
                            Object[] arrobject3 = new Object[(n9 | 1) << 1];
                            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject3, (int)0, (int)n12);
                            arrobject3[n12] = object3;
                            System.arraycopy((Object)arrobject, (int)n12, (Object)arrobject3, (int)(n12 + 1), (int)(arrobject.length - n12));
                            arrobject = arrobject3;
                        }
                        \u6241\u5e73\u53163.\u6293\u624b = arrobject;
                        object = object3;
                    }
                    ((\u6241\u5e73\u5316)object).\u8d4b\u80fd(intentFilter.hashCode(), (Object)intentFilter);
                }
            }
        }
        if (n7 != 0) {
            Iterator iterator3 = intentFilter.actionsIterator();
            \u6241\u5e73\u5316 \u6241\u5e73\u53164 = this.\u6f0f\u6597;
            if (iterator3 == null) {
                return;
            }
            while (iterator3.hasNext()) {
                Object object;
                int n13 = ((String)iterator3.next()).hashCode();
                \u6536\u5272 \u6536\u52724 = \u6536\u5272.\u8d4b\u80fd;
                int[] arrn = \u6241\u5e73\u53164.\u8d4b\u80fd;
                int n14 = \u6241\u5e73\u53164.\u4e2d\u53f0;
                int n15 = \u753b\u997c.\u8d4b\u80fd(arrn, n14, n13);
                if (n15 >= 0) {
                    object = \u6241\u5e73\u53164.\u6293\u624b[n15];
                } else {
                    int n16;
                    int n17 = n15;
                    \u6241\u5e73\u53164.\u8d4b\u80fd = \u8bb2\u6545\u4e8b.\u8d4b\u80fd(arrn, n14, n17, n13);
                    \u6241\u5e73\u53164.\u4e2d\u53f0 = n16 = n14 + 1;
                    Object object4 = \u6536\u52724.invoke();
                    Object[] arrobject = \u6241\u5e73\u53164.\u6293\u624b;
                    if (n16 <= arrobject.length) {
                        System.arraycopy((Object)arrobject, (int)n17, (Object)arrobject, (int)(n17 + 1), (int)(n14 - n17));
                        arrobject[n17] = object4;
                    } else {
                        Object[] arrobject4 = new Object[(n14 | 1) << 1];
                        System.arraycopy((Object)arrobject, (int)0, (Object)arrobject4, (int)0, (int)n17);
                        arrobject4[n17] = object4;
                        System.arraycopy((Object)arrobject, (int)n17, (Object)arrobject4, (int)(n17 + 1), (int)(arrobject.length - n17));
                        arrobject = arrobject4;
                    }
                    \u6241\u5e73\u53164.\u6293\u624b = arrobject;
                    object = object4;
                }
                ((\u6241\u5e73\u5316)object).\u8d4b\u80fd(intentFilter.hashCode(), (Object)intentFilter);
            }
        }
    }

    public void \u8d4b\u80fd(\u5c01\u88c5 \u5c01\u88c52) {
        Iterator iterator = \u5c01\u88c52.schemesIterator();
        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = this.\u95ed\u73af;
        int n = 0;
        if (iterator == null) {
            n = 0;
        } else {
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                ++n;
                \u5171\u4eab.\u8d4b\u80fd(\u6241\u5e73\u53162, string2, \u5c01\u88c52);
            }
        }
        int n2 = this.\u95ed\u73af(\u5c01\u88c52);
        if (n == 0 && n2 == 0) {
            Iterator iterator2 = \u5c01\u88c52.actionsIterator();
            \u6241\u5e73\u5316 \u6241\u5e73\u53163 = this.\u843d\u5730;
            if (iterator2 != null) {
                while (iterator2.hasNext()) {
                    \u5171\u4eab.\u8d4b\u80fd(\u6241\u5e73\u53163, (String)iterator2.next(), \u5c01\u88c52);
                }
            }
        }
        if (n2 != 0) {
            Iterator iterator3 = \u5c01\u88c52.actionsIterator();
            \u6241\u5e73\u5316 \u6241\u5e73\u53164 = this.\u6f0f\u6597;
            if (iterator3 == null) {
                return;
            }
            while (iterator3.hasNext()) {
                \u5171\u4eab.\u8d4b\u80fd(\u6241\u5e73\u53164, (String)iterator3.next(), \u5c01\u88c52);
            }
        }
    }

    public boolean \u8d4b\u80fd(String string2, IntentFilter intentFilter) {
        return true;
    }

    public final int \u95ed\u73af(IntentFilter intentFilter) {
        Iterator iterator = intentFilter.typesIterator();
        int n = 0;
        if (iterator == null) {
            return 0;
        }
        while (iterator.hasNext()) {
            String string2;
            String string3 = (String)iterator.next();
            ++n;
            int n2 = StringsKt.indexOf$default((CharSequence)string3, (char)'/', (int)0, (boolean)false, (int)6, null);
            if (n2 > 0) {
                string2 = StringsKt.take((String)string3, (int)n2).intern();
            } else {
                String string4 = string3 + "/*";
                string2 = string3;
                string3 = string4;
            }
            \u5171\u4eab.\u8d4b\u80fd(this.\u8d4b\u80fd, string3, intentFilter);
            \u6241\u5e73\u5316 \u6241\u5e73\u53162 = n2 > 0 ? this.\u6293\u624b : this.\u4e2d\u53f0;
            \u5171\u4eab.\u8d4b\u80fd(\u6241\u5e73\u53162, string2, intentFilter);
        }
        return n;
    }
}

