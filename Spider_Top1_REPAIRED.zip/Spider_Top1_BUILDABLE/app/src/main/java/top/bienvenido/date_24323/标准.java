/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ProviderInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ProviderInfo;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u6807\u51c6
extends FunctionReferenceImpl
implements Function2 {
    public static final \u6807\u51c6 \u8d4b\u80fd = new \u6807\u51c6();

    public \u6807\u51c6() {
        super(2, \u94f8\u9020.class, "getProviderInfo", "getProviderInfo(Landroid/content/ComponentName;)Landroid/content/pm/ProviderInfo;", 0);
    }

    public final Object invoke(Object object, Object object2) {
        return ((\u94f8\u9020)object).\u4e2d\u53f0((ComponentName)object2);
    }
}

