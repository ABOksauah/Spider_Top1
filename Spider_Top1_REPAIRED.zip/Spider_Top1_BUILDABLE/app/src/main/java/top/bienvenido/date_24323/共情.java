/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5171\u60c5$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u5171\u60c5
extends \u89e6\u8fbe {
    public final Function2 \u8d4b\u80fd;

    public \u5171\u60c5(Function2 function2) {
        this.\u8d4b\u80fd = function2;
    }

    public static final ComponentInfo \u8d4b\u80fd(\u5171\u60c5 \u5171\u60c52, Object object, \u94f8\u9020 \u94f8\u90202) {
        return (ComponentInfo)\u5171\u60c52.\u8d4b\u80fd.invoke((Object)\u94f8\u90202, object);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        block5 : {
            String string;
            object2 = arrobject[0];
            if (!(object2 instanceof ComponentName) || Intrinsics.areEqual((Object)(string = ((ComponentName)object2).getPackageName()), (Object)\u98ce\u53e3.\u6293\u624b)) return method.invoke(object, arrobject);
            if (\u6c34\u4f4d.\u6f0f\u6597 || !Intrinsics.areEqual((Object)string, (Object)\u6c34\u4f4d.\u6293\u624b)) break block5;
            \u89e6\u8fbe.\u8d4b\u80fd(arrobject, 1);
            Object object3 = method.invoke(object, arrobject);
            if (object3 == null) return null;
            \u6269\u5c55.\u8d4b\u80fd(((ComponentInfo)object3).applicationInfo);
            return object3;
        }
        ComponentInfo componentInfo = (ComponentInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u5171\u60c5$$ExternalSyntheticLambda0(this, object2));
        if (componentInfo == null) return method.invoke(object, arrobject);
        try {
            \u6269\u5c55.\u8d4b\u80fd(componentInfo.applicationInfo);
            return componentInfo;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

