/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.IInterface;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u66dd\u5149;
import top.bienvenido.date_24323.\u8986\u76d6;

public final class \u5f62\u6001
extends FunctionReferenceImpl
implements Function1 {
    public static final \u5f62\u6001 \u8d4b\u80fd = new \u5f62\u6001();

    public \u5f62\u6001() {
        super(1, \u66dd\u5149.class, "asInterface", "asInterface(Landroid/os/IBinder;)Ltop/bienvenido/mundo/IMundoAccountManagerService;", 0);
    }

    public final Object invoke(Object object) {
        IBinder iBinder = (IBinder)object;
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("MundoAccountManagerService");
        if (iInterface != null && iInterface instanceof \u589e\u957f) {
            return (\u589e\u957f)iInterface;
        }
        return new \u8986\u76d6(iBinder);
    }
}

