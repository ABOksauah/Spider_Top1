/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.IServiceConnection
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u91cf\u5316
 */
package top.bienvenido.date_24323;

import android.app.IServiceConnection;
import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u91cf\u5316;

public final class \u91cf\u5316$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ IServiceConnection f$1;

    public /* synthetic */ \u91cf\u5316$$ExternalSyntheticLambda0(Intent intent, IServiceConnection iServiceConnection) {
        this.f$0 = intent;
        this.f$1 = iServiceConnection;
    }

    public final Object invoke(Object object) {
        return \u91cf\u5316.\u8d4b\u80fd((Intent)this.f$0, (IServiceConnection)this.f$1, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

