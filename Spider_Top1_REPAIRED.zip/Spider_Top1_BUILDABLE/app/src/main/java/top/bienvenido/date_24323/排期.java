/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u5f39\u7a97;

public final class \u6392\u671f {
    public final boolean \u4e2d\u53f0;
    public final IBinder \u6293\u624b;
    public final \u5f39\u7a97 \u8d4b\u80fd;

    public \u6392\u671f(\u5f39\u7a97 \u5f39\u7a972, IBinder iBinder, boolean bl) {
        this.\u8d4b\u80fd = \u5f39\u7a972;
        this.\u6293\u624b = iBinder;
        this.\u4e2d\u53f0 = bl;
    }
}

