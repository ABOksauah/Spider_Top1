/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u91cd\u5851
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u91cd\u5851;

public final class \u91cd\u5851$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Intent f$0;

    public /* synthetic */ \u91cd\u5851$$ExternalSyntheticLambda0(Intent intent) {
        this.f$0 = intent;
    }

    public final Object invoke(Object object) {
        return \u91cd\u5851.\u8d4b\u80fd((Intent)this.f$0, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

