/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ProviderInfo
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Triple
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u56de\u5f52$
 *  top.bienvenido.date_24323.\u56de\u5f52$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u94fe\u8def
 */
package top.bienvenido.date_24323;

import android.content.pm.ProviderInfo;
import android.os.IBinder;
import kotlin.Triple;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u56de\u5f52$;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u94fe\u8def;

public abstract class \u56de\u5f52 {
    public static final IBinder \u8d4b\u80fd(String string2, ProviderInfo[] arrproviderInfo, String[] arrstring, \u7b14\u82af \u7b14\u82af2) {
        return \u7b14\u82af2.\u8d4b\u80fd(string2, \u6c34\u4f4d.\u95ed\u73af, arrproviderInfo, arrstring, \u6c34\u4f4d.\u6c89\u6dc0);
    }

    public static Triple \u8d4b\u80fd(String string2) {
        ProviderInfo[] arrproviderInfo = new ProviderInfo[1];
        String[] arrstring = new String[1];
        return new Triple((Object)((IBinder)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(string2, arrproviderInfo, arrstring))), (Object)arrstring[0], (Object)arrproviderInfo[0]);
    }
}

