/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u64cd\u76d8
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u64cd\u76d8;
import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ \u64cd\u76d8 f$1;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda0(String string2, \u64cd\u76d8 \u64cd\u76d82) {
        this.f$0 = string2;
        this.f$1 = \u64cd\u76d82;
    }

    public final void run() {
        \u8fb9\u754c.\u8d4b\u80fd((String)this.f$0, (\u64cd\u76d8)this.f$1);
    }
}

