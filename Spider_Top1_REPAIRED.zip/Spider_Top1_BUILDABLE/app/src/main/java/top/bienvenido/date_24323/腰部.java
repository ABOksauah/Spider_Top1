/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.functions.Function1;

public final class \u8170\u90e8
implements Parcelable.Creator {
    public final Function1 \u6293\u624b;
    public final Parcelable.Creator \u8d4b\u80fd;

    public \u8170\u90e8(Parcelable.Creator creator, Function1 function1) {
        this.\u8d4b\u80fd = creator;
        this.\u6293\u624b = function1;
    }

    public final Object createFromParcel(Parcel parcel) {
        Object object = this.\u8d4b\u80fd.createFromParcel(parcel);
        this.\u6293\u624b.invoke(object);
        return object;
    }

    public final Object[] newArray(int n) {
        return this.\u8d4b\u80fd.newArray(n);
    }
}

