/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda13
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ Intent f$1;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda13(IBinder iBinder, Intent intent) {
        this.f$0 = iBinder;
        this.f$1 = intent;
    }

    public final void run() {
        \u6bb5\u4f4d.\u95ed\u73af((IBinder)this.f$0, (Intent)this.f$1);
    }
}

