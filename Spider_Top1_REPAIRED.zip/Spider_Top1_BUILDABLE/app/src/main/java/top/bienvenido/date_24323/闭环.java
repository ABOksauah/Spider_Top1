/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u95ed\u73af$$ExternalSyntheticLambda0;

public final class \u95ed\u73af
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        Object object = arrobject[0];
        String string = object != null ? object.toString() : null;
        Object object2 = arrobject[1];
        String string2 = null;
        if (object2 != null) {
            string2 = object2.toString();
        }
        \u589e\u957f2.\u8d4b\u80fd(string, string2);
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u95ed\u73af$$ExternalSyntheticLambda0(arrobject));
    }
}

