/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IIntentReceiver
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u62b9\u5e73
 */
package top.bienvenido.date_24323;

import android.content.IIntentReceiver;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62b9\u5e73;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u62b9\u5e73$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ IIntentReceiver f$0;

    public /* synthetic */ \u62b9\u5e73$$ExternalSyntheticLambda0(IIntentReceiver iIntentReceiver) {
        this.f$0 = iIntentReceiver;
    }

    public final Object invoke(Object object) {
        return \u62b9\u5e73.\u8d4b\u80fd((IIntentReceiver)this.f$0, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

