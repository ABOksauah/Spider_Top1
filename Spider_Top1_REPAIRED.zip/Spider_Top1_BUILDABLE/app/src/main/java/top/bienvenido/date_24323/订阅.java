/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.IBinder;
import android.os.IInterface;

public interface \u8ba2\u9605
extends IInterface {
    public void \u6293\u624b(Uri var1, IBinder var2, boolean var3);

    public void \u843d\u5730(IBinder var1);

    public void \u8d4b\u80fd(Uri var1, IBinder var2, boolean var3);
}

