/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Parcel
 *  android.os.Parcelable
 *  java.io.Serializable
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.util.Map;
import top.bienvenido.date_24323.\u515c\u5e95;

public final class \u8d4b\u80fd {
    public final \u515c\u5e95 \u4e2d\u53f0;
    public String \u6293\u624b;
    public long \u843d\u5730;
    public Account \u8d4b\u80fd;
    public final \u515c\u5e95 \u95ed\u73af;

    public \u8d4b\u80fd(Account account) {
        this.\u8d4b\u80fd = account;
        this.\u4e2d\u53f0 = new \u515c\u5e95(0);
        this.\u95ed\u73af = new \u515c\u5e95(0);
    }

    public \u8d4b\u80fd(Parcel parcel) {
        Map map;
        Account account = (Account)parcel.readParcelable(Account.class.getClassLoader());
        if (account == null) {
            account = new Account(parcel);
        }
        this(account);
        this.\u6293\u624b = parcel.readString();
        Map map2 = (Map)parcel.readSerializable();
        if (map2 != null) {
            this.\u4e2d\u53f0.putAll(map2);
        }
        if ((map = (Map)parcel.readSerializable()) != null) {
            this.\u95ed\u73af.putAll(map);
        }
        this.\u843d\u5730 = parcel.readLong();
    }
}

