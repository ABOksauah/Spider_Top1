/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;

public final class \u73a9\u6cd5
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ Account \u540c\u6b65;
    public final /* synthetic */ Bundle \u5bf9\u9f50;

    public \u73a9\u6cd5(boolean bl, Account account, Bundle bundle, IAccountManagerResponse iAccountManagerResponse, String string, String string2) {
        this.\u540c\u6b65 = account;
        this.\u5bf9\u9f50 = bundle;
        super(iAccountManagerResponse, string, bl, true, string2, true, true);
    }

    @Override
    public final void \u5bf9\u9f50() {
        IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
        if (iAccountAuthenticator != null) {
            iAccountAuthenticator.confirmCredentials((IAccountAuthenticatorResponse)this, this.\u540c\u6b65, this.\u5bf9\u9f50);
        }
    }
}

