/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u89e3\u8026
extends \u89e6\u8fbe {
    public final /* synthetic */ \u89e6\u8fbe \u6293\u624b;
    public final /* synthetic */ \u515c\u5e95 \u8d4b\u80fd;

    public \u89e3\u8026(\u515c\u5e95 \u515c\u5e952, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.\u8d4b\u80fd = \u515c\u5e952;
        this.\u6293\u624b = \u89e6\u8fbe2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = arrobject[0];
        Object object3 = this.\u8d4b\u80fd.remove(object2);
        if (object3 == null) return this.\u6293\u624b.\u8d4b\u80fd(object, method, arrobject);
        try {
            arrobject[0] = object3;
            return this.\u6293\u624b.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return this.\u6293\u624b.\u8d4b\u80fd(object, method, arrobject);
    }
}

