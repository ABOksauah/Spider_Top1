/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.collections.ArraysKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u56e0\u5b50;
import top.bienvenido.date_24323.\u57fa\u56e0;
import top.bienvenido.date_24323.\u57fa\u77f3;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6a21\u578b$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u7a7a\u767d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d5b\u9053;

public final class \u6a21\u578b
extends \u89e6\u53d1 {
    public static final \u6a21\u578b \u6293\u624b = new \u6a21\u578b();

    public static final Intent \u8d4b\u80fd(IBinder iBinder, Intent intent, Object[] arrobject, \u5e03\u5c40 \u5e03\u5c402) {
        int n = \u6c34\u4f4d.\u6c89\u6dc0;
        Number number = (Number)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Number.class);
        int n2 = number != null ? number.intValue() : -1;
        boolean bl = n2 >= 0;
        return \u5e03\u5c402.\u8d4b\u80fd(iBinder, intent, n, bl);
    }

    public static boolean \u8d4b\u80fd(Intent intent) {
        String string = intent.getAction();
        return string != null && (Intrinsics.areEqual((Object)"android.media.action.IMAGE_CAPTURE", (Object)string) || Intrinsics.areEqual((Object)"android.media.action.IMAGE_CAPTURE_SECURE", (Object)string) || Intrinsics.areEqual((Object)"android.provider.action.MOTION_PHOTO_CAPTURE", (Object)string) || Intrinsics.areEqual((Object)"android.provider.action.MOTION_PHOTO_CAPTURE_SECURE", (Object)string) || Intrinsics.areEqual((Object)"android.media.action.VIDEO_CAPTURE", (Object)string) || Intrinsics.areEqual((Object)"android.intent.action.SEND", (Object)string) || Intrinsics.areEqual((Object)"android.intent.action.SEND_MULTIPLE", (Object)string));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        int n;
        Object[] arrobject2;
        block7 : {
            int n2;
            block6 : {
                if (!\u6c34\u4f4d.\u8d4b\u80fd) return super.\u8d4b\u80fd(object, method, arrobject);
                try {
                    arrobject2 = method.getParameterTypes();
                    n2 = arrobject.length;
                    break block6;
                }
                catch (Exception exception) {
                    // empty catch block
                }
                return super.\u8d4b\u80fd(object, method, arrobject);
            }
            for (n = 0; n < n2; ++n) {
                if (!Intent.class.isInstance(arrobject[n])) {
                    continue;
                }
                break block7;
            }
            n = -1;
        }
        if (n < 0) return super.\u8d4b\u80fd(object, method, arrobject);
        int n3 = ArraysKt.indexOf((Object[])arrobject2, IBinder.class);
        IBinder iBinder = n3 >= 0 ? (IBinder)arrobject[n3] : null;
        Intent intent = (Intent)arrobject[n];
        Intent intent2 = (Intent)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u6a21\u578b$$ExternalSyntheticLambda0(iBinder, intent, arrobject));
        if (intent2 != null) {
            arrobject[n] = intent2;
            if (!\u62bd\u8c61.\u5e73\u53f0) return super.\u8d4b\u80fd(object, method, arrobject);
            Bundle bundle = (Bundle)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Bundle.class);
            if (bundle == null) return super.\u8d4b\u80fd(object, method, arrobject);
            bundle.remove("android.activity.activityType");
            bundle.remove("android.activity.launchTypeBubble");
            bundle.remove("android.activity.alwaysOnTop");
            bundle.remove("android:activity.remoteTransition");
            bundle.remove("android:activity.remoteAnimationAdapter");
            bundle.remove("android.activity.dismissKeyguardIfInsecure");
            bundle.remove("android:activity.overrideTaskTransition");
            bundle.remove("android:activity.lockTaskMode");
            bundle.remove("android.activity.launchDisplayId");
            bundle.remove("android.activity.launchTaskDisplayAreaToken");
            bundle.remove("android.activity.transientLaunch");
            bundle.remove("android.activity.launchTaskId");
            bundle.remove("android.activity.disableStarting");
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        if (\u62bd\u8c61.\u8fed\u4ee3 && \u6a21\u578b.\u8d4b\u80fd(intent)) {
            intent.setFlags(3 | intent.getFlags());
        }
        arrobject[n] = \u7a7a\u767d.\u8d4b\u80fd(intent);
        return super.\u8d4b\u80fd(object, method, arrobject);
    }

    public final void \u8d4b\u80fd(\u51fa\u51fb \u51fa\u51fb2) {
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-1528850031, 1188583438, -1938750181, 1002006553, -764358898, -932892417, 1441231458}, this);
        if (\u62bd\u8c61.\u5bf9\u6807) {
            \u771f\u9999.\u8d4b\u80fd(Bundle.class, "intentClass", null);
        }
        \u8d5b\u9053 \u8d5b\u90532 = new \u8d5b\u9053();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1076229154, \u8d5b\u90532);
        \u57fa\u77f3 \u57fa\u77f32 = new \u57fa\u77f3();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-346076689, \u57fa\u77f32);
        \u57fa\u56e0 \u57fa\u56e02 = new \u57fa\u56e0();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1965957592, \u57fa\u56e02);
        \u56e0\u5b50 \u56e0\u5b502 = new \u56e0\u5b50();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1621249213, \u56e0\u5b502);
    }
}

