/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.bluetooth.IBluetoothManagerCallback
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.bluetooth.IBluetoothManagerCallback;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u5bb9\u9519;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u5bb9\u707e
extends \u89e6\u8fbe {
    public final /* synthetic */ \u89e6\u8fbe \u6293\u624b;
    public final /* synthetic */ \u515c\u5e95 \u8d4b\u80fd;

    public \u5bb9\u707e(\u515c\u5e95 \u515c\u5e952, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.\u8d4b\u80fd = \u515c\u5e952;
        this.\u6293\u624b = \u89e6\u8fbe2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        try {
            Object object3 = arrobject[0];
            if (object3 instanceof IBluetoothManagerCallback) {
                void var7_7;
                Object object4 = this.\u8d4b\u80fd.get(object3);
                if (object4 == null) {
                    \u89e6\u8fbe \u89e6\u8fbe2 = this.\u6293\u624b;
                    \u5bb9\u9519 \u5bb9\u95192 = new \u5bb9\u9519((IBluetoothManagerCallback)object3, \u89e6\u8fbe2);
                    this.\u8d4b\u80fd.put(object3, (Object)\u5bb9\u95192);
                }
                arrobject[0] = var7_7;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if ((object2 = method.invoke(object, arrobject)) == null) {
            return null;
        }
        return \u56f4\u7ed5.\u8d4b\u80fd(object2, this.\u6293\u624b);
    }
}

