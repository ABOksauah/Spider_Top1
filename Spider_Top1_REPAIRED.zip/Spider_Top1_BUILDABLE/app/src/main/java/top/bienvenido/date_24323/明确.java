/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u786e\u8ba4
 *  top.bienvenido.date_24323.\u8bc1\u8a00
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u786e\u8ba4;
import top.bienvenido.date_24323.\u8bc1\u8a00;

public abstract class \u660e\u786e {
    public static final Function1 \u8d4b\u80fd;

    static {
        Object object = \u62bd\u8c61.\u6f0f\u6597 ? \u8bc1\u8a00.\u8d4b\u80fd : new \u786e\u8ba4();
        \u8d4b\u80fd = object;
    }

    public static ParceledListSlice \u8d4b\u80fd(List list) {
        try {
            ParceledListSlice parceledListSlice = new ParceledListSlice(list);
            return parceledListSlice;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static List \u8d4b\u80fd(Object object) {
        try {
            if (!(object instanceof ParceledListSlice)) {
                return (List)object;
            }
            List list = (List)\u8d4b\u80fd.invoke(object);
            return list;
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}

