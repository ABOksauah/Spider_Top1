/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RecentTaskInfo
 *  android.app.ActivityManager$RunningTaskInfo
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u642d\u5efa;

public final class \u6784\u7b51
implements \u5e03\u5c40 {
    public final IBinder \u8d4b\u80fd;

    public \u6784\u7b51(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final void \u4e2d\u53f0(String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(17, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u4e2d\u53f0() {
        boolean bl;
        Parcel parcel;
        Parcel parcel2;
        block2 : {
            parcel2 = Parcel.obtain();
            parcel = Parcel.obtain();
            try {
                parcel2.writeInterfaceToken("MundoWindowManagerService");
                this.\u8d4b\u80fd.transact(19, parcel2, parcel, 0);
                parcel.readException();
                int n = parcel.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel.recycle();
                parcel2.recycle();
                throw throwable;
            }
        }
        parcel.recycle();
        parcel2.recycle();
        return bl;
    }

    @Override
    public final boolean \u6293\u624b(String string, String string2) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel2 = Parcel.obtain();
            parcel = Parcel.obtain();
            try {
                parcel2.writeInterfaceToken("MundoWindowManagerService");
                parcel2.writeString(string);
                parcel2.writeString(string2);
                this.\u8d4b\u80fd.transact(14, parcel2, parcel, 0);
                parcel.readException();
                int n = parcel.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel.recycle();
                parcel2.recycle();
                throw throwable;
            }
        }
        parcel.recycle();
        parcel2.recycle();
        return bl;
    }

    @Override
    public final void \u6c89\u6dc0(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(7, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u6f0f\u6597(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(8, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final String \u7ed9\u5230(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(13, parcel, parcel2, 0);
            parcel2.readException();
            String string = parcel2.readString();
            return string;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u843d\u5730(String string, String string2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeString(string);
            parcel.writeString(string2);
            this.\u8d4b\u80fd.transact(15, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final ComponentName \u8d4b\u80fd(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(12, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = ComponentName.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            ComponentName componentName = (ComponentName)object;
            return componentName;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Intent \u8d4b\u80fd(long l, Intent intent) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeLong(l);
            \u642d\u5efa.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            this.\u8d4b\u80fd.transact(4, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = Intent.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            Intent intent2 = (Intent)object;
            return intent2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Intent \u8d4b\u80fd(IBinder iBinder, Intent intent, int n, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            \u642d\u5efa.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeInt(n);
            parcel.writeInt((int)bl);
            this.\u8d4b\u80fd.transact(1, parcel, parcel2, 0);
            parcel2.readException();
            Parcelable.Creator creator = Intent.CREATOR;
            Object object = parcel2.readInt() != 0 ? creator.createFromParcel(parcel2) : null;
            Intent intent2 = (Intent)object;
            return intent2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final String \u8d4b\u80fd() {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            this.\u8d4b\u80fd.transact(18, parcel, parcel2, 0);
            parcel2.readException();
            String string = parcel2.readString();
            return string;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u8d4b\u80fd(long l) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeLong(l);
            this.\u8d4b\u80fd.transact(9, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ActivityManager.RunningTaskInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final List \u8d4b\u80fd(long l, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeLong(l);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(10, parcel, parcel2, 0);
            parcel2.readException();
            ArrayList arrayList = parcel2.createTypedArrayList(ActivityManager.RecentTaskInfo.CREATOR);
            return arrayList;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(Intent intent, String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            \u642d\u5efa.\u8d4b\u80fd(parcel, (Parcelable)intent, 0);
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(3, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, IBinder iBinder2) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeStrongBinder(iBinder2);
            this.\u8d4b\u80fd.transact(5, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, String string, String string2, String string3, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeString(string2);
            parcel.writeString(string3);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(11, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(20, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final Intent[] \u8d4b\u80fd(IBinder iBinder, Intent[] arrintent, int n) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoWindowManagerService");
            parcel.writeStrongBinder(iBinder);
            parcel.writeTypedArray((Parcelable[])arrintent, 0);
            parcel.writeInt(n);
            this.\u8d4b\u80fd.transact(2, parcel, parcel2, 0);
            parcel2.readException();
            Intent[] arrintent2 = (Intent[])parcel2.createTypedArray(Intent.CREATOR);
            return arrintent2;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final boolean \u95ed\u73af(IBinder iBinder) {
        Parcel parcel;
        boolean bl;
        Parcel parcel2;
        block2 : {
            parcel = Parcel.obtain();
            parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("MundoWindowManagerService");
                parcel.writeStrongBinder(iBinder);
                this.\u8d4b\u80fd.transact(16, parcel, parcel2, 0);
                parcel2.readException();
                int n = parcel2.readInt();
                bl = false;
                if (n == 0) break block2;
                bl = true;
            }
            catch (Throwable throwable) {
                parcel2.recycle();
                parcel.recycle();
                throw throwable;
            }
        }
        parcel2.recycle();
        parcel.recycle();
        return bl;
    }
}

