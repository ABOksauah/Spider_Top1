/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Singleton
 *  java.lang.Exception
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.util.Singleton;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8d70\u51fa\u53bb;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u9080\u8bf7
extends \u96c6\u6210 {
    public static final \u9080\u8bf7 \u6293\u624b = new \u9080\u8bf7();

    @Override
    public final void \u8d4b\u80fd() {
        Object object = null;
        try {
            object = \u771f\u9999.\u8d4b\u80fd("com.hihonor.android.content.pm.HwPackageManager", "PACKAGE_MANAGER_SINGLETON").\u8d4b\u80fd(null);
        }
        catch (Exception exception) {
            // empty catch block
        }
        Singleton singleton = (Singleton)object;
        if (singleton == null) {
            return;
        }
        Object object2 = singleton.get();
        if (object2 == null) {
            return;
        }
        Object object3 = \u56f4\u7ed5.\u8d4b\u80fd(object2, \u672c\u6211.\u4e2d\u53f0);
        \u8d70\u51fa\u53bb.\u8d4b\u80fd.\u8d4b\u80fd((Object)singleton, object3);
    }
}

