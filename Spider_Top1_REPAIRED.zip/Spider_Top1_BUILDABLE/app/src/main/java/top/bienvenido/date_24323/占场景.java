/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.Pair
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u5360\u573a\u666f
extends \u89e6\u8fbe {
    public final Function1 \u8d4b\u80fd;

    public \u5360\u573a\u666f(Function1 function1) {
        this.\u8d4b\u80fd = function1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Pair pair;
            \u6241\u5e73\u5316 \u6241\u5e73\u53162 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd;
            Object object2 = arrobject[0];
            int n = 0;
            if (object2 != null) {
                n = object2.hashCode();
            }
            if ((pair = (Pair)\u6241\u5e73\u53162.\u8d4b\u80fd(n)) == null) return method.invoke(object, arrobject);
            return this.\u8d4b\u80fd.invoke(pair.getFirst());
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

