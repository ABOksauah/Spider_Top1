/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u91cd\u7ec4$$ExternalSyntheticLambda0;

public final class \u91cd\u7ec4
extends \u89e6\u53d1 {
    public static final \u91cd\u7ec4 \u6293\u624b = new \u91cd\u7ec4();

    public static final Intent \u8d4b\u80fd(int n, Intent intent, \u5e03\u5c40 \u5e03\u5c402) {
        return \u5e03\u5c402.\u8d4b\u80fd(0xFFFFFFFFL & (long)\u6c34\u4f4d.\u6c89\u6dc0 | -4294967296L & (long)n << 32, intent);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        int n;
        int n2;
        Intent[] arrintent;
        try {
            arrintent = (Intent[])\u89e6\u8fbe.\u8d4b\u80fd(arrobject, Intent[].class);
            if (!\u6c34\u4f4d.\u8d4b\u80fd || arrintent == null) return super.\u8d4b\u80fd(object, method, arrobject);
            n2 = (Integer)arrobject[0];
            n = arrintent.length;
        }
        catch (Exception exception) {
            // empty catch block
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        for (int i = 0; i < n; ++i) {
            int n3;
            Intent intent = arrintent[i];
            Object object2 = n2 != 1 && n2 != 2 && n2 != 4 && n2 != 5 ? null : (Intent)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u91cd\u7ec4$$ExternalSyntheticLambda0(n2, intent));
            int n4 = -3 + arrobject.length;
            Object object3 = arrobject[n4];
            if (object2 != null) {
                arrintent[i] = object2;
                if (!(object3 instanceof Integer)) continue;
                arrobject[n4] = 50331648 | -67108865 & ((Number)object3).intValue();
                continue;
            }
            if (!\u62bd\u8c61.\u540c\u6b65 || !(object3 instanceof Integer) || \u6253\u78e8.\u8d4b\u80fd(n3 = ((Number)object3).intValue(), 536870912) || !\u6253\u78e8.\u8d4b\u80fd(n3, 33554432) || intent.getComponent() != null || intent.getPackage() != null) continue;
            arrobject[n4] = 83886080 | -33554433 & ((Number)object3).intValue();
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

