/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function3
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.os.IBinder;
import kotlin.jvm.functions.Function3;
import top.bienvenido.date_24323.\u5408\u529b;

public final class \u5408\u529b$$ExternalSyntheticLambda8
implements Function3 {
    public final Object invoke(Object object, Object object2, Object object3) {
        return \u5408\u529b.\u95ed\u73af(object, (ComponentName)object2, (IBinder)object3);
    }
}

