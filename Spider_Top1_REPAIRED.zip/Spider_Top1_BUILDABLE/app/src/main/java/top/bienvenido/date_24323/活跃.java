/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.media.session.MediaSession
 *  android.media.session.MediaSession$Token
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Exception
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.Map
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u53ef\u63a7
 */
package top.bienvenido.date_24323;

import android.media.session.MediaSession;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u53ef\u63a7;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u6d3b\u8dc3$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8170\u90e8;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u6d3b\u8dc3
extends \u96c6\u6210 {
    public static final \u6d3b\u8dc3 \u6293\u624b = new \u6d3b\u8dc3();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final Unit \u8d4b\u80fd(\u81ea\u6d3d \u81ea\u6d3d2, MediaSession.Token token) {
        try {
            Object object = \u81ea\u6d3d2.\u8d4b\u80fd((Object)token);
            if (object == null) {
                return Unit.INSTANCE;
            }
            \u81ea\u6d3d2.\u8d4b\u80fd((Object)token, \u56f4\u7ed5.\u8d4b\u80fd(object, \u672c\u6211.\u4e2d\u53f0));
            return Unit.INSTANCE;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return Unit.INSTANCE;
    }

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("media_session", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u53ef\u63a7 \u53ef\u63a72 = new \u53ef\u63a7();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-63461894, (Object)\u53ef\u63a72);
        \u6d3b\u8dc3$$ExternalSyntheticLambda0 \u6d3b\u8dc3$$ExternalSyntheticLambda0 = new \u6d3b\u8dc3$$ExternalSyntheticLambda0(\u771f\u9999.\u8d4b\u80fd(MediaSession.Token.class, "mBinder"));
        \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(MediaSession.Token.class, "CREATOR");
        \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, (Object)new \u8170\u90e8((Parcelable.Creator)\u81ea\u6d3d2.\u8d4b\u80fd(null), \u6d3b\u8dc3$$ExternalSyntheticLambda0));
        boolean bl = \u62bd\u8c61.\u54cd\u5e94;
        Object object = null;
        if (bl) {
            object = \u771f\u9999.\u4e2d\u53f0(Parcel.class, "sPairedCreators");
            if (\u62bd\u8c61.\u540c\u6b65 && object == null) {
                return;
            }
        }
        if (object == null) {
            object = \u771f\u9999.\u4e2d\u53f0(Parcel.class, "mCreators");
        }
        if (object != null) {
            Object object2 = object;
            synchronized (object2) {
                Iterator iterator = ((Map)object).values().iterator();
                while (iterator.hasNext()) {
                    ((Map)iterator.next()).clear();
                }
                return;
            }
        }
    }
}

