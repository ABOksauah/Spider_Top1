/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import java.util.Objects;

public final class \u611f\u77e5\u5ea6 {
    public final String \u6293\u624b;
    public final Account \u8d4b\u80fd;

    public \u611f\u77e5\u5ea6(Account account, String string2) {
        this.\u8d4b\u80fd = account;
        this.\u6293\u624b = string2;
    }

    public final boolean equals(Object object) {
        if (object instanceof \u611f\u77e5\u5ea6) {
            \u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62 = (\u611f\u77e5\u5ea6)object;
            if (Objects.equals((Object)this.\u8d4b\u80fd, (Object)\u611f\u77e5\u5ea62.\u8d4b\u80fd) && Objects.equals((Object)this.\u6293\u624b, (Object)\u611f\u77e5\u5ea62.\u6293\u624b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.\u8d4b\u80fd.hashCode() ^ this.\u6293\u624b.hashCode();
    }
}

