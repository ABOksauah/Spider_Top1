/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda20
implements Function1 {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda20(String string) {
        this.f$0 = string;
    }

    public final Object invoke(Object object) {
        return \u6bb5\u4f4d.\u8d4b\u80fd(this.f$0, (PackageManager)object);
    }
}

