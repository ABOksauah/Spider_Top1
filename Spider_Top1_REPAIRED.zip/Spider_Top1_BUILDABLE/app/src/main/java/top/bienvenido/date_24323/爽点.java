/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u75db\u70b9
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u75db\u70b9;

public final class \u723d\u70b9
extends \u5361\u4f4d {
    public static final \u723d\u70b9 \u843d\u5730 = new \u723d\u70b9();

    public \u723d\u70b9() {
        super((Function1)\u75db\u70b9.\u8d4b\u80fd, "MundoContentService");
    }
}

