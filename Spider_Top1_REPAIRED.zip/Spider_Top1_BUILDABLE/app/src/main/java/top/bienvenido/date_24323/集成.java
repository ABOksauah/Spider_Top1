/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.ServiceManager
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import android.os.ServiceManager;
import java.util.Map;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public abstract class \u96c6\u6210 {
    public \u89e6\u8fbe \u8d4b\u80fd = \u672c\u6211.\u8d4b\u80fd;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final \u51fa\u51fb \u8d4b\u80fd(String var1_1, Object var2_2) {
        var4_3 = this.\u8d4b\u80fd;
        try {
            var9_5 = var6_4 = \u6d1e\u81ea\u8eab.\u6293\u624b;
            // MONITORENTER : var9_5
        }
        catch (Exception var5_7) {
            return null;
        }
        var8_6 = ServiceManager.getService((String)var1_1);
        if (var8_6 != null) ** GOTO lbl12
        // MONITOREXIT : var9_5
        return null;
lbl12: // 1 sources:
        // MONITOREXIT : var9_5
        return \u6d1e\u81ea\u8eab.\u8d4b\u80fd(var1_1, var4_3, var8_6, var2_2);
    }

    public abstract void \u8d4b\u80fd();

    public final /* varargs */ void \u8d4b\u80fd(String ... arrstring) {
        \u89e6\u8fbe \u89e6\u8fbe2 = this.\u8d4b\u80fd;
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            try {
                \u6d1e\u81ea\u8eab.\u8d4b\u80fd(arrstring[i], \u89e6\u8fbe2, null);
            }
            catch (Exception exception) {
                // empty catch block
                break;
            }
            continue;
        }
    }
}

