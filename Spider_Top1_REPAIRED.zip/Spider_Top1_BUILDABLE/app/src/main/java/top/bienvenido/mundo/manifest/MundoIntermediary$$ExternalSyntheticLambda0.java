/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package top.bienvenido.mundo.manifest;

import android.content.Intent;
import java.util.concurrent.atomic.AtomicBoolean;
import top.bienvenido.mundo.manifest.MundoIntermediary;

public final class MundoIntermediary$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ MundoIntermediary f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ AtomicBoolean f$2;

    public /* synthetic */ MundoIntermediary$$ExternalSyntheticLambda0(MundoIntermediary mundoIntermediary, Intent intent, AtomicBoolean atomicBoolean) {
        this.f$0 = mundoIntermediary;
        this.f$1 = intent;
        this.f$2 = atomicBoolean;
    }

    public final void run() {
        MundoIntermediary.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2);
    }
}

