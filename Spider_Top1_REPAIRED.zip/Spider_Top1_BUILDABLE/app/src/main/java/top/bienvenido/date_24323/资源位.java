/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public abstract class \u8d44\u6e90\u4f4d {
    public static final \u81ea\u6d3d \u4e2d\u53f0;
    public static final \u81ea\u6d3d \u6293\u624b;
    public static final \u81ea\u6d3d \u843d\u5730;
    public static final Object \u8d4b\u80fd;
    public static final \u81ea\u6d3d \u95ed\u73af;

    static {
        Class class_ = Class.forName((String)"dalvik.system.VMRuntime");
        \u8d4b\u80fd = \u771f\u9999.\u6293\u624b(class_, "getRuntime").\u8d4b\u80fd((Object)null, new Object[0]);
        \u81ea\u6d3d \u81ea\u6d3d2 = \u62bd\u8c61.\u6f0f\u6597 ? \u771f\u9999.\u8d4b\u80fd(class_, "setProcessPackageName", new Class[]{String.class}) : \u81ea\u6d3d.\u8d4b\u80fd;
        \u6293\u624b = \u81ea\u6d3d2;
        Class[] arrclass = new Class[]{Integer.TYPE};
        \u4e2d\u53f0 = \u771f\u9999.\u8d4b\u80fd(class_, "setTargetSdkVersion", arrclass);
        \u81ea\u6d3d \u81ea\u6d3d3 = \u62bd\u8c61.\u6c89\u6dc0 ? \u771f\u9999.\u8d4b\u80fd(class_, "setProcessDataDirectory", new Class[]{String.class}) : \u81ea\u6d3d.\u8d4b\u80fd;
        \u95ed\u73af = \u81ea\u6d3d3;
        \u81ea\u6d3d \u81ea\u6d3d4 = !\u62bd\u8c61.\u6293\u624b ? \u771f\u9999.\u6293\u624b(class_, "is64Bit") : \u81ea\u6d3d.\u8d4b\u80fd;
        \u843d\u5730 = \u81ea\u6d3d4;
    }
}

