/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationChannel
 *  android.content.pm.ParceledListSlice
 *  android.media.AudioAttributes
 *  android.net.Uri
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.app.NotificationChannel;
import android.content.pm.ParceledListSlice;
import android.media.AudioAttributes;
import android.net.Uri;
import android.provider.Settings;
import java.lang.reflect.Method;
import java.util.List;
import top.bienvenido.date_24323.\u5206\u53d1;
import top.bienvenido.date_24323.\u56de\u6d41;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8d77\u98de;

public final class \u9b54\u65b9
extends \u89e6\u53d1 {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2;
        if (!\u6c34\u4f4d.\u8d4b\u80fd || (object2 = arrobject[1]) == null) return super.\u8d4b\u80fd(object, method, arrobject);
        List list = \u660e\u786e.\u8d4b\u80fd(object2);
        if (list == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            for (NotificationChannel notificationChannel : list) {
                String string = \u6c34\u4f4d.\u6293\u624b;
                \u8d77\u98de \u8d77\u98de2 = \u56de\u6d41.\u8d4b\u80fd;
                String string2 = \u5206\u53d1.\u8d4b\u80fd(string, notificationChannel.getId());
                \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)notificationChannel, (Object)string2);
                if (notificationChannel.getSound() == null) continue;
                notificationChannel.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, notificationChannel.getAudioAttributes());
            }
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return super.\u8d4b\u80fd(object, method, arrobject);
            \u660e\u786e.\u8d4b\u80fd(list);
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

