/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.window.WindowContainerToken
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import android.window.WindowContainerToken;
import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u4e0d\u53ef\u63a7;

public final class \u4e0d\u53ef\u63a7$$ExternalSyntheticLambda1
implements Function0 {
    public final /* synthetic */ WindowContainerToken f$0;

    public /* synthetic */ \u4e0d\u53ef\u63a7$$ExternalSyntheticLambda1(WindowContainerToken windowContainerToken) {
        this.f$0 = windowContainerToken;
    }

    public final Object invoke() {
        return \u4e0d\u53ef\u63a7.\u8d4b\u80fd(this.f$0);
    }
}

