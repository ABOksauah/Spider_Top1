/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.telephony.TelephonyManager
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.telephony.TelephonyManager;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u9020\u5e02;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u8bd5\u70b9
extends \u96c6\u6210 {
    public static final \u8bd5\u70b9 \u6293\u624b = new \u8bd5\u70b9();

    @Override
    public final void \u8d4b\u80fd() {
        \u51fa\u51fb \u51fa\u51fb2;
        ArrayList arrayList;
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb3 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("phone", \u89e6\u53d12, null);
        if (\u51fa\u51fb3 != null) {
            if (\u62bd\u8c61.\u5e73\u53f0 || \u62bd\u8c61.\u4ea4\u4ed8) {
                \u771f\u9999.\u8d4b\u80fd(TelephonyManager.class, "sITelephony", null);
            }
            \u51fa\u51fb3.\u8d4b\u80fd(new int[]{-1107875961, 1141893961, 666398025, 1057163518}, new \u79c1\u57df(\u9020\u5e02.\u6293\u624b));
        }
        if (\u62bd\u8c61.\u6c89\u6dc0) {
            \u6d1e\u81ea\u8eab.\u8d4b\u80fd("ions", this.\u8d4b\u80fd, null);
        }
        if ((\u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("isub", this.\u8d4b\u80fd, null)) != null && \u62bd\u8c61.\u6293\u624b && (arrayList = \u9020\u5e02.\u4e2d\u53f0) != null) {
            \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df((Object)arrayList);
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-652029243, \u79c1\u57df2);
        }
        if (\u6d1e\u81ea\u8eab.\u8d4b\u80fd("telephony.registry", this.\u8d4b\u80fd, null) != null && \u62bd\u8c61.\u7ed9\u5230) {
            \u771f\u9999.\u8d4b\u80fd("android.telephony.TelephonyRegistryManager", "sRegistry").\u8d4b\u80fd((Object)null, (Object)null);
        }
        if (\u6d1e\u81ea\u8eab.\u8d4b\u80fd("iphonesubinfo", this.\u8d4b\u80fd, null) != null && (\u62bd\u8c61.\u7ed9\u5230 || \u62bd\u8c61.\u4ea4\u4ed8)) {
            \u771f\u9999.\u8d4b\u80fd(TelephonyManager.class, "sIPhoneSubInfo", null);
        }
    }
}

