/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IpcDataCache
 *  android.os.IpcDataCache$QueryHandler
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  kotlin.Metadata
 */
package top.bienvenido.mundo.common.ext;

import android.os.IpcDataCache;
import kotlin.Metadata;

@Metadata(d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0007\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u0001B\u001b\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\u0004\b\u0005\u0010\u0006J\u001b\u0010\b\u001a\u0004\u0018\u00010\u00022\b\u0010\u0007\u001a\u0004\u0018\u00010\u0002H\u0016\u00a2\u0006\u0004\b\b\u0010\t\u00a8\u0006\n"}, d2={"Ltop/bienvenido/mundo/common/ext/ExtQueryHandler;", "Landroid/os/IpcDataCache$QueryHandler;", "", "", "origin", "<init>", "(Landroid/os/IpcDataCache$QueryHandler;)V", "serviceQuery", "apply", "(Ljava/lang/Object;)Ljava/lang/Object;", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class ExtQueryHandler
extends IpcDataCache.QueryHandler<Object, Object> {
    public final IpcDataCache.QueryHandler \u8d4b\u80fd;

    public ExtQueryHandler(IpcDataCache.QueryHandler<Object, Integer> queryHandler) {
        this.\u8d4b\u80fd = queryHandler;
    }

    public Object apply(Object object) {
        try {
            Object object2 = this.\u8d4b\u80fd.apply(object);
            return object2;
        }
        catch (Exception exception) {
            return 0;
        }
    }
}

