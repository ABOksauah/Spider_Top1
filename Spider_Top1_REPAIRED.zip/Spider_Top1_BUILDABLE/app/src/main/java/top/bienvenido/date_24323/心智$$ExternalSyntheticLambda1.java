/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5fc3\u667a;

public final class \u5fc3\u667a$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Intent f$0;

    public /* synthetic */ \u5fc3\u667a$$ExternalSyntheticLambda1(Intent intent) {
        this.f$0 = intent;
    }

    public final Object invoke(Object object) {
        return \u5fc3\u667a.\u8d4b\u80fd(this.f$0, (PackageManager)object);
    }
}

