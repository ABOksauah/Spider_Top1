/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u52a1\u5b9e$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u62c9\u65b0;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u52a1\u5b9e
extends \u89e6\u8fbe {
    public final Function2 \u8d4b\u80fd;

    public \u52a1\u5b9e(Function2 function2) {
        this.\u8d4b\u80fd = function2;
    }

    public static final List \u8d4b\u80fd(\u52a1\u5b9e \u52a1\u5b9e2, Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Function2 function2 = \u52a1\u5b9e2.\u8d4b\u80fd;
        Object object = arrobject[0];
        boolean bl = object instanceof Number;
        int n = 0;
        if (bl) {
            n = ((Number)object).intValue();
        }
        return (List)function2.invoke((Object)\u94f8\u90202, (Object)n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            List list;
            List list2 = \u660e\u786e.\u8d4b\u80fd(method.invoke(object, arrobject));
            if (list2 == null) {
                list2 = Collections.EMPTY_LIST;
            }
            if ((list = (List)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u52a1\u5b9e$$ExternalSyntheticLambda0(this, arrobject))) == null) {
                list = Collections.EMPTY_LIST;
            }
            List list3 = CollectionsKt.plus((Collection)list2, (Iterable)list);
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return list3;
            return \u660e\u786e.\u8d4b\u80fd(list3);
        }
        catch (Exception exception) {
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return Collections.EMPTY_LIST;
            return \u62c9\u65b0.\u8d4b\u80fd;
        }
    }
}

