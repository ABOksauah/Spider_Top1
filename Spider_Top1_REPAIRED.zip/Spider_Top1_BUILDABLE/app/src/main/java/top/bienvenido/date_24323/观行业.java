/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8e1d\u90e8;

public final class \u89c2\u884c\u4e1a
extends \u89e6\u8fbe {
    public final /* synthetic */ \u89e6\u8fbe \u6293\u624b;
    public final /* synthetic */ \u8e1d\u90e8 \u8d4b\u80fd;

    public \u89c2\u884c\u4e1a(\u8e1d\u90e8 \u8e1d\u90e82, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.\u8d4b\u80fd = \u8e1d\u90e82;
        this.\u6293\u624b = \u89e6\u8fbe2;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            if (Intrinsics.areEqual((Object)method.getReturnType(), IBinder.class) && arrobject.length == 0) {
                \u8e1d\u90e8 \u8e1d\u90e82 = this.\u8d4b\u80fd;
                return \u8e1d\u90e82;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return this.\u6293\u624b.\u8d4b\u80fd(object, method, arrobject);
    }
}

