/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u8054\u52a8$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u8054\u52a8
extends \u89e6\u8fbe {
    public static final String \u8d4b\u80fd(IBinder iBinder, \u5e03\u5c40 \u5e03\u5c402) {
        return \u5e03\u5c402.\u7ed9\u5230(iBinder);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IBinder iBinder = (IBinder)arrobject[0];
        if (iBinder == null) return method.invoke(object, arrobject);
        try {
            return \u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u8054\u52a8$$ExternalSyntheticLambda0(iBinder));
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

