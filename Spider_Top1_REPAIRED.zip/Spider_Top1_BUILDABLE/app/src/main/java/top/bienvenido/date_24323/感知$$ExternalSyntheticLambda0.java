/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u611f\u77e5
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u611f\u77e5;

public final class \u611f\u77e5$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ IBinder f$1;

    public /* synthetic */ \u611f\u77e5$$ExternalSyntheticLambda0(IBinder iBinder, IBinder iBinder2) {
        this.f$0 = iBinder;
        this.f$1 = iBinder2;
    }

    public final void run() {
        \u611f\u77e5.\u8d4b\u80fd((IBinder)this.f$0, (IBinder)this.f$1);
    }
}

