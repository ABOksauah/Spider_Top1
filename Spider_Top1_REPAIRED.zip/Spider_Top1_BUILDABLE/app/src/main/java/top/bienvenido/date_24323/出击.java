/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 */
package top.bienvenido.date_24323;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u51fa\u51fb
implements InvocationHandler {
    public static final \u56f4\u7ed5 \u843d\u5730 = new \u56f4\u7ed5();
    public final \u89e6\u8fbe \u4e2d\u53f0;
    public final Object \u6293\u624b;
    public final \u6241\u5e73\u5316 \u8d4b\u80fd = new \u6241\u5e73\u5316(0);
    public final Object \u95ed\u73af;

    public \u51fa\u51fb(Object object, \u89e6\u8fbe \u89e6\u8fbe2) {
        this.\u4e2d\u53f0 = \u89e6\u8fbe2;
        this.\u6293\u624b = object;
        ClassLoader classLoader = object.getClass().getClassLoader();
        Class class_ = object.getClass();
        \u5dee\u5f02\u5316 \u5dee\u5f02\u53162 = new \u5dee\u5f02\u5316(2);
        \u56f4\u7ed5.\u8d4b\u80fd(class_, \u5dee\u5f02\u53162);
        this.\u95ed\u73af = Proxy.newProxyInstance((ClassLoader)classLoader, (Class[])((Class[])\u5dee\u5f02\u53162.toArray((Object[])\u4e0b\u6c89.\u6293\u624b)), (InvocationHandler)this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Object invoke(Object object, Method method, Object[] arrobject) {
        try {
            String string2 = method.getName();
            \u89e6\u8fbe \u89e6\u8fbe2 = (\u89e6\u8fbe)this.\u8d4b\u80fd.\u8d4b\u80fd(string2.hashCode());
            if (\u89e6\u8fbe2 == null) {
                \u89e6\u8fbe2 = this.\u4e2d\u53f0;
            }
            Object object2 = this.\u6293\u624b;
            if (arrobject != null) return \u89e6\u8fbe2.\u8d4b\u80fd(object2, method, arrobject);
            arrobject = \u4e0b\u6c89.\u4e2d\u53f0;
            return \u89e6\u8fbe2.\u8d4b\u80fd(object2, method, arrobject);
        }
        catch (InvocationTargetException invocationTargetException) {
            Throwable throwable;
            Throwable throwable2 = invocationTargetException.getCause();
            if (throwable2 == null) {
                throw throwable;
            }
            throwable = throwable2;
            throw throwable;
        }
    }

    public final void \u8d4b\u80fd(int[] arrn, \u89e6\u8fbe \u89e6\u8fbe2) {
        for (int n : arrn) {
            this.\u8d4b\u80fd.\u8d4b\u80fd(n, \u89e6\u8fbe2);
        }
    }
}

