/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.hardware.display.DisplayManagerGlobal
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.hardware.display.DisplayManagerGlobal;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u9020\u4e8b
extends \u96c6\u6210 {
    public static final \u9020\u4e8b \u6293\u624b = new \u9020\u4e8b();

    @Override
    public final void \u8d4b\u80fd() {
        this.\u8d4b\u80fd = \u672c\u6211.\u4e2d\u53f0;
        Object object = \u771f\u9999.\u6293\u624b(DisplayManagerGlobal.class, "getInstance").\u8d4b\u80fd((Object)null, new Object[0]);
        if (object == null) {
            return;
        }
        \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(DisplayManagerGlobal.class, "mDm");
        Object object2 = \u81ea\u6d3d2.\u8d4b\u80fd(object);
        if (object2 == null) {
            return;
        }
        \u51fa\u51fb \u51fa\u51fb2 = this.\u8d4b\u80fd("display", object2);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u81ea\u6d3d2.\u8d4b\u80fd(object, \u51fa\u51fb2.\u95ed\u73af);
    }
}

