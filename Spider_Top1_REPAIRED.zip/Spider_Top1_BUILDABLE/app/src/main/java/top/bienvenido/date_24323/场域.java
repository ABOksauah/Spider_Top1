/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ResolveInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u573a\u57df
extends MutablePropertyReference1Impl {
    public static final \u573a\u57df \u8d4b\u80fd = new \u573a\u57df();

    public \u573a\u57df() {
        super(ResolveInfo.class, "activityInfo", "getActivityInfo()Landroid/content/pm/ActivityInfo;", 0);
    }

    public final Object get(Object object) {
        return ((ResolveInfo)object).activityInfo;
    }

    public final void set(Object object, Object object2) {
        ((ResolveInfo)object).activityInfo = (ActivityInfo)object2;
    }
}

