/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e2d\u53f0$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u4e2d\u53f0
extends \u89e6\u8fbe {
    public static final boolean \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        return \u589e\u957f2.\u8d4b\u80fd((Account)arrobject[0]);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return Intrinsics.areEqual((Object)\u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u4e2d\u53f0$$ExternalSyntheticLambda0(arrobject)), (Object)Boolean.TRUE);
    }
}

