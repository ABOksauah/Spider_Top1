/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  com.android.internal.infra.AndroidFuture
 *  java.lang.Boolean
 *  java.lang.Object
 *  top.bienvenido.date_24323.\u79c0\u808c\u8089
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import com.android.internal.infra.AndroidFuture;
import top.bienvenido.date_24323.\u501f\u4e1c\u98ce;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u62c9\u65b0;
import top.bienvenido.date_24323.\u65ad\u820d\u79bb;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u79c0\u808c\u8089;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u8585\u7f8a\u6bdb
extends \u96c6\u6210 {
    public static final \u8585\u7f8a\u6bdb \u6293\u624b = new \u8585\u7f8a\u6bdb();

    @Override
    public final void \u8d4b\u80fd() {
        boolean bl = \u62bd\u8c61.\u5e73\u53f0;
        \u89e6\u53d1 \u89e6\u53d12 = bl && !\u62bd\u8c61.\u54cd\u5e94 ? new \u79c0\u808c\u8089() : \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("shortcut", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        if (\u62bd\u8c61.\u54cd\u5e94) {
            \u501f\u4e1c\u98ce \u501f\u4e1c\u98ce2 = new \u501f\u4e1c\u98ce();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(451961580, \u501f\u4e1c\u98ce2);
            \u65ad\u820d\u79bb \u65ad\u820d\u79bb2 = new \u65ad\u820d\u79bb();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(532289435, \u65ad\u820d\u79bb2);
            \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-822057436, 501628912, -658792913}, \u672c\u6211.\u6c89\u6dc0);
            int[] arrn = new int[]{-2037178825, -329985383};
            \u51fa\u51fb2.\u8d4b\u80fd(arrn, new \u79c1\u57df((Object)\u62c9\u65b0.\u8d4b\u80fd));
            return;
        }
        if (bl) {
            int[] arrn = new int[]{-329985383, -2037178825};
            \u51fa\u51fb2.\u8d4b\u80fd(arrn, new \u79c1\u57df((Object)AndroidFuture.completedFuture((Object)\u62c9\u65b0.\u8d4b\u80fd)));
            \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-658792913, 501628912, 451961580, -822057436}, new \u79c1\u57df((Object)AndroidFuture.completedFuture((Object)Boolean.FALSE)));
        }
    }
}

