/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.servertransaction.LaunchActivityItem
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$ObjectRef
 */
package top.bienvenido.date_24323;

import android.app.servertransaction.LaunchActivityItem;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Ref;
import top.bienvenido.date_24323.\u5171\u5efa;

public final class \u5171\u5efa$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Ref.ObjectRef f$0;

    public /* synthetic */ \u5171\u5efa$$ExternalSyntheticLambda0(Ref.ObjectRef objectRef) {
        this.f$0 = objectRef;
    }

    public final Object invoke(Object object) {
        return \u5171\u5efa.\u8d4b\u80fd(this.f$0, (LaunchActivityItem)object);
    }
}

