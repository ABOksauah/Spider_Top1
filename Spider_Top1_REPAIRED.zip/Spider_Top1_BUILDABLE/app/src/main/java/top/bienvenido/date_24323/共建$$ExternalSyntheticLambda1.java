/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.servertransaction.ClientTransaction
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$ObjectRef
 */
package top.bienvenido.date_24323;

import android.app.servertransaction.ClientTransaction;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Ref;
import top.bienvenido.date_24323.\u5171\u5efa;

public final class \u5171\u5efa$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Function1 f$0;
    public final /* synthetic */ Ref.ObjectRef f$1;
    public final /* synthetic */ Function1 f$2;

    public /* synthetic */ \u5171\u5efa$$ExternalSyntheticLambda1(Function1 function1, Ref.ObjectRef objectRef, Function1 function12) {
        this.f$0 = function1;
        this.f$1 = objectRef;
        this.f$2 = function12;
    }

    public final Object invoke(Object object) {
        return \u5171\u5efa.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (ClientTransaction)object);
    }
}

