/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import top.bienvenido.date_24323.\u5bf9\u4e00\u4e0b;

public final class \u5c01\u88c5
extends IntentFilter {
    public final String \u6293\u624b;
    public final \u5bf9\u4e00\u4e0b \u8d4b\u80fd;

    public \u5c01\u88c5(IntentFilter intentFilter, \u5bf9\u4e00\u4e0b \u5bf9\u4e00\u4e0b2, String string2) {
        super(intentFilter);
        this.\u8d4b\u80fd = \u5bf9\u4e00\u4e0b2;
        this.\u6293\u624b = string2;
    }
}

