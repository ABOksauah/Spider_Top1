/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import android.os.IBinder;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u5171\u4eab;
import top.bienvenido.date_24323.\u5bf9\u4e00\u4e0b;
import top.bienvenido.date_24323.\u5c01\u88c5;

public final class \u6218\u5f79
extends \u5171\u4eab {
    @Override
    public final int \u6293\u624b(IntentFilter intentFilter) {
        return ((\u5c01\u88c5)intentFilter).\u8d4b\u80fd.\u8d4b\u80fd.hashCode();
    }

    @Override
    public final Object \u8d4b\u80fd(IntentFilter intentFilter, int n, int n2) {
        return (\u5c01\u88c5)intentFilter;
    }

    @Override
    public final void \u8d4b\u80fd(IntentFilter intentFilter) {
        \u5c01\u88c5 \u5c01\u88c52 = (\u5c01\u88c5)intentFilter;
        \u6218\u5f79 \u6218\u5f792 = this;
        synchronized (\u6218\u5f792) {
            super.\u8d4b\u80fd((IntentFilter)\u5c01\u88c52);
            return;
        }
    }

    @Override
    public final void \u8d4b\u80fd(\u5c01\u88c5 \u5c01\u88c52) {
        \u6218\u5f79 \u6218\u5f792 = this;
        synchronized (\u6218\u5f792) {
            super.\u8d4b\u80fd(\u5c01\u88c52);
            return;
        }
    }

    @Override
    public final boolean \u8d4b\u80fd(String string, IntentFilter intentFilter) {
        \u5c01\u88c5 \u5c01\u88c52 = (\u5c01\u88c5)intentFilter;
        return string == null || Intrinsics.areEqual((Object)string, (Object)\u5c01\u88c52.\u6293\u624b);
        {
        }
    }
}

