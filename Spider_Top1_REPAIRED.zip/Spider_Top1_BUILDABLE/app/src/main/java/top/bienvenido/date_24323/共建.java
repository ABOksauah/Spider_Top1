/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.servertransaction.ClientTransaction
 *  android.app.servertransaction.ClientTransactionItem
 *  android.app.servertransaction.LaunchActivityItem
 *  android.app.servertransaction.NewIntentItem
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.List
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$ObjectRef
 *  top.bienvenido.date_24323.\u52a0\u6301
 */
package top.bienvenido.date_24323;

import android.app.servertransaction.ClientTransaction;
import android.app.servertransaction.ClientTransactionItem;
import android.app.servertransaction.LaunchActivityItem;
import android.app.servertransaction.NewIntentItem;
import android.os.IBinder;
import android.os.Parcelable;
import java.lang.reflect.Method;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u4f53\u611f;
import top.bienvenido.date_24323.\u5171\u5efa$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5171\u5efa$$ExternalSyntheticLambda1;
import top.bienvenido.date_24323.\u52a0\u6301;
import top.bienvenido.date_24323.\u52a0\u901f;
import top.bienvenido.date_24323.\u611f\u77e5;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u652f\u63f4;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u8170\u90e8;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u5171\u5efa
extends \u96c6\u6210 {
    public static final \u5171\u5efa \u6293\u624b = new \u5171\u5efa();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final Unit \u8d4b\u80fd(Function1 function1, Ref.ObjectRef objectRef, Function1 function12, ClientTransaction clientTransaction) {
        List list = (List)function1.invoke((Object)clientTransaction);
        if (list == null) return Unit.INSTANCE;
        Object object = CollectionsKt.firstOrNull((List)list);
        if (object == null) return Unit.INSTANCE;
        try {
            if (object instanceof LaunchActivityItem) {
                ((Function2)objectRef.element).invoke(object, (Object)clientTransaction.getActivityToken());
                return Unit.INSTANCE;
            } else {
                if (!(object instanceof NewIntentItem)) return Unit.INSTANCE;
                function12.invoke(object);
            }
            return Unit.INSTANCE;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return Unit.INSTANCE;
    }

    public static final Unit \u8d4b\u80fd(Ref.ObjectRef objectRef, LaunchActivityItem launchActivityItem) {
        try {
            ((Function2)objectRef.element).invoke((Object)launchActivityItem, (Object)launchActivityItem.getActivityToken());
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return Unit.INSTANCE;
    }

    @Override
    public final void \u8d4b\u80fd() {
        boolean bl = \u62bd\u8c61.\u5bf9\u9f50;
        if (!bl && \u62bd\u8c61.\u540c\u6b65) {
            try {
                Method method = ClientTransactionItem.class.getDeclaredMethod("getActivityToken", \u4e0b\u6c89.\u6293\u624b);
                method.setAccessible(true);
                bl = method.getReturnType().isInterface();
            }
            catch (Throwable throwable) {
                bl = false;
            }
        }
        Object object = new \u611f\u77e5(\u771f\u9999.\u8d4b\u80fd(LaunchActivityItem.class, "mIntent"), \u771f\u9999.\u8d4b\u80fd(LaunchActivityItem.class, "mInfo"), \u771f\u9999.\u8d4b\u80fd(LaunchActivityItem.class, "mReferrer"));
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        if (\u62bd\u8c61.\u5e73\u53f0) {
            object = new \u652f\u63f4(objectRef, (\u611f\u77e5)object);
        }
        objectRef.element = object;
        \u4f53\u611f \u4f53\u611f2 = new \u4f53\u611f(\u771f\u9999.\u8d4b\u80fd(NewIntentItem.class, "mIntents"));
        if (bl) {
            \u5171\u5efa$$ExternalSyntheticLambda0 \u5171\u5efa$$ExternalSyntheticLambda0 = new \u5171\u5efa$$ExternalSyntheticLambda0(objectRef);
            \u81ea\u6d3d \u81ea\u6d3d2 = \u771f\u9999.\u8d4b\u80fd(LaunchActivityItem.class, "CREATOR");
            \u81ea\u6d3d2.\u8d4b\u80fd((Object)null, (Object)new \u8170\u90e8((Parcelable.Creator)\u81ea\u6d3d2.\u8d4b\u80fd(null), \u5171\u5efa$$ExternalSyntheticLambda0));
            \u81ea\u6d3d \u81ea\u6d3d3 = \u771f\u9999.\u8d4b\u80fd(NewIntentItem.class, "CREATOR");
            \u81ea\u6d3d3.\u8d4b\u80fd((Object)null, (Object)new \u8170\u90e8((Parcelable.Creator)\u81ea\u6d3d3.\u8d4b\u80fd(null), \u4f53\u611f2));
            return;
        }
        Object object2 = \u62bd\u8c61.\u7ed9\u5230 ? \u52a0\u6301.\u8d4b\u80fd : new \u52a0\u901f();
        \u5171\u5efa$$ExternalSyntheticLambda1 \u5171\u5efa$$ExternalSyntheticLambda1 = new \u5171\u5efa$$ExternalSyntheticLambda1((Function1)object2, objectRef, \u4f53\u611f2);
        \u81ea\u6d3d \u81ea\u6d3d4 = \u771f\u9999.\u8d4b\u80fd(ClientTransaction.class, "CREATOR");
        \u81ea\u6d3d4.\u8d4b\u80fd((Object)null, (Object)new \u8170\u90e8((Parcelable.Creator)\u81ea\u6d3d4.\u8d4b\u80fd(null), \u5171\u5efa$$ExternalSyntheticLambda1));
    }
}

