/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u5cf0\u503c
 *  top.bienvenido.date_24323.\u6f0f\u6d1e
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u5361\u8ba4\u77e5;
import top.bienvenido.date_24323.\u5cf0\u503c;
import top.bienvenido.date_24323.\u6f0f\u6d1e;

public final class \u98ce\u9669
extends \u5361\u8ba4\u77e5 {
    public final \u5cf0\u503c \u6293\u624b = \u5cf0\u503c.\u8d4b\u80fd;
    public final \u6f0f\u6d1e \u8d4b\u80fd = \u6f0f\u6d1e.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

