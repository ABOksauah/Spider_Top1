/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u7b14\u82af;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda14
implements Function1 {
    public final /* synthetic */ IBinder f$0;
    public final /* synthetic */ Intent f$1;
    public final /* synthetic */ IBinder f$2;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda14(IBinder iBinder, Intent intent, IBinder iBinder2) {
        this.f$0 = iBinder;
        this.f$1 = intent;
        this.f$2 = iBinder2;
    }

    public final Object invoke(Object object) {
        return \u6bb5\u4f4d.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, (\u7b14\u82af)object);
    }
}

