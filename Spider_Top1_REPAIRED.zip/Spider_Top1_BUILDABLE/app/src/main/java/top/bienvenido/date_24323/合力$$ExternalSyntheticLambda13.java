/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u5408\u529b
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u53d8\u9769;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u54c1\u724c;

public final class \u5408\u529b$$ExternalSyntheticLambda13
implements Runnable {
    public final /* synthetic */ \u53d8\u9769 f$0;
    public final /* synthetic */ \u54c1\u724c f$1;
    public final /* synthetic */ IBinder f$2;

    public /* synthetic */ \u5408\u529b$$ExternalSyntheticLambda13(\u53d8\u9769 \u53d8\u97692, \u54c1\u724c \u54c1\u724c2, IBinder iBinder) {
        this.f$0 = \u53d8\u97692;
        this.f$1 = \u54c1\u724c2;
        this.f$2 = iBinder;
    }

    public final void run() {
        \u5408\u529b.\u8d4b\u80fd((\u53d8\u9769)this.f$0, (\u54c1\u724c)this.f$1, (IBinder)this.f$2);
    }
}

