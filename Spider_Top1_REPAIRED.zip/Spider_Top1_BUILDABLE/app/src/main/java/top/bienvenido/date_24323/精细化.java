/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ObbInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.MutablePropertyReference1Impl
 */
package top.bienvenido.date_24323;

import android.content.res.ObbInfo;
import kotlin.jvm.internal.MutablePropertyReference1Impl;

public final class \u7cbe\u7ec6\u5316
extends MutablePropertyReference1Impl {
    public static final \u7cbe\u7ec6\u5316 \u8d4b\u80fd = new \u7cbe\u7ec6\u5316();

    public \u7cbe\u7ec6\u5316() {
        super(ObbInfo.class, "packageName", "getPackageName()Ljava/lang/String;", 0);
    }

    public final Object get(Object object) {
        return ((ObbInfo)object).packageName;
    }

    public final void set(Object object, Object object2) {
        ((ObbInfo)object).packageName = (String)object2;
    }
}

