/*
 * Decompiled with CFR 0.0.
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u516c\u57df;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u6613\u7528\u6027
extends \u96c6\u6210 {
    public static final \u6613\u7528\u6027 \u6293\u624b = new \u6613\u7528\u6027();

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("wifi", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-886176881, 971749735, -1685137099, 1046406358, -2129330689}, \u672c\u6211.\u54cd\u5e94);
    }
}

