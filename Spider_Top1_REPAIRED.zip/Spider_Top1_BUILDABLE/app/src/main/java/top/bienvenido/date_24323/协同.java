/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.os.IBinder
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u534f\u540c$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u534f\u540c
extends \u89e6\u8fbe {
    public static final ComponentName \u8d4b\u80fd(IBinder iBinder, \u5e03\u5c40 \u5e03\u5c402) {
        return \u5e03\u5c402.\u8d4b\u80fd(iBinder);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IBinder iBinder = (IBinder)arrobject[0];
        if (iBinder == null) return method.invoke(object, arrobject);
        try {
            return \u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u534f\u540c$$ExternalSyntheticLambda0(iBinder));
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

