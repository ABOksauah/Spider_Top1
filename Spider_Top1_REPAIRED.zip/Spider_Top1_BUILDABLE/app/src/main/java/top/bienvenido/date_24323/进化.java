/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.Attribution
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ConfigurationInfo
 *  android.content.pm.FeatureGroupInfo
 *  android.content.pm.FeatureInfo
 *  android.content.pm.InstrumentationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageParser
 *  android.content.pm.PackageParser$Component
 *  android.content.pm.PackageParser$Instrumentation
 *  android.content.pm.PackageParser$Package
 *  android.content.pm.PackageParser$Permission
 *  android.content.pm.PackageParser$Provider
 *  android.content.pm.PermissionInfo
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ServiceInfo
 *  android.content.pm.SharedLibraryInfo
 *  android.content.pm.Signature
 *  android.content.pm.SigningInfo
 *  android.net.Uri
 *  android.os.Bundle
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.collections.ArraysKt
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.text.StringsKt
 *  sun.misc.Unsafe
 *  top.bienvenido.date_24323.\u53cd\u601d
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u5c65\u7ea6
 *  top.bienvenido.date_24323.\u601d\u8003
 *  top.bienvenido.date_24323.\u62bd\u79bb
 *  top.bienvenido.date_24323.\u64cd\u76d8
 *  top.bienvenido.date_24323.\u6df1\u8015
 *  top.bienvenido.date_24323.\u7a81\u56f4
 *  top.bienvenido.date_24323.\u7cbe\u7b80
 *  top.bienvenido.date_24323.\u7ea6\u675f
 *  top.bienvenido.date_24323.\u8865\u4f4d
 *  top.bienvenido.date_24323.\u8d77\u98de
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.Attribution;
import android.content.pm.ComponentInfo;
import android.content.pm.ConfigurationInfo;
import android.content.pm.FeatureGroupInfo;
import android.content.pm.FeatureInfo;
import android.content.pm.InstrumentationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageParser;
import android.content.pm.PermissionInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.SharedLibraryInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.net.Uri;
import android.os.Bundle;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.text.StringsKt;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u4ed8\u8d39;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u53cd\u601d;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u5c65\u7ea6;
import top.bienvenido.date_24323.\u601d\u8003;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3;
import top.bienvenido.date_24323.\u62bd\u79bb;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u64cd\u76d8;
import top.bienvenido.date_24323.\u6d41\u5931;
import top.bienvenido.date_24323.\u6df1\u8015;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u7a81\u56f4;
import top.bienvenido.date_24323.\u7cbe\u7b80;
import top.bienvenido.date_24323.\u7ea6\u675f;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8865\u4f4d;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u8fd4\u4f63;

public final class \u8fdb\u5316 {
    public static final \u8fdb\u5316 \u8d4b\u80fd = new \u8fdb\u5316();

    public static int \u8d4b\u80fd(String string2) {
        int n = string2.length();
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            n2 = n2 * 31 + i * 31 + 31 * string2.charAt(i);
        }
        return Math.abs((int)n2);
    }

    public static void \u8d4b\u80fd(ApplicationInfo applicationInfo) {
        if (\u62bd\u8c61.\u6c89\u6dc0) {
            String[] arrstring = \u62bd\u8c61.\u7ed9\u5230 ? new String[]{"/system/framework/org.apache.http.legacy.jar", "/system/framework/android.test.base.jar"} : new String[]{"/system/framework/org.apache.http.legacy.jar"};
            \u8d77\u98de \u8d77\u98de2 = \u51b7\u542f\u52a8.\u8d4b\u80fd;
            List list = (List)\u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo);
            if (list == null) {
                list = new ArrayList(arrstring.length);
                \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, (Object)list);
            }
            for (String string2 : arrstring) {
                SharedLibraryInfo sharedLibraryInfo = (SharedLibraryInfo)\u62a4\u57ce\u6cb3.\u6293\u624b.allocateInstance(SharedLibraryInfo.class);
                \u51b7\u542f\u52a8.\u6c89\u6dc0.\u6293\u624b.\u8d4b\u80fd((Object)sharedLibraryInfo, (Object)string2);
                list.add((Object)sharedLibraryInfo);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u8d4b\u80fd(ApplicationInfo applicationInfo, ApplicationInfo applicationInfo2) {
        try {
            String string2;
            applicationInfo.dataDir = string2 = applicationInfo2.dataDir;
            if (\u62bd\u8c61.\u4e2d\u53f0) {
                applicationInfo.deviceProtectedDataDir = string2;
                \u51b7\u542f\u52a8.\u7ed9\u5230.\u8d4b\u80fd((Object)applicationInfo, (Object)string2);
            }
            if (\u62bd\u8c61.\u843d\u5730) {
                applicationInfo.splitNames = applicationInfo2.splitNames;
            }
            if (\u62bd\u8c61.\u6f0f\u6597 && (134217728 & applicationInfo.flags) != 0) {
                \u8d77\u98de \u8d77\u98de2 = \u51b7\u542f\u52a8.\u6f0f\u6597;
                Integer n = 0;
                \u8d77\u98de2.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, (Object)n);
            }
            applicationInfo.sharedLibraryFiles = applicationInfo2.sharedLibraryFiles;
            \u8fdb\u5316.\u8d4b\u80fd(applicationInfo);
            String string3 = applicationInfo2.processName;
            String string4 = string3 != null && string3.length() != 0 ? applicationInfo2.processName : applicationInfo.packageName;
            applicationInfo.processName = string4;
            applicationInfo.nativeLibraryDir = applicationInfo2.nativeLibraryDir;
            applicationInfo.sourceDir = applicationInfo2.sourceDir;
            applicationInfo.publicSourceDir = applicationInfo2.publicSourceDir;
            \u8d77\u98de \u8d77\u98de3 = \u51b7\u542f\u52a8.\u6293\u624b;
            Object object = \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo2);
            \u8d77\u98de3.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, object);
            \u8d77\u98de \u8d77\u98de4 = \u51b7\u542f\u52a8.\u4e2d\u53f0;
            Object object2 = \u8d77\u98de4.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo2);
            \u8d77\u98de4.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, object2);
            \u8d77\u98de \u8d77\u98de5 = \u51b7\u542f\u52a8.\u95ed\u73af;
            Object object3 = \u8d77\u98de5.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo2);
            \u8d77\u98de5.\u6293\u624b.\u8d4b\u80fd((Object)applicationInfo, object3);
            applicationInfo.splitSourceDirs = applicationInfo2.splitSourceDirs;
            applicationInfo.splitPublicSourceDirs = applicationInfo2.splitPublicSourceDirs;
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static void \u8d4b\u80fd(ComponentInfo componentInfo, ApplicationInfo applicationInfo) {
        String string2;
        if (componentInfo.packageName == null) {
            componentInfo.packageName = applicationInfo.packageName;
        }
        if ((string2 = componentInfo.processName) == null || string2.length() == 0) {
            String string3 = applicationInfo.processName;
            if (string3 == null || string3.length() == 0) {
                string3 = applicationInfo.packageName;
            }
            componentInfo.processName = string3;
        }
        componentInfo.applicationInfo = applicationInfo;
        String string4 = componentInfo.name;
        if (string4 != null && StringsKt.startsWith$default((CharSequence)string4, (char)'.', (boolean)false, (int)2, null)) {
            String string5 = applicationInfo.packageName;
            String string6 = componentInfo.name;
            componentInfo.name = string5 + string6;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void \u8d4b\u80fd(\u64cd\u76d8 \u64cd\u76d82, int n) {
        try {
            String string2;
            ArrayList arrayList;
            int n2;
            int[] arrn;
            \u8fd4\u4f63 \u8fd4\u4f632;
            PackageInfo packageInfo = \u64cd\u76d82.\u4e2d\u53f0;
            PackageParser.Package package_ = new PackageParser().parsePackage(new File(\u64cd\u76d82.\u95ed\u73af.sourceDir), 0);
            ApplicationInfo applicationInfo = package_.applicationInfo;
            if (applicationInfo == null) return;
            \u8fdb\u5316.\u8d4b\u80fd(applicationInfo, \u64cd\u76d82.\u95ed\u73af);
            String string3 = packageInfo.packageName;
            int n3 = string3.hashCode();
            int n4 = ArraysKt.contains((int[])\u4ed8\u8d39.\u6293\u624b, (int)n3) ? \u8fdb\u5316.\u8d4b\u80fd("com.google") : ((string2 = packageInfo.sharedUserId) != null && string2.length() != 0 ? \u8fdb\u5316.\u8d4b\u80fd(string2) : \u8fdb\u5316.\u8d4b\u80fd(string3));
            applicationInfo.uid = 13000 + n4 % 7000;
            int n5 = 1;
            applicationInfo.enabled = n5;
            applicationInfo.metaData = package_.mAppMetaData;
            applicationInfo.flags = 8683588 | applicationInfo.flags;
            packageInfo.applicationInfo = applicationInfo;
            \u64cd\u76d82.\u95ed\u73af = applicationInfo;
            \u64cd\u76d82.\u6f0f\u6597 = \u8fd4\u4f632 = new \u8fd4\u4f63(package_.activities.size() + package_.receivers.size() + package_.services.size() + package_.providers.size());
            packageInfo.activities = (ActivityInfo[])\u8fdb\u5316.\u8d4b\u80fd(package_.activities, \u8fd4\u4f632, applicationInfo, (Function1)\u601d\u8003.\u8d4b\u80fd, (Function1)\u53cd\u601d.\u8d4b\u80fd);
            packageInfo.receivers = (ActivityInfo[])\u8fdb\u5316.\u8d4b\u80fd(package_.receivers, \u8fd4\u4f632, applicationInfo, (Function1)\u7cbe\u7b80.\u8d4b\u80fd, (Function1)\u6df1\u8015.\u8d4b\u80fd);
            packageInfo.services = (ServiceInfo[])\u8fdb\u5316.\u8d4b\u80fd(package_.services, \u8fd4\u4f632, applicationInfo, (Function1)\u7a81\u56f4.\u8d4b\u80fd, (Function1)\u8865\u4f4d.\u8d4b\u80fd);
            ArrayList arrayList2 = package_.providers;
            int n6 = arrayList2.size();
            int[] arrn2 = n6 == 0 ? \u4e0b\u6c89.\u8d4b\u80fd : new int[n6];
            Iterator iterator = arrayList2.iterator();
            int n7 = 0;
            do {
                String string4;
                Iterator iterator2;
                block17 : {
                    block16 : {
                        block15 : {
                            if (!iterator.hasNext()) break block15;
                            ProviderInfo providerInfo = ((PackageParser.Provider)iterator.next()).info;
                            string4 = providerInfo.authority;
                            if (string4 == null) break block16;
                            break block17;
                        }
                        packageInfo.providers = (ProviderInfo[])\u8fdb\u5316.\u8d4b\u80fd(arrayList2, \u8fd4\u4f632, applicationInfo, (Function1)\u62bd\u79bb.\u8d4b\u80fd, (Function1)\u5c65\u7ea6.\u8d4b\u80fd);
                        String[] arrstring = (String[])package_.requestedPermissions.toArray((Object[])\u4e0b\u6c89.\u95ed\u73af);
                        packageInfo.requestedPermissions = arrstring;
                        n2 = arrstring.length;
                        arrn = new int[n2];
                        break;
                    }
                    n5 = 1;
                    continue;
                }
                char[] arrc = new char[n5];
                arrc[0] = 59;
                List list = StringsKt.split$default((CharSequence)string4, (char[])arrc, (boolean)false, (int)0, (int)6, null);
                ArrayList arrayList3 = new ArrayList(list.size());
                Iterator iterator3 = list.iterator();
                do {
                    String string5;
                    Iterator iterator4;
                    boolean bl;
                    Iterator iterator5;
                    block21 : {
                        block19 : {
                            int n8;
                            block20 : {
                                block18 : {
                                    if (!iterator3.hasNext()) break block18;
                                    string5 = (String)iterator3.next();
                                    int n9 = string5.hashCode();
                                    iterator5 = iterator;
                                    int n10 = \u753b\u997c.\u8d4b\u80fd(arrn2, n7, n9);
                                    if (n10 >= 0) break block19;
                                    int n11 = n10;
                                    iterator4 = iterator3;
                                    n8 = n7 + 1;
                                    if (n8 <= arrn2.length) {
                                        System.arraycopy((Object)arrn2, (int)n11, (Object)arrn2, (int)(n11 + 1), (int)(n7 - n11));
                                        arrn2[n11] = n9;
                                    } else {
                                        int[] arrn3 = new int[(n7 | 1) << 1];
                                        System.arraycopy((Object)arrn2, (int)0, (Object)arrn3, (int)0, (int)n11);
                                        arrn3[n11] = n9;
                                        System.arraycopy((Object)arrn2, (int)n11, (Object)arrn3, (int)(n11 + 1), (int)(arrn2.length - n11));
                                        arrn2 = arrn3;
                                    }
                                    break block20;
                                }
                                iterator2 = iterator;
                                if (arrayList3.isEmpty()) {
                                    providerInfo.authority = null;
                                    break;
                                }
                                if (arrayList3.size() == list.size()) break;
                                providerInfo.authority = CollectionsKt.joinToString$default((Iterable)arrayList3, (CharSequence)";", null, null, (int)0, null, null, (int)62, null);
                                break;
                            }
                            n7 = n8;
                            bl = true;
                            break block21;
                        }
                        iterator4 = iterator3;
                        bl = false;
                    }
                    if (bl) {
                        arrayList3.add((Object)string5);
                    }
                    iterator3 = iterator4;
                    iterator = iterator5;
                } while (true);
                iterator = iterator2;
                n5 = 1;
            } while (true);
            for (int i = 0; i < n2; ++i) {
                arrn[i] = 3;
            }
            packageInfo.requestedPermissionsFlags = arrn;
            int[] arrn4 = \u4e0b\u6c89.\u8d4b\u80fd;
            packageInfo.gids = arrn4;
            if (\u62bd\u8c61.\u8d4b\u80fd) {
                String[] arrstring = packageInfo.splitNames;
                if (arrstring != null && arrstring.length != 0) {
                    arrn4 = new int[arrstring.length];
                }
                packageInfo.splitRevisionCodes = arrn4;
            }
            FeatureInfo[] arrfeatureInfo = (arrayList = package_.reqFeatures) != null ? (FeatureInfo[])arrayList.toArray((Object[])new FeatureInfo[0]) : null;
            packageInfo.reqFeatures = arrfeatureInfo;
            ArrayList arrayList4 = package_.configPreferences;
            ConfigurationInfo[] arrconfigurationInfo = arrayList4 != null ? (ConfigurationInfo[])arrayList4.toArray((Object[])new ConfigurationInfo[0]) : null;
            packageInfo.configPreferences = arrconfigurationInfo;
            ArrayList arrayList5 = package_.instrumentation;
            ArrayList arrayList6 = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)arrayList5, (int)10));
            for (PackageParser.Instrumentation instrumentation : arrayList5) {
                InstrumentationInfo instrumentationInfo = instrumentation.info;
                instrumentationInfo.metaData = instrumentation.metaData;
                arrayList6.add((Object)instrumentationInfo);
            }
            packageInfo.instrumentation = (InstrumentationInfo[])arrayList6.toArray((Object[])new InstrumentationInfo[0]);
            ArrayList arrayList7 = package_.permissions;
            ArrayList arrayList8 = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)arrayList7, (int)10));
            for (PackageParser.Permission permission : arrayList7) {
                PermissionInfo permissionInfo = permission.info;
                permissionInfo.metaData = permission.metaData;
                arrayList8.add((Object)permissionInfo);
            }
            packageInfo.permissions = (PermissionInfo[])arrayList8.toArray((Object[])new PermissionInfo[0]);
            ArrayList arrayList9 = package_.featureGroups;
            FeatureGroupInfo[] arrfeatureGroupInfo = arrayList9 != null ? (FeatureGroupInfo[])arrayList9.toArray((Object[])new FeatureGroupInfo[0]) : null;
            packageInfo.featureGroups = arrfeatureGroupInfo;
            \u64cd\u76d82.\u843d\u5730 = new \u7ea6\u675f(package_);
            if (n == 0) return;
            {
                String string6 = n == 1 ? "android.intent.action.PACKAGE_ADDED" : "android.intent.action.PACKAGE_REPLACED";
                Intent intent = new Intent(string6);
                intent.setData(Uri.fromParts((String)"package", (String)packageInfo.packageName, null));
                \u5408\u529b.\u6293\u624b.\u6293\u624b(intent, null);
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static ComponentInfo[] \u8d4b\u80fd(ArrayList arrayList, \u8fd4\u4f63 \u8fd4\u4f632, ApplicationInfo applicationInfo, Function1 function1, Function1 function12) {
        if (arrayList.isEmpty()) {
            return null;
        }
        ArrayList arrayList2 = new ArrayList(arrayList.size());
        try {
            for (PackageParser.Component component : arrayList) {
                ComponentInfo componentInfo = (ComponentInfo)function1.invoke((Object)component);
                \u8fdb\u5316.\u8d4b\u80fd(componentInfo, applicationInfo);
                componentInfo.metaData = component.metaData;
                String string2 = componentInfo.name;
                \u8fd4\u4f632.\u8d4b\u80fd.\u8d4b\u80fd(string2.hashCode(), (Object)componentInfo);
                arrayList2.add((Object)componentInfo);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return (ComponentInfo[])function12.invoke((Object)arrayList2);
    }

    public final PackageInfo \u8d4b\u80fd(PackageInfo packageInfo, int n) {
        PackageInfo packageInfo2 = new PackageInfo();
        packageInfo2.lastUpdateTime = packageInfo.lastUpdateTime;
        packageInfo2.firstInstallTime = packageInfo.firstInstallTime;
        packageInfo2.reqFeatures = packageInfo.reqFeatures;
        packageInfo2.featureGroups = packageInfo.featureGroups;
        packageInfo2.packageName = packageInfo.packageName;
        packageInfo2.splitNames = packageInfo.splitNames;
        packageInfo2.versionName = packageInfo.versionName;
        packageInfo2.sharedUserId = packageInfo.sharedUserId;
        packageInfo2.applicationInfo = packageInfo.applicationInfo;
        packageInfo2.sharedUserLabel = packageInfo.sharedUserLabel;
        packageInfo2.installLocation = packageInfo.installLocation;
        if (\u62bd\u8c61.\u8d4b\u80fd) {
            packageInfo2.baseRevisionCode = packageInfo.baseRevisionCode;
            packageInfo2.splitRevisionCodes = packageInfo.splitRevisionCodes;
        }
        if (\u62bd\u8c61.\u6f0f\u6597) {
            packageInfo2.setLongVersionCode(packageInfo.getLongVersionCode());
            if ((134217728 & n) != 0) {
                packageInfo2.signingInfo = packageInfo.signingInfo;
            }
        } else {
            packageInfo2.versionCode = packageInfo.versionCode;
        }
        if (\u62bd\u8c61.\u5e73\u53f0) {
            packageInfo2.attributions = packageInfo.attributions;
        }
        if ((n & 1) != 0) {
            packageInfo2.activities = packageInfo.activities;
        }
        if ((n & 2) != 0) {
            packageInfo2.receivers = packageInfo.receivers;
        }
        if ((n & 8) != 0) {
            packageInfo2.providers = packageInfo.providers;
        }
        if ((n & 4) != 0) {
            packageInfo2.services = packageInfo.services;
        }
        if ((n & 4096) != 0) {
            packageInfo2.permissions = packageInfo.permissions;
            packageInfo2.requestedPermissions = packageInfo.requestedPermissions;
            packageInfo2.requestedPermissionsFlags = packageInfo.requestedPermissionsFlags;
        }
        if ((n & 16384) != 0) {
            packageInfo2.configPreferences = packageInfo.configPreferences;
        }
        if ((n & 16) != 0) {
            packageInfo2.instrumentation = packageInfo.instrumentation;
        }
        if ((n & 256) != 0) {
            packageInfo2.gids = packageInfo.gids;
        }
        if ((n & 64) != 0) {
            packageInfo2.signatures = packageInfo.signatures;
        }
        return packageInfo2;
    }
}

