/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u4f53\u7cfb;

public final class \u4f53\u7cfb$$ExternalSyntheticLambda3
implements Runnable {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u4f53\u7cfb$$ExternalSyntheticLambda3(String string2) {
        this.f$0 = string2;
    }

    public final void run() {
        \u4f53\u7cfb.\u4e2d\u53f0(this.f$0);
    }
}

