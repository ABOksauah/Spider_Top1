/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.os.IBinder
 *  java.lang.Integer
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u84c4\u80fd
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u84c4\u80fd;

public final class \u84c4\u80fd$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ ComponentName f$0;
    public final /* synthetic */ IBinder f$1;
    public final /* synthetic */ Integer f$2;

    public /* synthetic */ \u84c4\u80fd$$ExternalSyntheticLambda0(ComponentName componentName, IBinder iBinder, Integer n) {
        this.f$0 = componentName;
        this.f$1 = iBinder;
        this.f$2 = n;
    }

    public final Object invoke(Object object) {
        return \u84c4\u80fd.\u8d4b\u80fd((ComponentName)this.f$0, (IBinder)this.f$1, (Integer)this.f$2, (\u7b14\u82af)((\u7b14\u82af)object));
    }
}

