/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.net.Authenticator
 *  java.net.Authenticator$RequestorType
 *  java.net.PasswordAuthentication
 */
package top.bienvenido.date_24323;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

public final class \u5c42\u7ea7
extends Authenticator {
    public final /* synthetic */ char[] \u6293\u624b;
    public final /* synthetic */ String \u8d4b\u80fd;

    public \u5c42\u7ea7(String string2, char[] arrc) {
        this.\u8d4b\u80fd = string2;
        this.\u6293\u624b = arrc;
    }

    public final PasswordAuthentication getPasswordAuthentication() {
        if (this.getRequestorType() == Authenticator.RequestorType.PROXY) {
            return new PasswordAuthentication(this.\u8d4b\u80fd, this.\u6293\u624b);
        }
        return super.getPasswordAuthentication();
    }
}

