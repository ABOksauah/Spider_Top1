/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Comparable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.concurrent.Callable
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  top.bienvenido.date_24323.\u4f18\u5148\u7ea7
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u4f18\u5148\u7ea7;

public final class \u4e0b\u9650
implements Callable,
Comparable {
    public Object \u8d4b\u80fd;

    public final Object call() {
        return this.\u8d4b\u80fd;
    }

    public final int compareTo(Object object) {
        block8 : {
            block10 : {
                block9 : {
                    block7 : {
                        if (!(object instanceof Class)) break block7;
                        this.\u8d4b\u80fd = object;
                        return 1;
                    }
                    if (!(object instanceof String)) break block8;
                    if (!StringsKt.startsWith$default((String)((String)object), (String)"deps:", (boolean)false, (int)2, null)) break block9;
                    this.\u8d4b\u80fd = "30064";
                    return 1;
                }
                if (!StringsKt.startsWith$default((String)((String)object), (String)"marco:", (boolean)false, (int)2, null)) break block10;
                \u4f18\u5148\u7ea7.\u8d4b\u80fd((String)((String)object).substring(6));
                this.\u8d4b\u80fd = object;
                return 1;
            }
            Method[] arrmethod = ((Class)this.\u8d4b\u80fd).getDeclaredMethods();
            int n = arrmethod.length;
            for (int i = 0; i < n; ++i) {
                try {
                    Method method = arrmethod[i];
                    if (!Intrinsics.areEqual((Object)method.getName(), (Object)object) || (256 & method.getModifiers()) == 0) continue;
                    this.\u8d4b\u80fd = method;
                    return 1;
                }
                catch (Exception exception) {
                    // empty catch block
                    break;
                }
            }
        }
        return 0;
    }
}

