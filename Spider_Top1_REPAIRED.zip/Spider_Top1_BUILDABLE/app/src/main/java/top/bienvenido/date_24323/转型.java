/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcel
 *  android.os.Process
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u516c\u5173
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u683c\u5c40
 *  top.bienvenido.date_24323.\u75d2\u70b9
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Process;
import top.bienvenido.date_24323.\u516c\u5173;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u75d2\u70b9;
import top.bienvenido.date_24323.\u78b0\u4e00\u4e0b;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.date_24323.\u9ad8\u5730;

public final class \u8f6c\u578b
extends Binder {
    public static final Bundle \u6293\u624b;
    public static final \u8f6c\u578b \u8d4b\u80fd;

    static {
        \u8f6c\u578b \u8f6c\u578b2;
        \u8d4b\u80fd = \u8f6c\u578b2 = new \u8f6c\u578b();
        Bundle bundle = new Bundle();
        \u516c\u5173 \u516c\u51732 = \u516c\u5173.\u6293\u624b;
        bundle.putBinder(\u516c\u51732.getInterfaceDescriptor(), (IBinder)\u516c\u51732);
        \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
        bundle.putBinder(\u8fb9\u754c2.getInterfaceDescriptor(), (IBinder)\u8fb9\u754c2);
        \u5408\u529b \u5408\u529b2 = \u5408\u529b.\u6293\u624b;
        bundle.putBinder(\u5408\u529b2.getInterfaceDescriptor(), (IBinder)\u5408\u529b2);
        \u75d2\u70b9 \u75d2\u70b92 = \u75d2\u70b9.\u6293\u624b;
        bundle.putBinder(\u75d2\u70b92.getInterfaceDescriptor(), (IBinder)\u75d2\u70b92);
        \u683c\u5c40 \u683c\u5c402 = \u683c\u5c40.\u6293\u624b;
        bundle.putBinder(\u683c\u5c402.getInterfaceDescriptor(), (IBinder)\u683c\u5c402);
        bundle.putBinder("https://www.62v.net/jnative/binder", (IBinder)\u8f6c\u578b2);
        bundle.putInt(Integer.TYPE.getName(), Process.myPid());
        \u6293\u624b = bundle;
    }

    public final String getInterfaceDescriptor() {
        return "https://www.62v.net/jnative/binder";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b2;
        if (n != 7001) return super.onTransact(n, parcel, parcel2, n2);
        long l = parcel.readLong();
        int n3 = (int)((-4294967296L & l) >>> 32);
        int n4 = (int)(l & 0xFFFFFFFFL);
        \u78b0\u4e00\u4e0b \u78b0\u4e00\u4e0b3 = \u78b0\u4e00\u4e0b2 = \u9ad8\u5730.\u4e2d\u53f0;
        // MONITORENTER : \u78b0\u4e00\u4e0b3
        Object object = \u78b0\u4e00\u4e0b2.\u8d4b\u80fd.\u8d4b\u80fd(n4);
        // MONITOREXIT : \u78b0\u4e00\u4e0b3
        try {
            \u54c1\u724c \u54c1\u724c2;
            \u54c1\u724c \u54c1\u724c3 = (\u54c1\u724c)object;
            int n5 = -1;
            if (\u54c1\u724c3 != null && (\u54c1\u724c2 = (\u54c1\u724c)\u78b0\u4e00\u4e0b2.\u8d4b\u80fd(n3)) != null) {
                if (\u54c1\u724c2.\u8d4b\u80fd.hashCode() == \u54c1\u724c3.\u8d4b\u80fd.hashCode()) {
                    n5 = \u98ce\u53e3.\u4e2d\u53f0;
                } else {
                    n5 = \u54c1\u724c3.\u6f0f\u6597;
                    if (n5 == \u54c1\u724c2.\u6f0f\u6597) {
                        n5 = \u98ce\u53e3.\u4e2d\u53f0;
                    }
                }
            }
            parcel2.writeInt(n5);
            return true;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return true;
    }
}

