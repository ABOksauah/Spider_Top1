/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  com.android.internal.content.ReferrerIntent
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  kotlin.Triple
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import com.android.internal.content.ReferrerIntent;
import java.util.List;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u805a\u5408;
import top.bienvenido.date_24323.\u81ea\u6d3d;

public final class \u4f53\u611f
implements Function1 {
    public final /* synthetic */ \u81ea\u6d3d \u8d4b\u80fd;

    public \u4f53\u611f(\u81ea\u6d3d \u81ea\u6d3d2) {
        this.\u8d4b\u80fd = \u81ea\u6d3d2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Object invoke(Object object) {
        int n;
        List list;
        try {
            list = (List)this.\u8d4b\u80fd.\u8d4b\u80fd(object);
            n = list.size();
        }
        catch (Throwable throwable) {
            // empty catch block
            return Unit.INSTANCE;
        }
        for (int i = 0; i < n; ++i) {
            Intent intent;
            Intent intent2 = (Intent)list.get(i);
            Triple triple = \u805a\u5408.\u8d4b\u80fd(intent2);
            if (triple == null) continue;
            if (\u62bd\u8c61.\u8d4b\u80fd) {
                Intent intent3 = (Intent)triple.getFirst();
                String string = (String)triple.getThird();
                if (string == null) {
                    string = ((ReferrerIntent)intent2).mReferrer;
                }
                intent = new ReferrerIntent(intent3, string);
            } else {
                intent = (Intent)triple.getFirst();
            }
            list.set(i, (Object)intent);
        }
        return Unit.INSTANCE;
    }
}

