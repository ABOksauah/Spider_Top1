/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u6fc0\u6d3b;
import top.bienvenido.date_24323.\u9ad8\u5730;

public final class \u9ad8\u5730$$ExternalSyntheticLambda0
implements Function2 {
    public final /* synthetic */ \u54c1\u724c f$0;

    public /* synthetic */ \u9ad8\u5730$$ExternalSyntheticLambda0(\u54c1\u724c \u54c1\u724c2) {
        this.f$0 = \u54c1\u724c2;
    }

    public final Object invoke(Object object, Object object2) {
        return \u9ad8\u5730.\u8d4b\u80fd(this.f$0, (\u6fc0\u6d3b)object, (int)((Integer)object2));
    }
}

