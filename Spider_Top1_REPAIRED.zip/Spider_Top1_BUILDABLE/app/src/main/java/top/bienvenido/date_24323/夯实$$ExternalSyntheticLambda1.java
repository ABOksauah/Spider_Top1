/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u592f\u5b9e;

public final class \u592f\u5b9e$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ String f$0;

    public /* synthetic */ \u592f\u5b9e$$ExternalSyntheticLambda1(String string) {
        this.f$0 = string;
    }

    public final Object invoke(Object object) {
        return \u592f\u5b9e.\u8d4b\u80fd(this.f$0, (PackageManager)object);
    }
}

