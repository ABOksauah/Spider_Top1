/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  kotlin.Triple
 */
package top.bienvenido.date_24323;

import android.graphics.drawable.Drawable;
import kotlin.Triple;

public final class \u5185\u5377 {
    public final Triple \u6293\u624b;
    public final Drawable \u8d4b\u80fd;

    public \u5185\u5377(Drawable drawable2, Triple triple) {
        this.\u8d4b\u80fd = drawable2;
        this.\u6293\u624b = triple;
    }
}

