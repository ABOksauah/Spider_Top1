/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Debug
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u84dd\u6d77$
 *  top.bienvenido.date_24323.\u84dd\u6d77$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u84dd\u6d77$$ExternalSyntheticLambda1
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Debug;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u515c\u5e95;
import top.bienvenido.date_24323.\u6253\u78e8;
import top.bienvenido.date_24323.\u84dd\u6d77$;
import top.bienvenido.date_24323.\u8fb9\u754c;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u84dd\u6d77 {
    public static int \u8d4b\u80fd(String string2, boolean bl) {
        ApplicationInfo applicationInfo = bl ? \u8fb9\u754c.\u6293\u624b.\u6293\u624b(string2, 0) : (ApplicationInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda1(string2));
        if (applicationInfo != null) {
            return applicationInfo.uid;
        }
        return -1;
    }

    public static ActivityInfo \u8d4b\u80fd(Intent intent, String string2) {
        \u8fb9\u754c \u8fb9\u754c2 = \u8fb9\u754c.\u6293\u624b;
        \u8fb9\u754c2.getClass();
        ResolveInfo resolveInfo = \u8fb9\u754c.\u4e2d\u53f0.containsKey(string2) ? (ResolveInfo)CollectionsKt.firstOrNull((List)\u6253\u78e8.\u8d4b\u80fd(\u8fb9\u754c2.\u4e2d\u53f0(intent, null, 0))) : (ResolveInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(intent));
        if (resolveInfo != null) {
            return resolveInfo.activityInfo;
        }
        return null;
    }

    public static ActivityInfo \u8d4b\u80fd(String string2) {
        ActivityInfo activityInfo;
        Intent intent = new Intent("android.intent.action.MAIN").addCategory("android.intent.category.LAUNCHER").setPackage(string2);
        if (Debug.isDebuggerConnected()) {
            intent.setPackage("com.android.vending");
        }
        if ((activityInfo = \u84dd\u6d77.\u8d4b\u80fd(intent, string2)) == null) {
            intent.removeCategory("android.intent.category.LAUNCHER");
            return \u84dd\u6d77.\u8d4b\u80fd(intent.addCategory("android.intent.category.INFO"), string2);
        }
        return activityInfo;
    }

    public static final ApplicationInfo \u8d4b\u80fd(String string2, PackageManager packageManager) {
        return packageManager.getApplicationInfo(string2, 512);
    }

    public static final ResolveInfo \u8d4b\u80fd(Intent intent, PackageManager packageManager) {
        return packageManager.resolveActivity(intent, 0);
    }
}

