/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

public class \u81ea\u6d3d {
    public static final \u81ea\u6d3d \u8d4b\u80fd = new \u81ea\u6d3d();

    public Object \u8d4b\u80fd(Object object) {
        return null;
    }

    public /* varargs */ Object \u8d4b\u80fd(Object object, Object ... arrobject) {
        return null;
    }

    public void \u8d4b\u80fd(Object object, Object object2) {
    }
}

