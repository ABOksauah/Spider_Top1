/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.lang.Exception
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import top.bienvenido.date_24323.\u5f39\u7a97;

public final class \u5ef6\u671f
implements IBinder.DeathRecipient {
    public final /* synthetic */ \u5f39\u7a97 \u4e2d\u53f0;
    public final boolean \u6293\u624b;
    public final IBinder \u8d4b\u80fd;

    public \u5ef6\u671f(\u5f39\u7a97 \u5f39\u7a972, IBinder iBinder, boolean bl) {
        this.\u4e2d\u53f0 = \u5f39\u7a972;
        this.\u8d4b\u80fd = iBinder;
        this.\u6293\u624b = bl;
        try {
            iBinder.linkToDeath((IBinder.DeathRecipient)this, 0);
            return;
        }
        catch (Exception exception) {
            this.binderDied();
            return;
        }
    }

    public final void binderDied() {
        try {
            this.\u4e2d\u53f0.\u8d4b\u80fd(this.\u8d4b\u80fd);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }
}

