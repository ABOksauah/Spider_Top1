/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class \u6bd4\u5fc3 {
    public static Object \u8d4b\u80fd(Parcel parcel, Parcelable.Creator creator) {
        if (parcel.readInt() != 0) {
            return creator.createFromParcel(parcel);
        }
        return null;
    }

    public static void \u8d4b\u80fd(Parcel parcel, Parcelable parcelable, int n) {
        if (parcelable != null) {
            parcel.writeInt(1);
            parcelable.writeToParcel(parcel, n);
            return;
        }
        parcel.writeInt(0);
    }
}

