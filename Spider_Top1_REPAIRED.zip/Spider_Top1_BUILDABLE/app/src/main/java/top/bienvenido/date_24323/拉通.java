/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u62c9\u901a
extends \u89e6\u8fbe {
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            arrobject[1] = Boolean.TRUE;
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

