/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.HashMap
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4ea4\u4ed8$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u4ea4\u4ed8
extends \u89e6\u8fbe {
    public static final Map \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        Object object = arrobject[0];
        String string = object != null ? object.toString() : null;
        Object object2 = arrobject[1];
        String string2 = null;
        if (object2 != null) {
            string2 = object2.toString();
        }
        return \u589e\u957f2.\u54cd\u5e94(string, string2);
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Map map = (Map)\u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u4ea4\u4ed8$$ExternalSyntheticLambda0(arrobject));
        if (map == null) {
            map = new LinkedHashMap();
        }
        return map;
    }
}

