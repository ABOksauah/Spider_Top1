/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda8
implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ \u8fb9\u754c$$ExternalSyntheticLambda8(String string2, String string3) {
        this.f$0 = string2;
        this.f$1 = string3;
    }

    public final void run() {
        \u8fb9\u754c.\u5bf9\u9f50((String)this.f$0, (String)this.f$1);
    }
}

