/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.Parcel
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import android.os.IBinder;
import android.os.Parcel;
import top.bienvenido.date_24323.\u6fc0\u6d3b;

public final class \u52a9\u529b
implements \u6fc0\u6d3b {
    public final IBinder \u8d4b\u80fd;

    public \u52a9\u529b(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final void \u54cd\u5e94(String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(9, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final IBinder \u5bf9\u9f50(String string) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeString(string);
            this.\u8d4b\u80fd.transact(7, parcel, parcel2, 0);
            parcel2.readException();
            IBinder iBinder = parcel2.readStrongBinder();
            return iBinder;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u6293\u624b(IBinder iBinder, Intent intent) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeStrongBinder(iBinder);
            if (intent != null) {
                parcel.writeInt(1);
                intent.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            this.\u8d4b\u80fd.transact(3, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u6c89\u6dc0(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(5, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u6f0f\u6597() {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            this.\u8d4b\u80fd.transact(6, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(Intent intent, IBinder iBinder, String string) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            if (intent != null) {
                parcel.writeInt(1);
                intent.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            this.\u8d4b\u80fd.transact(8, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(IBinder iBinder, Intent intent) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeStrongBinder(iBinder);
            if (intent != null) {
                parcel.writeInt(1);
                intent.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            this.\u8d4b\u80fd.transact(2, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string, Intent intent, IBinder iBinder, int n) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeStrongBinder(iBinder);
            parcel.writeString(string);
            parcel.writeInt(n);
            if (intent != null) {
                parcel.writeInt(1);
                intent.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            this.\u8d4b\u80fd.transact(4, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(String string, String string2, String string3, boolean bl, String string4) {
        Parcel parcel = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoAppThread");
            parcel.writeString(string);
            parcel.writeString(string2);
            parcel.writeString(string3);
            parcel.writeInt((int)bl);
            parcel.writeString(string4);
            this.\u8d4b\u80fd.transact(1, parcel, null, 1);
            return;
        }
        finally {
            parcel.recycle();
        }
    }
}

