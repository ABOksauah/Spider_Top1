/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 */
package top.bienvenido.date_24323;

public abstract class \u8bb2\u6545\u4e8b {
    public static int[] \u8d4b\u80fd(int[] arrn, int n, int n2, int n3) {
        if (n + 1 <= arrn.length) {
            System.arraycopy((Object)arrn, (int)n2, (Object)arrn, (int)(n2 + 1), (int)(n - n2));
            arrn[n2] = n3;
            return arrn;
        }
        int[] arrn2 = new int[(n | 1) << 1];
        System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)n2);
        arrn2[n2] = n3;
        System.arraycopy((Object)arrn, (int)n2, (Object)arrn2, (int)(n2 + 1), (int)(arrn.length - n2));
        return arrn2;
    }
}

