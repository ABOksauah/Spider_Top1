/*
 * Decompiled with CFR 0.0.
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u516c\u57df;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u6bcd\u4f53
extends \u96c6\u6210 {
    public static final \u6bcd\u4f53 \u6293\u624b = new \u6bcd\u4f53();

    @Override
    public final void \u8d4b\u80fd() {
        \u516c\u57df \u516c\u57df2 = \u672c\u6211.\u54cd\u5e94;
        this.\u8d4b\u80fd = \u516c\u57df2;
        \u6d1e\u81ea\u8eab.\u8d4b\u80fd("power", \u516c\u57df2, null);
    }
}

