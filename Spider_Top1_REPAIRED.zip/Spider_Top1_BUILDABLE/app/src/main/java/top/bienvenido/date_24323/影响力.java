/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.UserInfo
 *  android.os.PersistableBundle
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.collections.CollectionsKt
 */
package top.bienvenido.date_24323;

import android.content.pm.UserInfo;
import android.os.PersistableBundle;
import kotlin.collections.CollectionsKt;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u5f71\u54cd\u529b
extends \u96c6\u6210 {
    public static final \u5f71\u54cd\u529b \u6293\u624b = new \u5f71\u54cd\u529b();

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        \u51fa\u51fb \u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("user", \u89e6\u53d12, null);
        if (\u51fa\u51fb2 == null) {
            return;
        }
        \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df("user");
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1811233388, \u79c1\u57df2);
        UserInfo userInfo = \u62bd\u8c61.\u7ed9\u5230 ? new UserInfo(0, "user", null, 16387, "android.os.usertype.profile.MANAGED") : new UserInfo(0, "user", null, 16387);
        \u79c1\u57df \u79c1\u57df3 = new \u79c1\u57df((Object)CollectionsKt.arrayListOf((Object[])new UserInfo[]{userInfo}));
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1967404114, \u79c1\u57df3);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{2016450557, 1811096719}, new \u79c1\u57df((Object)userInfo));
        \u79c1\u57df \u79c1\u57df4 = \u672c\u6211.\u95ed\u73af;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(223144277, \u79c1\u57df4);
        if (\u62bd\u8c61.\u4e2d\u53f0) {
            \u79c1\u57df \u79c1\u57df5 = new \u79c1\u57df((Object)PersistableBundle.EMPTY);
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-255616392, \u79c1\u57df5);
        }
    }
}

