/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda17
implements Function1 {
    public final Object invoke(Object object) {
        return \u516c\u5173.\u5bf9\u6807((IBinder)object);
    }
}

