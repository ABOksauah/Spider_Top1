/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u51b7\u542f\u52a8;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u6269\u5c55 {
    public static final \u6269\u5c55 \u8d4b\u80fd = new \u6269\u5c55();

    public static void \u8d4b\u80fd(ComponentInfo[] arrcomponentInfo, ApplicationInfo applicationInfo) {
        if (arrcomponentInfo != null) {
            int n = arrcomponentInfo.length;
            for (int i = 0; i < n; ++i) {
                arrcomponentInfo[i].applicationInfo = applicationInfo;
            }
        }
    }

    public static boolean \u8d4b\u80fd(ApplicationInfo applicationInfo) {
        try {
            if (Intrinsics.areEqual((Object)applicationInfo.packageName, (Object)\u6c34\u4f4d.\u6293\u624b)) {
                String string2;
                applicationInfo.packageName = \u6c34\u4f4d.\u6293\u624b;
                applicationInfo.uid = \u98ce\u53e3.\u4e2d\u53f0;
                applicationInfo.enabled = true;
                applicationInfo.dataDir = string2 = \u6c34\u4f4d.\u843d\u5730;
                if (\u62bd\u8c61.\u4e2d\u53f0) {
                    applicationInfo.deviceProtectedDataDir = string2;
                    \u51b7\u542f\u52a8.\u7ed9\u5230.\u8d4b\u80fd((Object)applicationInfo, (Object)string2);
                }
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }
}

