/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Future
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import java.util.concurrent.Future;
import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ Future[] f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda4(Future[] arrfuture) {
        this.f$0 = arrfuture;
    }

    public final void run() {
        \u6bb5\u4f4d.\u8d4b\u80fd((Future[])this.f$0);
    }
}

