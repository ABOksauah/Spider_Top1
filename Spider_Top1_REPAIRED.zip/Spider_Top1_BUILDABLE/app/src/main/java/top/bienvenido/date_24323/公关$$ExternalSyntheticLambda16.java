/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  top.bienvenido.date_24323.\u516c\u5173
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda16
implements Runnable {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda16(Intent intent, String string2) {
        this.f$0 = intent;
        this.f$1 = string2;
    }

    public final void run() {
        \u516c\u5173.\u6f0f\u6597((Intent)this.f$0, (String)this.f$1);
    }
}

