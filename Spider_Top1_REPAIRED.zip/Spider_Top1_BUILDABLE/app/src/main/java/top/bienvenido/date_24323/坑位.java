/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.IOnChecksumsReadyListener
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.IOnChecksumsReadyListener;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u5751\u4f4d$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5751\u4f4d
extends \u89e6\u53d1 {
    public static final boolean \u8d4b\u80fd(String string, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u95ed\u73af(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            Object object2 = arrobject[0];
            String string = object2 != null ? object2.toString() : null;
            if (string == null) return super.\u8d4b\u80fd(object, method, arrobject);
            {
                Boolean bl = (Boolean)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u5751\u4f4d$$ExternalSyntheticLambda0(string));
                boolean bl2 = false;
                if (bl != null) {
                    bl2 = bl;
                }
                if (!bl2) return super.\u8d4b\u80fd(object, method, arrobject);
                {
                    IOnChecksumsReadyListener iOnChecksumsReadyListener = (IOnChecksumsReadyListener)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, IOnChecksumsReadyListener.class);
                    if (iOnChecksumsReadyListener == null) return null;
                    {
                        iOnChecksumsReadyListener.onChecksumsReady(Collections.EMPTY_LIST);
                    }
                    return null;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

