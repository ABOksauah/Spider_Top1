/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PropertyInvalidatedCache
 *  android.bluetooth.BluetoothAdapter
 *  android.os.IpcDataCache
 *  android.os.IpcDataCache$QueryHandler
 *  java.lang.Integer
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

import android.app.PropertyInvalidatedCache;
import android.bluetooth.BluetoothAdapter;
import android.os.IpcDataCache;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u96c6\u6210;
import top.bienvenido.mundo.common.ext.ExtQueryHandler;

public final class \u590d\u7528
extends \u96c6\u6210 {
    public static final \u590d\u7528 \u6293\u624b = new \u590d\u7528();

    @Override
    public final void \u8d4b\u80fd() {
        IpcDataCache ipcDataCache = (IpcDataCache)\u771f\u9999.\u4e2d\u53f0(BluetoothAdapter.class, "sGetProfileConnectionStateCache");
        if (ipcDataCache == null) {
            return;
        }
        IpcDataCache.QueryHandler queryHandler = (IpcDataCache.QueryHandler)\u771f\u9999.\u4e2d\u53f0(BluetoothAdapter.class, "sBluetoothProfileQuery");
        if (queryHandler == null) {
            return;
        }
        \u771f\u9999.\u8d4b\u80fd(PropertyInvalidatedCache.class, "mComputer").\u8d4b\u80fd((Object)ipcDataCache, (Object)new ExtQueryHandler((IpcDataCache.QueryHandler<Object, Integer>)queryHandler));
        ipcDataCache.clear();
    }
}

