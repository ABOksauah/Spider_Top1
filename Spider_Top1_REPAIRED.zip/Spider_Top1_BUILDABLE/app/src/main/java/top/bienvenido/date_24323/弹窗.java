/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.IBinder;
import java.util.ArrayList;
import java.util.List;
import top.bienvenido.date_24323.\u5ef6\u671f;
import top.bienvenido.date_24323.\u6392\u671f;

public final class \u5f39\u7a97 {
    public final ArrayList \u4e2d\u53f0 = new ArrayList();
    public final ArrayList \u6293\u624b = new ArrayList();
    public final String \u8d4b\u80fd;

    public \u5f39\u7a97(String string2) {
        this.\u8d4b\u80fd = string2;
    }

    public final void \u8d4b\u80fd(Uri uri, int n, IBinder iBinder, boolean bl) {
        int n2 = 0;
        int n3 = uri == null ? 0 : 1 + uri.getPathSegments().size();
        if (n == n3) {
            this.\u4e2d\u53f0.add((Object)new \u5ef6\u671f(this, iBinder, bl));
            return;
        }
        String string2 = uri != null ? (n == 0 ? uri.getAuthority() : (String)uri.getPathSegments().get(n - 1)) : null;
        int n4 = this.\u6293\u624b.size();
        while (n2 < n4) {
            \u5f39\u7a97 \u5f39\u7a972 = (\u5f39\u7a97)this.\u6293\u624b.get(n2);
            if (\u5f39\u7a972.\u8d4b\u80fd.equals((Object)string2)) {
                \u5f39\u7a972.\u8d4b\u80fd(uri, n + 1, iBinder, bl);
                return;
            }
            ++n2;
        }
        \u5f39\u7a97 \u5f39\u7a973 = new \u5f39\u7a97(string2);
        this.\u6293\u624b.add((Object)\u5f39\u7a973);
        \u5f39\u7a973.\u8d4b\u80fd(uri, n + 1, iBinder, bl);
    }

    public final void \u8d4b\u80fd(Uri uri, int n, IBinder iBinder, boolean bl, ArrayList arrayList) {
        String string2;
        int n2 = uri == null ? 0 : 1 + uri.getPathSegments().size();
        String string3 = null;
        if (n >= n2) {
            this.\u8d4b\u80fd(true, iBinder, bl, arrayList);
            string2 = null;
        } else {
            if (uri != null) {
                string3 = n == 0 ? uri.getAuthority() : (String)uri.getPathSegments().get(n - 1);
            }
            this.\u8d4b\u80fd(false, iBinder, bl, arrayList);
            string2 = string3;
        }
        int n3 = this.\u6293\u624b.size();
        for (int i = 0; i < n3; ++i) {
            \u5f39\u7a97 \u5f39\u7a972 = (\u5f39\u7a97)this.\u6293\u624b.get(i);
            if (string2 != null && !\u5f39\u7a972.\u8d4b\u80fd.equals((Object)string2)) continue;
            \u5f39\u7a972.\u8d4b\u80fd(uri, n + 1, iBinder, bl, arrayList);
            if (string2 == null) continue;
            return;
        }
    }

    public final void \u8d4b\u80fd(boolean bl, IBinder iBinder, boolean bl2, ArrayList arrayList) {
        int n = this.\u4e2d\u53f0.size();
        for (int i = 0; i < n; ++i) {
            \u5ef6\u671f \u5ef6\u671f2 = (\u5ef6\u671f)this.\u4e2d\u53f0.get(i);
            IBinder iBinder2 = \u5ef6\u671f2.\u8d4b\u80fd;
            if (iBinder2 == iBinder && !bl2 || !bl && !\u5ef6\u671f2.\u6293\u624b) continue;
            arrayList.add((Object)new \u6392\u671f(this, iBinder2, bl2));
        }
    }

    public final boolean \u8d4b\u80fd(IBinder iBinder) {
        int n = this.\u6293\u624b.size();
        for (int i = 0; i < n; ++i) {
            if (!((\u5f39\u7a97)this.\u6293\u624b.get(i)).\u8d4b\u80fd(iBinder)) continue;
            this.\u6293\u624b.remove(i);
            --i;
            --n;
        }
        int n2 = this.\u4e2d\u53f0.size();
        for (int i = 0; i < n2; ++i) {
            \u5ef6\u671f \u5ef6\u671f2 = (\u5ef6\u671f)this.\u4e2d\u53f0.get(i);
            if (\u5ef6\u671f2.\u8d4b\u80fd != iBinder) continue;
            this.\u4e2d\u53f0.remove(i);
            iBinder.unlinkToDeath((IBinder.DeathRecipient)\u5ef6\u671f2, 0);
            break;
        }
        return this.\u6293\u624b.isEmpty() && this.\u4e2d\u53f0.isEmpty();
    }
}

