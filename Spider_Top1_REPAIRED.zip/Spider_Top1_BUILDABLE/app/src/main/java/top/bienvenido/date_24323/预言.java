/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.AuthenticatorDescription
 *  android.content.pm.ServiceInfo
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.AuthenticatorDescription;
import android.content.pm.ServiceInfo;

public final class \u9884\u8a00
extends AuthenticatorDescription {
    public final ServiceInfo \u8d4b\u80fd;

    public \u9884\u8a00(String string2, String string3, int n, int n2, int n3, int n4, boolean bl, ServiceInfo serviceInfo) {
        super(string2, string3, n, n2, n3, n4, bl);
        this.\u8d4b\u80fd = serviceInfo;
    }
}

