/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 */
package top.bienvenido.mundo.common.initialize;

import java.io.Serializable;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;

@Metadata(d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0005\b\u00c6\u0002\u0018\u00002\u00020\u0001J$\u0010\u0005\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0003\u001a\u00020\u00022\b\u0010\u0004\u001a\u0004\u0018\u00010\u0001H\u0087 \u00a2\u0006\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2={"Ltop/bienvenido/mundo/common/initialize/MNative;", "", "", "code", "obj", "ioctl", "(ILjava/lang/Object;)Ljava/lang/Object;", "mundo"}, k=1, mv={2, 2, 0}, xi=48)
public final class MNative {
    public static final /* synthetic */ int \u8d4b\u80fd;

    static {
        try {
            System.loadLibrary((String)"w9e76gns");
        }
        catch (Throwable throwable) {}
    }

    @JvmStatic
    public static final native Object ioctl(int var0, Object var1);

    public static Object \u8d4b\u80fd(int n, Serializable serializable) {
        try {
            Object object = MNative.ioctl(n, (Object)serializable);
            return object;
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}

