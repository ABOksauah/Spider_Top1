/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u6bb5\u4f4d;

public final class \u6bb5\u4f4d$$ExternalSyntheticLambda7
implements Runnable {
    public final /* synthetic */ \u6bb5\u4f4d f$0;

    public /* synthetic */ \u6bb5\u4f4d$$ExternalSyntheticLambda7(\u6bb5\u4f4d \u6bb5\u4f4d2) {
        this.f$0 = \u6bb5\u4f4d2;
    }

    public final void run() {
        this.f$0.\u5e73\u53f0();
    }
}

