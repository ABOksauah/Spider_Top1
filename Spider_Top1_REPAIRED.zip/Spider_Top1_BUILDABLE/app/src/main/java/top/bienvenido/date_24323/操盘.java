/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import top.bienvenido.date_24323.\u5524\u9192;
import top.bienvenido.date_24323.\u5934\u90e8;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6d41\u5931;
import top.bienvenido.date_24323.\u6df1\u5165;
import top.bienvenido.date_24323.\u8ba4\u8bc1;
import top.bienvenido.date_24323.\u8fd4\u4f63;

public final class \u64cd\u76d8
extends \u5934\u90e8 {
    public final PackageInfo \u4e2d\u53f0;
    public final \u6df1\u5165 \u6c89\u6dc0 = new \u6df1\u5165(this);
    public \u8fd4\u4f63 \u6f0f\u6597 = \u8fd4\u4f63.\u6293\u624b;
    public \u6d41\u5931 \u843d\u5730 = \u5524\u9192.\u8d4b\u80fd;
    public ApplicationInfo \u95ed\u73af;

    public \u64cd\u76d8(PackageInfo packageInfo, ApplicationInfo applicationInfo) {
        super(packageInfo.packageName, new \u5dee\u5f02\u5316());
        this.\u4e2d\u53f0 = packageInfo;
        this.\u95ed\u73af = applicationInfo;
    }

    public \u64cd\u76d8(PackageInfo packageInfo, ApplicationInfo applicationInfo, \u5dee\u5f02\u5316 \u5dee\u5f02\u53162) {
        super(packageInfo.packageName, \u5dee\u5f02\u53162);
        this.\u4e2d\u53f0 = packageInfo;
        this.\u95ed\u73af = applicationInfo;
    }
}

