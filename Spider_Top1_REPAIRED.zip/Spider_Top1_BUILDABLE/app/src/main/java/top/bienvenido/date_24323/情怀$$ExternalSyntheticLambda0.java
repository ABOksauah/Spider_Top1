/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u60c5\u6000;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u60c5\u6000$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;

    public /* synthetic */ \u60c5\u6000$$ExternalSyntheticLambda0(Object[] arrobject) {
        this.f$0 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u60c5\u6000.\u8d4b\u80fd(this.f$0, (\u94f8\u9020)object);
    }
}

