/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import top.bienvenido.date_24323.\u611f\u77e5\u5ea6;
import top.bienvenido.date_24323.\u65b9\u6cd5\u8bba;
import top.bienvenido.date_24323.\u7ec4\u5408\u62f3;

public final class \u5f15\u7206\u70b9 {
    public final \u65b9\u6cd5\u8bba \u8d4b\u80fd = new \u65b9\u6cd5\u8bba();

    public final \u7ec4\u5408\u62f3 \u8d4b\u80fd(Account account, String string2) {
        \u611f\u77e5\u5ea6 \u611f\u77e5\u5ea62 = new \u611f\u77e5\u5ea6(account, string2);
        \u7ec4\u5408\u62f3 \u7ec4\u5408\u62f32 = (\u7ec4\u5408\u62f3)this.\u8d4b\u80fd.get((Object)\u611f\u77e5\u5ea62);
        long l = System.currentTimeMillis();
        if (\u7ec4\u5408\u62f32 != null && l < \u7ec4\u5408\u62f32.\u6293\u624b) {
            return \u7ec4\u5408\u62f32;
        }
        if (\u7ec4\u5408\u62f32 != null) {
            String string3 = account.type;
            String string4 = \u7ec4\u5408\u62f32.\u8d4b\u80fd;
            this.\u8d4b\u80fd.\u8d4b\u80fd(string3, string4);
        }
        return null;
    }
}

