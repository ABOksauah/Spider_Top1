/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;

public class \u89e6\u8fbe {
    public static Object \u8d4b\u80fd(Object[] arrobject, Class class_) {
        for (Object object : arrobject) {
            if (!class_.isInstance(object)) continue;
            return object;
        }
        return null;
    }

    public static void \u8d4b\u80fd(Object[] arrobject, int n) {
        try {
            Object object = arrobject[n];
            if (object instanceof Integer) {
                arrobject[n] = 512 | ((Number)object).intValue();
                return;
            }
            if (object instanceof Long) {
                arrobject[n] = 512L | ((Number)object).longValue();
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return method.invoke(object, arrobject);
    }
}

