/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.IntentFilter
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 */
package top.bienvenido.date_24323;

import android.content.IntentFilter;
import android.os.IBinder;
import java.util.ArrayList;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5c01\u88c5;

public final class \u5bf9\u4e00\u4e0b
extends ArrayList {
    public final \u54c1\u724c \u6293\u624b;
    public final IBinder \u8d4b\u80fd;

    public \u5bf9\u4e00\u4e0b(IBinder iBinder, \u54c1\u724c \u54c1\u724c2) {
        this.\u8d4b\u80fd = iBinder;
        this.\u6293\u624b = \u54c1\u724c2;
    }

    public final boolean equals(Object object) {
        return this == object;
    }

    public final int hashCode() {
        return System.identityHashCode((Object)((Object)this));
    }

    public final boolean \u8d4b\u80fd(IntentFilter intentFilter) {
        int n = super.size();
        block0 : for (int i = 0; i < n; ++i) {
            int n2;
            IntentFilter intentFilter2 = (IntentFilter)this.get(i);
            int n3 = intentFilter2.countActions();
            if (n3 != intentFilter.countActions()) continue;
            for (int j = 0; j < n3; ++j) {
                if (!intentFilter.hasAction(intentFilter2.getAction(j))) continue block0;
            }
            int n4 = intentFilter2.countCategories();
            if (n4 != intentFilter.countCategories()) continue;
            for (int j = 0; j < n4; ++j) {
                if (!intentFilter.hasCategory(intentFilter2.getCategory(j))) continue block0;
            }
            if (intentFilter2.countDataTypes() != intentFilter.countDataTypes() || (n2 = intentFilter2.countDataSchemes()) != intentFilter.countDataSchemes()) continue;
            for (int j = 0; j < n2; ++j) {
                if (!intentFilter.hasDataScheme(intentFilter2.getDataScheme(j))) continue block0;
            }
            if (intentFilter2.countDataAuthorities() != intentFilter.countDataAuthorities() || intentFilter2.countDataPaths() != intentFilter.countDataPaths() || intentFilter2.countDataSchemeSpecificParts() != intentFilter.countDataSchemeSpecificParts()) continue;
            return true;
        }
        return false;
    }
}

