/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.IActivityManager
 *  android.content.pm.UserInfo
 *  android.util.Singleton
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  top.bienvenido.date_24323.\u5bfc\u6d41
 *  top.bienvenido.date_24323.\u5f15\u7206
 *  top.bienvenido.date_24323.\u6253\u5e73
 *  top.bienvenido.date_24323.\u6253\u901a
 *  top.bienvenido.date_24323.\u62b9\u5e73
 *  top.bienvenido.date_24323.\u6316\u6398
 *  top.bienvenido.date_24323.\u6a21\u578b
 *  top.bienvenido.date_24323.\u7ec6\u5206
 *  top.bienvenido.date_24323.\u80cc\u4e66
 *  top.bienvenido.date_24323.\u84c4\u80fd
 *  top.bienvenido.date_24323.\u91cd\u5851
 *  top.bienvenido.date_24323.\u91cd\u7ec4
 *  top.bienvenido.date_24323.\u91cf\u5316
 */
package top.bienvenido.date_24323;

import android.app.IActivityManager;
import android.content.pm.UserInfo;
import android.util.Singleton;
import java.lang.reflect.Constructor;
import top.bienvenido.date_24323.\u5171\u521b;
import top.bienvenido.date_24323.\u517c\u5bb9;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u53d1\u529b;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u5bfc\u6d41;
import top.bienvenido.date_24323.\u5f15\u7206;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6253\u5e73;
import top.bienvenido.date_24323.\u6253\u901a;
import top.bienvenido.date_24323.\u62b9\u5e73;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u62c9\u5347;
import top.bienvenido.date_24323.\u62c9\u901a;
import top.bienvenido.date_24323.\u6316\u6398;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6a21\u578b;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7ec6\u5206;
import top.bienvenido.date_24323.\u8054\u52a8;
import top.bienvenido.date_24323.\u80cc\u4e66;
import top.bienvenido.date_24323.\u80cc\u9505;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u84c4\u80fd;
import top.bienvenido.date_24323.\u878d\u5408;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8c03\u6027;
import top.bienvenido.date_24323.\u8d70\u51fa\u53bb;
import top.bienvenido.date_24323.\u8f90\u5c04;
import top.bienvenido.date_24323.\u8fc1\u79fb;
import top.bienvenido.date_24323.\u900f\u4f20;
import top.bienvenido.date_24323.\u91cd\u5851;
import top.bienvenido.date_24323.\u91cd\u7ec4;
import top.bienvenido.date_24323.\u91cf\u5316;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u652f\u6301
extends \u96c6\u6210 {
    public static final \u652f\u6301 \u6293\u624b = new \u652f\u6301();

    @Override
    public final void \u8d4b\u80fd() {
        UserInfo userInfo;
        boolean bl;
        this.\u8d4b\u80fd = \u672c\u6211.\u6293\u624b;
        Singleton singleton = \u8c03\u6027.\u8d4b\u80fd;
        \u51fa\u51fb \u51fa\u51fb2 = this.\u8d4b\u80fd("activity", (Object)((IActivityManager)singleton.get()));
        if (\u51fa\u51fb2 == null) {
            return;
        }
        Object object = \u51fa\u51fb2.\u95ed\u73af;
        \u8d70\u51fa\u53bb.\u8d4b\u80fd.\u8d4b\u80fd((Object)singleton, object);
        \u5bfc\u6d41 \u5bfc\u6d412 = \u5bfc\u6d41.\u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(972810068, (Object)\u5bfc\u6d412);
        \u6a21\u578b.\u6293\u624b.\u8d4b\u80fd(\u51fa\u51fb2);
        \u517c\u5bb9 \u517c\u5bb92 = new \u517c\u5bb9();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(343899992, \u517c\u5bb92);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{1342909549, 1418030008, -379822753}, (\u89e6\u8fbe)new \u91cf\u5316());
        \u7ec6\u5206 \u7ec6\u52062 = new \u7ec6\u5206();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1849706483, (Object)\u7ec6\u52062);
        \u91cd\u5851 \u91cd\u58512 = new \u91cd\u5851();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(699379795, (Object)\u91cd\u58512);
        \u84c4\u80fd \u84c4\u80fd2 = new \u84c4\u80fd();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1930712422, (Object)\u84c4\u80fd2);
        \u5f15\u7206 \u5f15\u72062 = new \u5f15\u7206();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1531153537, (Object)\u5f15\u72062);
        \u6316\u6398 \u6316\u63982 = new \u6316\u6398();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1218560218, (Object)\u6316\u63982);
        \u80cc\u4e66 \u80cc\u4e662 = new \u80cc\u4e66();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(39551382, (Object)\u80cc\u4e662);
        \u80cc\u9505 \u80cc\u95052 = new \u80cc\u9505();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1743087205, \u80cc\u95052);
        try {
            Class class_ = Integer.TYPE;
            Class[] arrclass = new Class[]{class_, String.class, class_};
            Constructor constructor = UserInfo.class.getDeclaredConstructor(arrclass);
            constructor.setAccessible(true);
            userInfo = (UserInfo)constructor.newInstance(new Object[]{0, "Admin", 1});
        }
        catch (Exception exception) {
            userInfo = null;
        }
        \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df((Object)userInfo);
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-38994002, \u79c1\u57df2);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{686218487, -409205432}, \u8fc1\u79fb.\u8d4b\u80fd);
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{1155315389, -1433640877}, (\u89e6\u8fbe)new \u6253\u901a());
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-1039717966, -1479937474}, (\u89e6\u8fbe)new \u6253\u5e73());
        \u62b9\u5e73 \u62b9\u5e732 = new \u62b9\u5e73();
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1102112331, (Object)\u62b9\u5e732);
        \u91cd\u7ec4 \u91cd\u7ec42 = \u91cd\u7ec4.\u6293\u624b;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-506172825, (Object)\u91cd\u7ec42);
        boolean bl2 = \u62bd\u8c61.\u6c89\u6dc0;
        if (bl2) {
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1576113007, (Object)\u91cd\u7ec42);
        }
        if (bl = \u62bd\u8c61.\u7ed9\u5230) {
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1875811945, (Object)\u91cd\u7ec42);
        }
        if (\u62bd\u8c61.\u5bf9\u9f50) {
            \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1554828183, \u89e6\u53d12);
        } else {
            \u89e6\u53d1 \u89e6\u53d13 = \u672c\u6211.\u4e2d\u53f0;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-18665309, \u89e6\u53d13);
        }
        \u79c1\u57df \u79c1\u57df3 = \u672c\u6211.\u95ed\u73af;
        \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-135772109, \u79c1\u57df3);
        if (bl2) {
            \u89e6\u53d1 \u89e6\u53d14 = \u672c\u6211.\u4e2d\u53f0;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-633679821, \u89e6\u53d14);
            if (bl) {
                \u51fa\u51fb2.\u8d4b\u80fd(new int[]{-546387422, 131012258}, \u89e6\u53d14);
                if (\u62bd\u8c61.\u5e73\u53f0) {
                    \u53d1\u529b \u53d1\u529b2 = new \u53d1\u529b();
                    \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(86032032, \u53d1\u529b2);
                }
            }
        } else {
            \u5171\u521b \u5171\u521b2 = new \u5171\u521b();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(463520714, \u5171\u521b2);
            \u878d\u5408 \u878d\u54082 = new \u878d\u5408();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1293072352, \u878d\u54082);
            \u8054\u52a8 \u8054\u52a82 = \u900f\u4f20.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1666360360, \u8054\u52a82);
            \u534f\u540c \u534f\u540c2 = \u900f\u4f20.\u6293\u624b;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1770569149, \u534f\u540c2);
            \u62c9\u901a \u62c9\u901a2 = new \u62c9\u901a();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1349683719, \u62c9\u901a2);
            \u62c9\u5347 \u62c9\u53472 = new \u62c9\u5347();
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(1985825802, \u62c9\u53472);
            \u8f90\u5c04 \u8f90\u5c042 = \u8f90\u5c04.\u8d4b\u80fd;
            \u51fa\u51fb2.\u8d4b\u80fd.\u8d4b\u80fd(-1059947677, \u8f90\u5c042);
        }
        \u51fa\u51fb2.\u8d4b\u80fd(new int[]{2009377951, -745473163}, \u672c\u6211.\u4e2d\u53f0);
    }
}

