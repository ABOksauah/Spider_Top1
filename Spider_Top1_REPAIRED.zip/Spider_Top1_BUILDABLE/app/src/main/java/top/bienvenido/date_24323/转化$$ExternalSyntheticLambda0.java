/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import java.io.File;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u8f6c\u5316;

public final class \u8f6c\u5316$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u8f6c\u5316.\u95ed\u73af((File)object);
    }
}

