/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.ParceledListSlice
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ParceledListSlice;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u60c5\u6000$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u62c9\u65b0;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u60c5\u6000
extends \u89e6\u8fbe {
    public static final List \u8d4b\u80fd(Object[] arrobject, \u94f8\u9020 \u94f8\u90202) {
        Object object = arrobject[0];
        String string = object != null ? object.toString() : null;
        Object object2 = arrobject[3];
        String string2 = null;
        if (object2 != null) {
            string2 = object2.toString();
        }
        return \u94f8\u90202.\u5e73\u53f0(string, string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            List list;
            List list2 = (List)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd(new \u60c5\u6000$$ExternalSyntheticLambda0(arrobject));
            if (list2 == null) {
                list2 = Collections.EMPTY_LIST;
            }
            if ((list = \u660e\u786e.\u8d4b\u80fd(method.invoke(object, arrobject))) == null) {
                list = Collections.EMPTY_LIST;
            }
            List list3 = CollectionsKt.plus((Collection)list2, (Iterable)list);
            Iterator iterator = list3.iterator();
            while (iterator.hasNext()) {
                \u6269\u5c55.\u8d4b\u80fd(((ComponentInfo)iterator.next()).applicationInfo);
            }
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return list3;
            return \u660e\u786e.\u8d4b\u80fd(list3);
        }
        catch (Exception exception) {
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return Collections.EMPTY_LIST;
            return \u62c9\u65b0.\u8d4b\u80fd;
        }
    }
}

