/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u8ba4\u77e5;

public final class \u8ba4\u77e5$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ \u8ba4\u77e5$$ExternalSyntheticLambda0(Intent intent, String string) {
        this.f$0 = intent;
        this.f$1 = string;
    }

    public final Object invoke(Object object) {
        return \u8ba4\u77e5.\u8d4b\u80fd(this.f$0, this.f$1, (\u5e03\u5c40)object);
    }
}

