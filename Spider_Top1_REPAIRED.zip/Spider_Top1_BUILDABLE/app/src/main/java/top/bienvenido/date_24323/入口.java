/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Map
 *  kotlin.collections.MapsKt
 */
package top.bienvenido.date_24323;

import java.util.ArrayList;
import java.util.Map;
import kotlin.collections.MapsKt;
import top.bienvenido.date_24323.\u5f15\u7206\u70b9;

public final class \u5165\u53e3 {
    public final \u5f15\u7206\u70b9 \u4e2d\u53f0 = new \u5f15\u7206\u70b9();
    public Map \u6293\u624b = MapsKt.emptyMap();
    public ArrayList \u8d4b\u80fd = new ArrayList();
}

