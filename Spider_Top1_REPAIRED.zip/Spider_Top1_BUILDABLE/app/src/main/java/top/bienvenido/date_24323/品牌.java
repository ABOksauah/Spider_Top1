/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.ConditionVariable
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.os.ConditionVariable;
import top.bienvenido.date_24323.\u5dee\u5f02\u5316;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6fc0\u6d3b;

public final class \u54c1\u724c {
    public final String \u4e2d\u53f0;
    public final \u5dee\u5f02\u5316 \u540c\u6b65;
    public final ConditionVariable \u54cd\u5e94;
    public final \u5dee\u5f02\u5316 \u5bf9\u6807;
    public final \u6241\u5e73\u5316 \u5bf9\u9f50;
    public int \u5e73\u53f0;
    public final String \u6293\u624b;
    public boolean \u6c89\u6dc0;
    public final int \u6f0f\u6597;
    public \u6fc0\u6d3b \u7ed9\u5230;
    public final int \u843d\u5730;
    public final String \u8d4b\u80fd;
    public final \u5dee\u5f02\u5316 \u8fed\u4ee3;
    public final boolean \u95ed\u73af;

    public \u54c1\u724c(String string2, String string3, String string4, boolean bl, int n, int n2) {
        this.\u8d4b\u80fd = string2;
        this.\u6293\u624b = string3;
        this.\u4e2d\u53f0 = string4;
        this.\u95ed\u73af = bl;
        this.\u843d\u5730 = n;
        this.\u6f0f\u6597 = n2;
        this.\u6c89\u6dc0 = true;
        this.\u54cd\u5e94 = new ConditionVariable();
        this.\u540c\u6b65 = new \u5dee\u5f02\u5316();
        this.\u5bf9\u9f50 = new \u6241\u5e73\u5316(0);
        this.\u5bf9\u6807 = new \u5dee\u5f02\u5316();
        this.\u8fed\u4ee3 = new \u5dee\u5f02\u5316();
    }
}

