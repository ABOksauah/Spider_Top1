/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.reflect.Array
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.List
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62c9\u65b0;

public class \u89e6\u53d1
extends \u53d8\u8fc1 {
    public static final \u6241\u5e73\u5316 \u8d4b\u80fd;

    static {
        Pair pair = TuplesKt.to((Object)String.class.hashCode(), (Object)"0");
        Pair pair2 = TuplesKt.to((Object)Long.TYPE.hashCode(), (Object)0L);
        Integer n = Short.TYPE.hashCode();
        Pair pair3 = TuplesKt.to((Object)n, (Object)0);
        Pair pair4 = TuplesKt.to((Object)Float.TYPE.hashCode(), (Object)Float.valueOf((float)0.0f));
        Pair pair5 = TuplesKt.to((Object)Character.TYPE.hashCode(), (Object)Character.valueOf((char)'0'));
        Pair pair6 = TuplesKt.to((Object)Byte.TYPE.hashCode(), (Object)0);
        Pair pair7 = TuplesKt.to((Object)Integer.TYPE.hashCode(), (Object)0);
        Pair pair8 = TuplesKt.to((Object)Double.TYPE.hashCode(), (Object)0.0);
        Pair pair9 = TuplesKt.to((Object)Boolean.TYPE.hashCode(), (Object)Boolean.FALSE);
        Pair pair10 = TuplesKt.to((Object)List.class.hashCode(), (Object)Collections.EMPTY_LIST);
        Integer n2 = ParceledListSlice.class.hashCode();
        Pair[] arrpair = new Pair[]{pair, pair2, pair3, pair4, pair5, pair6, pair7, pair8, pair9, pair10, TuplesKt.to((Object)n2, (Object)\u62c9\u65b0.\u8d4b\u80fd)};
        \u6241\u5e73\u5316 \u6241\u5e73\u53162 = new \u6241\u5e73\u5316(11);
        for (int i = 0; i < 11; ++i) {
            Pair pair11 = arrpair[i];
            \u6241\u5e73\u53162.\u8d4b\u80fd(((Number)pair11.getFirst()).intValue(), pair11.getSecond());
        }
        \u8d4b\u80fd = \u6241\u5e73\u53162;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        try {
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            Class class_ = method.getReturnType();
            if (Intrinsics.areEqual((Object)class_, (Object)Void.TYPE)) return null;
            Object object2 = \u8d4b\u80fd.\u8d4b\u80fd(class_.hashCode());
            if (object2 != null) return object2;
            Class class_2 = class_.getComponentType();
            if (class_2 == null) return null;
            return Array.newInstance((Class)class_2, (int)0);
        }
    }
}

