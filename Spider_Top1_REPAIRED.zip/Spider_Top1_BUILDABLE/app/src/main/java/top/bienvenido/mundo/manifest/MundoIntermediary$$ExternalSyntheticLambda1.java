/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.util.ArrayList
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.mundo.manifest;

import android.content.Intent;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.mundo.manifest.MundoIntermediary;

public final class MundoIntermediary$$ExternalSyntheticLambda1
implements Function1 {
    public final /* synthetic */ Intent f$0;
    public final /* synthetic */ \u5e73\u53f0\u5316 f$1;
    public final /* synthetic */ MundoIntermediary f$2;
    public final /* synthetic */ Intent f$3;
    public final /* synthetic */ ArrayList f$4;

    public /* synthetic */ MundoIntermediary$$ExternalSyntheticLambda1(Intent intent, \u5e73\u53f0\u5316 \u5e73\u53f0\u53162, MundoIntermediary mundoIntermediary, Intent intent2, ArrayList arrayList) {
        this.f$0 = intent;
        this.f$1 = \u5e73\u53f0\u53162;
        this.f$2 = mundoIntermediary;
        this.f$3 = intent2;
        this.f$4 = arrayList;
    }

    public final Object invoke(Object object) {
        return MundoIntermediary.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, (PackageManager)object);
    }
}

