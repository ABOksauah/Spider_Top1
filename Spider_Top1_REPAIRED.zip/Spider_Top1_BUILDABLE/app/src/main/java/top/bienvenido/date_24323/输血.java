/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.IContentObserver
 *  android.net.Uri
 *  android.os.IBinder
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.database.IContentObserver;
import android.net.Uri;
import android.os.IBinder;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u723d\u70b9;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u8ba2\u9605;
import top.bienvenido.date_24323.\u8f93\u8840$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u8f93\u8840$$ExternalSyntheticLambda1;

public final class \u8f93\u8840
extends \u89e6\u53d1 {
    public static final Unit \u6293\u624b(Uri uri, IContentObserver iContentObserver, boolean bl, \u8ba2\u9605 \u8ba2\u96052) {
        IBinder iBinder = iContentObserver != null ? iContentObserver.asBinder() : null;
        \u8ba2\u96052.\u8d4b\u80fd(uri, iBinder, bl);
        return Unit.INSTANCE;
    }

    public static final Unit \u8d4b\u80fd(Uri uri, IContentObserver iContentObserver, boolean bl, \u8ba2\u9605 \u8ba2\u96052) {
        IBinder iBinder = iContentObserver != null ? iContentObserver.asBinder() : null;
        \u8ba2\u96052.\u8d4b\u80fd(uri, iBinder, bl);
        return Unit.INSTANCE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        IContentObserver iContentObserver;
        boolean bl;
        block9 : {
            if (arrobject.length >= 6) {
                arrobject[5] = 22;
            }
            iContentObserver = (IContentObserver)arrobject[1];
            bl = (Boolean)arrobject[2];
            boolean bl2 = \u62bd\u8c61.\u7ed9\u5230;
            if (!bl2) break block9;
            Uri[] arruri = (Uri[])arrobject[0];
            if (arruri == null) return super.\u8d4b\u80fd(object, method, arrobject);
            int n = arruri.length;
            for (int i = 0; i < n; ++i) {
                Uri uri = arruri[i];
                \u723d\u70b9.\u843d\u5730.\u8d4b\u80fd(new \u8f93\u8840$$ExternalSyntheticLambda0(uri, iContentObserver, bl));
            }
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        Uri uri = (Uri)arrobject[0];
        if (uri == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            \u723d\u70b9.\u843d\u5730.\u8d4b\u80fd(new \u8f93\u8840$$ExternalSyntheticLambda1(uri, iContentObserver, bl));
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

