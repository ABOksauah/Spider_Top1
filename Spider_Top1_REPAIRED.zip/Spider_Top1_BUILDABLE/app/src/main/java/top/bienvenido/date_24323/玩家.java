/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.functions.Function4
 *  top.bienvenido.date_24323.\u5229\u5668
 *  top.bienvenido.date_24323.\u6df1\u5ea6
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import top.bienvenido.date_24323.\u5229\u5668;
import top.bienvenido.date_24323.\u62a2\u54c1\u7c7b;
import top.bienvenido.date_24323.\u6df1\u5ea6;

public final class \u73a9\u5bb6
extends \u62a2\u54c1\u7c7b {
    public final \u5229\u5668 \u6293\u624b = \u5229\u5668.\u8d4b\u80fd;
    public final \u6df1\u5ea6 \u8d4b\u80fd = \u6df1\u5ea6.\u8d4b\u80fd;

    @Override
    public final Function4 \u6293\u624b() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final Function1 \u8d4b\u80fd() {
        return this.\u6293\u624b;
    }
}

