/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.inputmethod.EditorInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 *  kotlin.reflect.KMutableProperty1
 */
package top.bienvenido.date_24323;

import android.view.inputmethod.EditorInfo;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.reflect.KMutableProperty1;

public final class \u6478\u9c7c
extends FunctionReferenceImpl
implements Function2 {
    public \u6478\u9c7c(Object object) {
        super(2, object, KMutableProperty1.class, "set", "set(Ljava/lang/Object;Ljava/lang/Object;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        EditorInfo editorInfo = (EditorInfo)object;
        String string = (String)object2;
        ((KMutableProperty1)this.receiver).set((Object)editorInfo, (Object)string);
        return Unit.INSTANCE;
    }
}

