/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import top.bienvenido.date_24323.\u5916\u5305;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;

public final class \u5916\u5305$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ boolean f$0;
    public final /* synthetic */ Context f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ ApplicationInfo f$3;
    public final /* synthetic */ \u6241\u5e73\u5316 f$4;

    public /* synthetic */ \u5916\u5305$$ExternalSyntheticLambda1(boolean bl, Context context, String string2, ApplicationInfo applicationInfo, \u6241\u5e73\u5316 \u6241\u5e73\u53162) {
        this.f$0 = bl;
        this.f$1 = context;
        this.f$2 = string2;
        this.f$3 = applicationInfo;
        this.f$4 = \u6241\u5e73\u53162;
    }

    public final void run() {
        \u5916\u5305.\u8d4b\u80fd(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4);
    }
}

