/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ParceledListSlice
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.List
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.pm.ParceledListSlice;
import java.lang.reflect.Method;
import java.util.List;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u56e0\u5b50$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u660e\u786e;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u56e0\u5b50
extends \u89e6\u8fbe {
    public static final List \u8d4b\u80fd(Object[] arrobject, \u5e03\u5c40 \u5e03\u5c402) {
        Object object = arrobject[0];
        int n = object instanceof Number ? ((Number)object).intValue() : 0;
        Object object2 = arrobject[1];
        boolean bl = object2 instanceof Number;
        int n2 = 0;
        if (bl) {
            n2 = ((Number)object2).intValue();
        }
        return \u5e03\u5c402.\u8d4b\u80fd(0xFFFFFFFFL & (long)n2 | -4294967296L & (long)n << 32, \u6c34\u4f4d.\u6c89\u6dc0);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        if (!\u6c34\u4f4d.\u8d4b\u80fd) return method.invoke(object, arrobject);
        List list = (List)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd(new \u56e0\u5b50$$ExternalSyntheticLambda0(arrobject));
        if (list == null) return method.invoke(object, arrobject);
        try {
            if (!ParceledListSlice.class.isAssignableFrom(method.getReturnType())) return list;
            return \u660e\u786e.\u8d4b\u80fd(list);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return method.invoke(object, arrobject);
    }
}

