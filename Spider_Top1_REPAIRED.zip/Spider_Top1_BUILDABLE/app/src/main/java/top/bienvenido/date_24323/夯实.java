/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  top.bienvenido.date_24323.\u4e0b\u6e38
 *  top.bienvenido.date_24323.\u592f\u5b9e$
 *  top.bienvenido.date_24323.\u592f\u5b9e$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u592f\u5b9e$$ExternalSyntheticLambda1
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u4e0b\u6e38;
import top.bienvenido.date_24323.\u592f\u5b9e$;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u6269\u5c55;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u94f8\u9020;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u592f\u5b9e {
    public static \u6241\u5e73\u5316 \u6293\u624b;
    public static final \u592f\u5b9e \u8d4b\u80fd;

    static {
        \u8d4b\u80fd = new \u592f\u5b9e();
        \u6293\u624b = new \u6241\u5e73\u5316(0);
    }

    public static final PackageInfo \u8d4b\u80fd(String string2, PackageManager packageManager) {
        return packageManager.getPackageInfo(string2, 513);
    }

    public static final PackageInfo \u8d4b\u80fd(String string2, \u94f8\u9020 \u94f8\u90202) {
        return \u94f8\u90202.\u4e2d\u53f0(string2, 1);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void \u8d4b\u80fd() {
        int n;
        ApplicationInfo applicationInfo;
        \u6241\u5e73\u5316 \u6241\u5e73\u53162;
        int n2;
        String string2;
        ActivityInfo[] arractivityInfo;
        block6 : {
            block5 : {
                try {
                    String string3 = \u6c34\u4f4d.\u6293\u624b;
                    string2 = \u6c34\u4f4d.\u4e2d\u53f0;
                    PackageInfo packageInfo = \u6c34\u4f4d.\u6f0f\u6597 ? (PackageInfo)\u4e0b\u6e38.\u843d\u5730.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(string3)) : (PackageInfo)\u98ce\u53e3.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda1(string3));
                    if (packageInfo == null || (arractivityInfo = packageInfo.activities) == null) break block5;
                    \u6241\u5e73\u53162 = new \u6241\u5e73\u5316(arractivityInfo.length);
                    n = 0;
                    applicationInfo = arractivityInfo[0].applicationInfo;
                    \u6269\u5c55.\u8d4b\u80fd(applicationInfo);
                    n2 = arractivityInfo.length;
                    break block6;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            return;
        }
        do {
            if (n >= n2) {
                \u6293\u624b = \u6241\u5e73\u53162;
                return;
            }
            ActivityInfo activityInfo = arractivityInfo[n];
            if (Intrinsics.areEqual((Object)activityInfo.processName, (Object)string2) || (1 & activityInfo.flags) != 0) {
                int n3 = activityInfo.name.hashCode();
                activityInfo.applicationInfo = applicationInfo;
                activityInfo.enabled = true;
                \u6241\u5e73\u53162.\u8d4b\u80fd(n3, (Object)activityInfo);
            }
            ++n;
        } while (true);
    }
}

