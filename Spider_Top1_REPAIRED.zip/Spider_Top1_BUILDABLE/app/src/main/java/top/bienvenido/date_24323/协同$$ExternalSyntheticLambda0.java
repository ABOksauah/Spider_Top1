/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.os.IBinder;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u534f\u540c;
import top.bienvenido.date_24323.\u5e03\u5c40;

public final class \u534f\u540c$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ IBinder f$0;

    public /* synthetic */ \u534f\u540c$$ExternalSyntheticLambda0(IBinder iBinder) {
        this.f$0 = iBinder;
    }

    public final Object invoke(Object object) {
        return \u534f\u540c.\u8d4b\u80fd(this.f$0, (\u5e03\u5c40)object);
    }
}

