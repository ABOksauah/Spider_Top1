/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u683c\u5c40
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u683c\u5c40;

public final class \u683c\u5c40$$ExternalSyntheticLambda0
implements Runnable {
    public final void run() {
        \u683c\u5c40.\u5bf9\u9f50();
    }
}

