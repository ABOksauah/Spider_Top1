/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Bundle
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.Map
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.os.Bundle;
import java.lang.reflect.Method;
import java.util.Map;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u65b9\u6848$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u65b9\u6848
extends \u89e6\u8fbe {
    public final Function1 \u8d4b\u80fd;

    public \u65b9\u6848(Function1 function1) {
        this.\u8d4b\u80fd = function1;
    }

    public static final boolean \u8d4b\u80fd(Object[] arrobject, \u65b9\u6848 \u65b9\u68482, \u589e\u957f \u589e\u957f2) {
        Account account = (Account)arrobject[0];
        Object object = arrobject[1];
        String string = object != null ? object.toString() : null;
        return \u589e\u957f2.\u8d4b\u80fd(account, string, (Bundle)arrobject[2], (Map)\u65b9\u68482.\u8d4b\u80fd.invoke((Object)arrobject));
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return Intrinsics.areEqual((Object)\u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u65b9\u6848$$ExternalSyntheticLambda0(arrobject, this)), (Object)Boolean.TRUE);
    }
}

