/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.AuthenticatorDescription
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.AuthenticatorDescription;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.HashMap;
import java.util.Map;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u88c2\u53d8;

public abstract class \u66dd\u5149
extends Binder
implements \u589e\u957f {
    public static final /* synthetic */ int \u8d4b\u80fd;

    public \u66dd\u5149() {
        this.attachInterface((IInterface)this, "MundoAccountManagerService");
    }

    public final IBinder asBinder() {
        return this;
    }

    public final boolean onTransact(int n, Parcel parcel, Parcel parcel2, int n2) {
        if (n >= 1 && n <= 16777215) {
            parcel.enforceInterface("MundoAccountManagerService");
        }
        if (n == 1598968902) {
            parcel2.writeString("MundoAccountManagerService");
            return true;
        }
        Object object = null;
        switch (n) {
            default: {
                return super.onTransact(n, parcel, parcel2, n2);
            }
            case 26: {
                String string = parcel.readString();
                String string2 = parcel.readString();
                HashMap hashMap = ((\u683c\u5c40)this).\u54cd\u5e94(string, string2);
                parcel2.writeNoException();
                parcel2.writeMap((Map)hashMap);
                return true;
            }
            case 25: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                Parcelable.Creator creator = Bundle.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Bundle bundle = (Bundle)object;
                HashMap hashMap = parcel.readHashMap(this.getClass().getClassLoader());
                int n3 = ((\u683c\u5c40)this).\u8d4b\u80fd(account, string, bundle, (Map)hashMap);
                parcel2.writeNoException();
                parcel2.writeInt(n3);
                return true;
            }
            case 24: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Account account = (Account)object;
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account);
                parcel2.writeNoException();
                return true;
            }
            case 23: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Account account = (Account)object;
                String string = parcel.readString();
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, string);
                parcel2.writeNoException();
                return true;
            }
            case 22: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                String string3 = parcel.readString();
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, string, string3);
                parcel2.writeNoException();
                return true;
            }
            case 21: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                int n4 = ((\u683c\u5c40)this).\u6293\u624b(account);
                parcel2.writeNoException();
                parcel2.writeInt(n4);
                return true;
            }
            case 20: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                Object object2 = parcel.readInt() != 0 ? creator.createFromParcel(parcel) : null;
                Account account = (Account)object2;
                Parcelable.Creator creator2 = Bundle.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator2.createFromParcel(parcel);
                }
                Bundle bundle = (Bundle)object;
                int n5 = parcel.readInt();
                boolean bl = false;
                if (n5 != 0) {
                    bl = true;
                }
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, bundle, bl);
                parcel2.writeNoException();
                return true;
            }
            case 19: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                int n6 = parcel.readInt();
                boolean bl = false;
                if (n6 != 0) {
                    bl = true;
                }
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, string, bl);
                parcel2.writeNoException();
                return true;
            }
            case 18: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                Object object3 = parcel.readInt() != 0 ? creator.createFromParcel(parcel) : null;
                Account account = (Account)object3;
                String string = parcel.readString();
                boolean bl = parcel.readInt() != 0;
                Parcelable.Creator creator3 = Bundle.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator3.createFromParcel(parcel);
                }
                Bundle bundle = (Bundle)object;
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, string, bl, bundle);
                parcel2.writeNoException();
                return true;
            }
            case 17: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                String string4 = parcel.readString();
                String[] arrstring = parcel.createStringArray();
                boolean bl = parcel.readInt() != 0;
                Parcelable.Creator creator = Bundle.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Bundle bundle = (Bundle)object;
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, string, string4, arrstring, bl, bundle);
                parcel2.writeNoException();
                return true;
            }
            case 16: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                Object object4 = parcel.readInt() != 0 ? creator.createFromParcel(parcel) : null;
                Account account = (Account)object4;
                String string = parcel.readString();
                boolean bl = parcel.readInt() != 0;
                boolean bl2 = parcel.readInt() != 0;
                Parcelable.Creator creator4 = Bundle.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator4.createFromParcel(parcel);
                }
                Bundle bundle = (Bundle)object;
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, string, bl, bl2, bundle);
                parcel2.writeNoException();
                return true;
            }
            case 15: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                String string5 = parcel.readString();
                ((\u683c\u5c40)this).\u8d4b\u80fd(account, string, string5);
                parcel2.writeNoException();
                return true;
            }
            case 14: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                ((\u683c\u5c40)this).\u8d4b\u80fd(account, string);
                parcel2.writeNoException();
                return true;
            }
            case 13: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                String string6 = parcel.readString();
                ((\u683c\u5c40)this).\u6293\u624b(account, string, string6);
                parcel2.writeNoException();
                return true;
            }
            case 12: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                String string7 = ((\u683c\u5c40)this).\u6293\u624b(account, string);
                parcel2.writeNoException();
                parcel2.writeString(string7);
                return true;
            }
            case 11: {
                String string = parcel.readString();
                String string8 = parcel.readString();
                ((\u683c\u5c40)this).\u8d4b\u80fd(string, string8);
                parcel2.writeNoException();
                return true;
            }
            case 10: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                int n7 = ((\u683c\u5c40)this).\u8d4b\u80fd(account);
                parcel2.writeNoException();
                parcel2.writeInt(n7);
                return true;
            }
            case 9: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Account account = (Account)object;
                int n8 = parcel.readInt();
                boolean bl = false;
                if (n8 != 0) {
                    bl = true;
                }
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, bl);
                parcel2.writeNoException();
                return true;
            }
            case 8: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                String[] arrstring = parcel.createStringArray();
                ((\u683c\u5c40)this).\u6293\u624b(iBinder, string, arrstring);
                parcel2.writeNoException();
                return true;
            }
            case 7: {
                IBinder iBinder = parcel.readStrongBinder();
                String string = parcel.readString();
                String[] arrstring = parcel.createStringArray();
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, string, arrstring);
                parcel2.writeNoException();
                return true;
            }
            case 6: {
                IBinder iBinder = parcel.readStrongBinder();
                Parcelable.Creator creator = Account.CREATOR;
                if (parcel.readInt() != 0) {
                    object = creator.createFromParcel(parcel);
                }
                Account account = (Account)object;
                String[] arrstring = parcel.createStringArray();
                ((\u683c\u5c40)this).\u8d4b\u80fd(iBinder, account, arrstring);
                parcel2.writeNoException();
                return true;
            }
            case 5: {
                String string = parcel.readString();
                Account[] arraccount = ((\u683c\u5c40)this).\u8ddf\u8fdb(string);
                parcel2.writeNoException();
                parcel2.writeTypedArray((Parcelable[])arraccount, 1);
                return true;
            }
            case 4: {
                parcel.readString();
                parcel.readInt();
                Account[] arraccount = ((\u683c\u5c40)this).\u7ed9\u5230();
                parcel2.writeNoException();
                parcel2.writeTypedArray((Parcelable[])arraccount, 1);
                return true;
            }
            case 3: {
                AuthenticatorDescription[] arrauthenticatorDescription = ((\u683c\u5c40)this).\u843d\u5730();
                parcel2.writeNoException();
                parcel2.writeTypedArray((Parcelable[])arrauthenticatorDescription, 1);
                return true;
            }
            case 2: {
                Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
                String string = parcel.readString();
                String string9 = ((\u683c\u5c40)this).\u4e2d\u53f0(account, string);
                parcel2.writeNoException();
                parcel2.writeString(string9);
                return true;
            }
            case 1: 
        }
        Account account = (Account)\u88c2\u53d8.\u8d4b\u80fd(parcel, Account.CREATOR);
        String string = ((\u683c\u5c40)this).\u4e2d\u53f0(account);
        parcel2.writeNoException();
        parcel2.writeString(string);
        return true;
    }
}

