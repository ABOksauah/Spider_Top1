/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  sun.misc.Unsafe
 *  top.bienvenido.date_24323.\u62a4\u57ce\u6cb3$
 *  top.bienvenido.date_24323.\u62a4\u57ce\u6cb3$$ExternalSyntheticLambda0
 *  top.bienvenido.date_24323.\u62a4\u57ce\u6cb3$$ExternalSyntheticLambda1
 *  top.bienvenido.date_24323.\u62a4\u57ce\u6cb3$$ExternalSyntheticLambda2
 */
package top.bienvenido.date_24323;

import android.os.Build;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import sun.misc.Unsafe;
import top.bienvenido.date_24323.\u4e0b\u6c89;
import top.bienvenido.date_24323.\u62a4\u57ce\u6cb3$;
import top.bienvenido.date_24323.\u8d85\u6211;

public final class \u62a4\u57ce\u6cb3 {
    public static final Function1 \u4e2d\u53f0;
    public static final Unsafe \u6293\u624b;
    public static final \u62a4\u57ce\u6cb3 \u8d4b\u80fd;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static {
        $ExternalSyntheticLambda2 externalSyntheticLambda2;
        block8 : {
            \u8d85\u6211 \u8d85\u62112;
            Object object;
            String[] arrstring;
            block9 : {
                int n;
                \u8d4b\u80fd = new \u62a4\u57ce\u6cb3();
                Method method = Unsafe.class.getDeclaredMethod("getUnsafe", \u4e0b\u6c89.\u6293\u624b);
                method.setAccessible(true);
                Object[] arrobject = \u4e0b\u6c89.\u4e2d\u53f0;
                externalSyntheticLambda2 = null;
                \u6293\u624b = (Unsafe)method.invoke(null, arrobject);
                if (Build.VERSION.SDK_INT < 28) break block8;
                arrstring = new String[]{"L"};
                try {
                    \u8d85\u62112 = new \u8d85\u6211(Class.forName((String)"dalvik.system.VMRuntime"));
                    n = \u8d85\u62112.\u4e2d\u53f0;
                }
                catch (Throwable throwable) {
                    // empty catch block
                    break block8;
                }
                for (int i = 0; i < n; ++i) {
                    long l = \u8d85\u62112.\u843d\u5730 + (long)i * \u8d85\u62112.\u6293\u624b;
                    \u6293\u624b.putLong((Object)\u8d85\u62112.\u95ed\u73af, \u8d85\u62112.\u8d4b\u80fd, l);
                    if (!Intrinsics.areEqual((Object)"getRuntime", (Object)\u8d85\u62112.\u95ed\u73af.getName())) continue;
                    object = \u8d85\u62112.\u95ed\u73af.invoke(null, arrobject);
                    break block9;
                }
                object = null;
            }
            String[][] arrarrstring = new String[][]{arrstring};
            int n = \u8d85\u62112.\u4e2d\u53f0;
            for (int i = 0; i < n; ++i) {
                long l = \u8d85\u62112.\u843d\u5730 + (long)i * \u8d85\u62112.\u6293\u624b;
                \u6293\u624b.putLong((Object)\u8d85\u62112.\u95ed\u73af, \u8d85\u62112.\u8d4b\u80fd, l);
                if (!Intrinsics.areEqual((Object)"setHiddenApiExemptions", (Object)\u8d85\u62112.\u95ed\u73af.getName())) continue;
                \u8d85\u62112.\u95ed\u73af.invoke(object, (Object[])arrarrstring);
                break;
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 36) {
                $ExternalSyntheticLambda2 externalSyntheticLambda22;
                Field field = Unsafe.class.getDeclaredField("theInternalUnsafe");
                field.setAccessible(true);
                Object object = field.get(null);
                Class class_ = object.getClass();
                Method method = class_.getDeclaredMethod("staticFieldOffset", new Class[]{Field.class});
                method.setAccessible(true);
                Class class_2 = Long.TYPE;
                Method method2 = class_.getDeclaredMethod("putReference", new Class[]{Object.class, class_2, Object.class});
                method2.setAccessible(true);
                Method method3 = class_.getDeclaredMethod("getReference", new Class[]{Object.class, class_2});
                method3.setAccessible(true);
                externalSyntheticLambda2 = externalSyntheticLambda22 = new $ExternalSyntheticLambda2(method, object, method3, method2);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        \u4e2d\u53f0 = externalSyntheticLambda2;
    }

    public static final Object \u8d4b\u80fd(Method method, Object object, Class class_, long l) {
        return method.invoke(object, new Object[]{class_, l});
    }

    public static final Pair \u8d4b\u80fd(Method method, Object object, Method method2, Method method3, Field field) {
        long l = (Long)method.invoke(object, new Object[]{field});
        Class class_ = field.getDeclaringClass();
        $ExternalSyntheticLambda0 externalSyntheticLambda0 = new $ExternalSyntheticLambda0(method2, object, class_, l);
        $ExternalSyntheticLambda1 externalSyntheticLambda1 = new $ExternalSyntheticLambda1(method3, object, class_, l);
        return TuplesKt.to((Object)externalSyntheticLambda0, (Object)externalSyntheticLambda1);
    }

    public static final Unit \u8d4b\u80fd(Method method, Object object, Class class_, long l, Object object2) {
        method.invoke(object, new Object[]{class_, l, object2});
        return Unit.INSTANCE;
    }
}

