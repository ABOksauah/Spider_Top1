/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u586b\u5751$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u586b\u5751
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        IInterface iInterface = (IInterface)arrobject[0];
        IBinder iBinder = iInterface != null ? iInterface.asBinder() : null;
        Object object = arrobject[1];
        String string = object != null ? object.toString() : null;
        Object object2 = arrobject[2];
        String string2 = null;
        if (object2 != null) {
            string2 = object2.toString();
        }
        \u589e\u957f2.\u8d4b\u80fd(iBinder, string, string2, (String[])arrobject[3], Intrinsics.areEqual((Object)arrobject[4], (Object)Boolean.TRUE), (Bundle)arrobject[5]);
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u586b\u5751$$ExternalSyntheticLambda0(arrobject));
    }
}

