/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u4f53\u7cfb;

public final class \u4f53\u7cfb$$ExternalSyntheticLambda0
implements Runnable {
    public final void run() {
        \u4f53\u7cfb.\u4e2d\u53f0();
    }
}

