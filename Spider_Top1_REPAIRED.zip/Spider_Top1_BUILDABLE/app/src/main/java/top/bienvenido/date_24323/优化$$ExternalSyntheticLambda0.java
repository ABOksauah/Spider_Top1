/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u4f18\u5316;
import top.bienvenido.date_24323.\u589e\u957f;

public final class \u4f18\u5316$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ Object[] f$0;

    public /* synthetic */ \u4f18\u5316$$ExternalSyntheticLambda0(Object[] arrobject) {
        this.f$0 = arrobject;
    }

    public final Object invoke(Object object) {
        return \u4f18\u5316.\u8d4b\u80fd(this.f$0, (\u589e\u957f)object);
    }
}

