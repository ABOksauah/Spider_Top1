/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.AdaptedFunctionReference
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.AdaptedFunctionReference;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u89e6\u53d1;

public final class \u7a33\u5b9a
extends AdaptedFunctionReference
implements Function1 {
    public \u7a33\u5b9a() {
        super(1, (Object)\u51fa\u51fb.\u843d\u5730, \u56f4\u7ed5.class, "createStaticEnhancedHandler", "createStaticEnhancedHandler(Ljava/lang/Object;Ltop/bienvenido/mundo/blockade/sm/MInvocationHandler;)Ljava/lang/Object;", 0);
    }

    public final Object invoke(Object object) {
        \u56f4\u7ed5 \u56f4\u7ed52 = (\u56f4\u7ed5)this.receiver;
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        \u56f4\u7ed52.getClass();
        return \u56f4\u7ed5.\u8d4b\u80fd(object, \u89e6\u53d12);
    }
}

