/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageInfo
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function3
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageInfo;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u5c5e\u6027
extends FunctionReferenceImpl
implements Function3 {
    public static final \u5c5e\u6027 \u8d4b\u80fd = new \u5c5e\u6027();

    public \u5c5e\u6027() {
        super(3, \u94f8\u9020.class, "getPackageInfo", "getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;", 0);
    }

    public final Object invoke(Object object, Object object2, Object object3) {
        return ((\u94f8\u9020)object).\u4e2d\u53f0((String)object2, ((Number)object3).intValue());
    }
}

