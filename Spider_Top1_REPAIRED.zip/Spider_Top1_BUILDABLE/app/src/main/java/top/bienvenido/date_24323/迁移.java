/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.text.StringsKt
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.text.StringsKt;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u8fc1\u79fb
extends \u53d8\u8fc1 {
    public static final \u5e73\u53f0\u5316 \u6293\u624b;
    public static final \u8fc1\u79fb \u8d4b\u80fd;

    static {
        \u8d4b\u80fd = new \u8fc1\u79fb();
        int[] arrn = new int[]{52602690, -2062386608, -895673731, -139251669, -244555749, -1726932149, 1903902114, 542441041, -223469635, 434482434, -406040016, 1365911975, 36778333, -5573545, -751646898, 691260818, 710297143, 175802396, 1344438003, 1011607};
        \u5e73\u53f0\u5316 \u5e73\u53f0\u53162 = new \u5e73\u53f0\u5316(20);
        for (int i = 0; i < 20; ++i) {
            try {
                \u5e73\u53f0\u53162.\u8d4b\u80fd(arrn[i]);
            }
            catch (Exception exception) {
                \u5e73\u53f0\u53162 = new \u5e73\u53f0\u5316(0);
                break;
            }
            continue;
        }
        \u6293\u624b = \u5e73\u53f0\u53162;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        boolean bl;
        String string;
        block4 : {
            block3 : {
                try {
                    string = (String)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, String.class);
                    if (string == null) return super.\u8d4b\u80fd(object, method, arrobject);
                    \u5e73\u53f0\u5316 \u5e73\u53f0\u53162 = \u6293\u624b;
                    int n = string.hashCode();
                    if (\u753b\u997c.\u8d4b\u80fd(\u5e73\u53f0\u53162.\u8d4b\u80fd, \u5e73\u53f0\u53162.\u6293\u624b, n) < 0 && !StringsKt.startsWith$default((String)string, (String)"com.google.android.", (boolean)false, (int)2, null)) break block3;
                }
                catch (Exception exception) {
                    // empty catch block
                    return super.\u8d4b\u80fd(object, method, arrobject);
                }
                bl = true;
                break block4;
            }
            bl = false;
        }
        if (!bl) {
            if (!StringsKt.startsWith$default((String)string, (String)\u6c34\u4f4d.\u6293\u624b, (boolean)false, (int)2, null)) return super.\u8d4b\u80fd(object, method, arrobject);
        }
        "Assume application obtained permission -> " + string;
        return 0;
    }
}

