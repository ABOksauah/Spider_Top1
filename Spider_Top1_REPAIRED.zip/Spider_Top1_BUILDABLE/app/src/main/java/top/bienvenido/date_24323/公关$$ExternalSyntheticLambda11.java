/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function0;
import top.bienvenido.date_24323.\u516c\u5173;

public final class \u516c\u5173$$ExternalSyntheticLambda11
implements Function0 {
    public final /* synthetic */ Class f$0;

    public /* synthetic */ \u516c\u5173$$ExternalSyntheticLambda11(Class class_) {
        this.f$0 = class_;
    }

    public final Object invoke() {
        return \u516c\u5173.\u8d4b\u80fd(this.f$0);
    }
}

