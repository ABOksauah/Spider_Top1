/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  top.bienvenido.date_24323.\u8fb9\u754c
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u8fb9\u754c;

public final class \u8fb9\u754c$$ExternalSyntheticLambda7
implements Runnable {
    public final void run() {
        \u8fb9\u754c.\u54cd\u5e94();
    }
}

