/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5f62\u6001
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5361\u4f4d;
import top.bienvenido.date_24323.\u5f62\u6001;

public final class \u751f\u6001
extends \u5361\u4f4d {
    public static final \u751f\u6001 \u843d\u5730 = new \u751f\u6001();

    public \u751f\u6001() {
        super((Function1)\u5f62\u6001.\u8d4b\u80fd, "MundoAccountManagerService");
    }
}

