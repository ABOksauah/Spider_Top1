/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  kotlin.jvm.functions.Function2
 */
package top.bienvenido.date_24323;

import java.lang.reflect.Method;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u98ce\u53e3;

public final class \u7eb5\u5411
extends \u89e6\u53d1 {
    public final Function2 \u4e2d\u53f0;
    public final Class \u6293\u624b;
    public final Object \u95ed\u73af;

    public \u7eb5\u5411(Class class_, Function2 function2) {
        String string = \u98ce\u53e3.\u6293\u624b;
        this.\u6293\u624b = class_;
        this.\u4e2d\u53f0 = function2;
        this.\u95ed\u73af = string;
    }

    public \u7eb5\u5411(Class class_, Function2 function2, String string) {
        this.\u6293\u624b = class_;
        this.\u4e2d\u53f0 = function2;
        this.\u95ed\u73af = string;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        Object object2 = \u89e6\u8fbe.\u8d4b\u80fd(arrobject, this.\u6293\u624b);
        if (object2 == null) return super.\u8d4b\u80fd(object, method, arrobject);
        try {
            this.\u4e2d\u53f0.invoke(object2, this.\u95ed\u73af);
            return super.\u8d4b\u80fd(object, method, arrobject);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return super.\u8d4b\u80fd(object, method, arrobject);
    }
}

