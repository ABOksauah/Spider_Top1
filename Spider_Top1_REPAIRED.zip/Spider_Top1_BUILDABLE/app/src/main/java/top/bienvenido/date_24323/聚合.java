/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Triple
 *  top.bienvenido.mundo.manifest.MundoActivity
 *  top.bienvenido.mundo.manifest.MundoActivity$Companion
 *  top.bienvenido.mundo.manifest.MundoActivity$Companion$STUB
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import kotlin.Triple;
import top.bienvenido.date_24323.\u54c1\u724c;
import top.bienvenido.date_24323.\u5fc3\u529b;
import top.bienvenido.date_24323.\u98ce\u53e3;
import top.bienvenido.mundo.manifest.MundoActivity;
import top.bienvenido.mundo.manifest.MundoReceiver;

public abstract class \u805a\u5408 {
    public static Intent \u8d4b\u80fd(Intent intent, int n, \u5fc3\u529b \u5fc3\u529b2, boolean bl, String string2) {
        String string3 = MundoActivity.Companion.STUB.class.getName();
        String string4 = string3 + n;
        Intent intent2 = new Intent();
        String string5 = \u98ce\u53e3.\u6293\u624b;
        if (bl) {
            string4 = string4 + "H";
        }
        Intent intent3 = intent2.setComponent(new ComponentName(string5, string4));
        Bundle bundle = new Bundle();
        bundle.putParcelable("android.intent.extra.INTENT", (Parcelable)intent);
        bundle.putBinder(\u5fc3\u529b.class.getName(), (IBinder)\u5fc3\u529b2);
        if (string2 != null) {
            bundle.putString(String.class.getName(), string2);
        }
        bundle.putString("user", \u5fc3\u529b2.\u4e2d\u53f0.\u4e2d\u53f0);
        return intent3.putExtras(bundle).setType(String.valueOf((int)intent.filterHashCode()));
    }

    public static Intent \u8d4b\u80fd(Intent intent, String string2) {
        if (intent.getComponent() == null && intent.getPackage() == null) {
            return null;
        }
        String string3 = \u98ce\u53e3.\u6293\u624b;
        Intent intent2 = new Intent(string3 + ".mundo.receiver.stub").setComponent(new ComponentName(string3, MundoReceiver.class.getName())).putExtra("android.intent.extra.INTENT", (Parcelable)intent);
        if (string2 != null) {
            intent2.putExtra(String.class.getName(), string2);
        }
        return intent2;
    }

    public static Triple \u8d4b\u80fd(Intent intent) {
        Bundle bundle;
        Intent intent2;
        block5 : {
            block4 : {
                try {
                    bundle = intent.getExtras();
                    if (bundle != null) break block4;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            intent2 = (Intent)bundle.getParcelable("android.intent.extra.INTENT");
            if (intent2 != null) break block5;
            return null;
        }
        Triple triple = new Triple((Object)intent2, (Object)bundle.getBinder(\u5fc3\u529b.class.getName()), (Object)bundle.getString(String.class.getName()));
        return triple;
    }
}

