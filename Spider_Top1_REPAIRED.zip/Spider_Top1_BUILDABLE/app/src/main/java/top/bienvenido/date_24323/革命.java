/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.job.IJobCallback
 *  android.app.job.IJobCallback$Stub
 *  android.app.job.JobParameters
 *  android.app.job.JobService
 *  android.content.ComponentName
 *  android.content.Intent
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcelable
 *  android.os.PersistableBundle
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Map
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u5408\u529b
 *  top.bienvenido.date_24323.\u6bb5\u4f4d
 *  top.bienvenido.date_24323.\u8425\u6536
 *  top.bienvenido.date_24323.\u8d77\u98de
 *  top.bienvenido.date_24323.\u94fe\u8def
 *  top.bienvenido.date_24323.\u9769\u547d$
 *  top.bienvenido.date_24323.\u9769\u547d$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import android.app.job.IJobCallback;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcelable;
import android.os.PersistableBundle;
import java.util.Map;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5408\u529b;
import top.bienvenido.date_24323.\u56f4\u7ed5;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6bb5\u4f4d;
import top.bienvenido.date_24323.\u6c34\u4f4d;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u81ea\u6d3d;
import top.bienvenido.date_24323.\u8425\u6536;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8d77\u98de;
import top.bienvenido.date_24323.\u8e1d\u90e8;
import top.bienvenido.date_24323.\u94fe\u8def;
import top.bienvenido.date_24323.\u9769\u547d$;

public abstract class \u9769\u547d
extends JobService {
    public final \u81ea\u6d3d \u6293\u624b;
    public final \u8d77\u98de \u8d4b\u80fd = new \u8d77\u98de("extras");

    public \u9769\u547d() {
        \u81ea\u6d3d \u81ea\u6d3d2 = \u62bd\u8c61.\u540c\u6b65 ? \u771f\u9999.\u8d4b\u80fd(JobParameters.class, "callback") : \u81ea\u6d3d.\u8d4b\u80fd;
        this.\u6293\u624b = \u81ea\u6d3d2;
    }

    public static final JobService \u8d4b\u80fd(ComponentName componentName, \u7b14\u82af \u7b14\u82af2) {
        IBinder iBinder = \u7b14\u82af2.\u8d4b\u80fd(componentName, \u6c34\u4f4d.\u95ed\u73af);
        if (iBinder != null) {
            \u6bb5\u4f4d.\u6293\u624b.getClass();
            Object object = \u6bb5\u4f4d.\u4ea4\u4ed8.get((Object)iBinder);
            if (object instanceof JobService) {
                return (JobService)object;
            }
        }
        return null;
    }

    public final void onNetworkChanged(JobParameters jobParameters) {
        JobService jobService = this.\u8d4b\u80fd(jobParameters);
        if (jobService != null) {
            jobService.onNetworkChanged(jobParameters);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final int onStartCommand(Intent intent, int n, int n2) {
        \u5408\u529b \u5408\u529b2;
        String string2;
        Intent intent2;
        block5 : {
            if (intent == null) return 2;
            try {
                intent2 = (Intent)intent.getParcelableExtra("android.intent.extra.INTENT");
            }
            catch (Exception exception) {
                return 2;
            }
            if (intent2 == null) return 2;
            \u5408\u529b2 = \u5408\u529b.\u6293\u624b;
            string2 = intent2.getStringExtra("user");
            if (string2 != null) break block5;
            string2 = "0";
        }
        \u5408\u529b2.\u843d\u5730(intent2, string2);
        do {
            return 2;
            break;
        } while (true);
    }

    public final boolean onStartJob(JobParameters jobParameters) {
        JobService jobService = this.\u8d4b\u80fd(jobParameters);
        if (jobService != null) {
            return jobService.onStartJob(jobParameters);
        }
        return true;
    }

    public final boolean onStopJob(JobParameters jobParameters) {
        JobService jobService = this.\u8d4b\u80fd(jobParameters);
        if (jobService != null) {
            return jobService.onStopJob(jobParameters);
        }
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final JobService \u8d4b\u80fd(JobParameters jobParameters) {
        if (jobParameters != null) {
            try {
                IBinder iBinder;
                JobService jobService;
                PersistableBundle persistableBundle = jobParameters.getExtras();
                if (persistableBundle == null) {
                    return null;
                }
                ComponentName componentName = ComponentName.unflattenFromString((String)persistableBundle.getString("mundo_base_string", ""));
                if (componentName == null) {
                    return null;
                }
                PersistableBundle persistableBundle2 = persistableBundle.getPersistableBundle("mundo_base_bundle");
                if (persistableBundle2 == null) {
                    return null;
                }
                if (\u62bd\u8c61.\u540c\u6b65 && (iBinder = (IBinder)this.\u6293\u624b.\u8d4b\u80fd((Object)jobParameters)) != null) {
                    IJobCallback iJobCallback = IJobCallback.Stub.asInterface((IBinder)iBinder);
                    this.\u6293\u624b.\u8d4b\u80fd((Object)jobParameters, (Object)new \u8e1d\u90e8(iBinder, (IInterface)\u56f4\u7ed5.\u8d4b\u80fd((Object)iJobCallback, (\u89e6\u8fbe)\u8425\u6536.\u6293\u624b)));
                }
                if ((jobService = (JobService)\u94fe\u8def.\u843d\u5730.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(componentName))) == null) {
                    return null;
                }
                this.\u8d4b\u80fd.\u6293\u624b.\u8d4b\u80fd((Object)jobParameters, (Object)persistableBundle2);
                return jobService;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return null;
    }
}

