/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.accounts.IAccountAuthenticator
 *  android.accounts.IAccountAuthenticatorResponse
 *  android.accounts.IAccountManagerResponse
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  kotlin.jvm.internal.Intrinsics
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.accounts.IAccountAuthenticator;
import android.accounts.IAccountAuthenticatorResponse;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.internal.Intrinsics;
import top.bienvenido.date_24323.\u5165\u53e3;
import top.bienvenido.date_24323.\u5f00\u573a\u5b50;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.date_24323.\u8d4b\u80fd;

public final class \u77e9\u9635
extends \u5f00\u573a\u5b50 {
    public final /* synthetic */ Account \u540c\u6b65;
    public final /* synthetic */ Bundle \u5bf9\u9f50;

    public \u77e9\u9635(IAccountManagerResponse iAccountManagerResponse, Account account, Bundle bundle, String string, String string2) {
        this.\u540c\u6b65 = account;
        this.\u5bf9\u9f50 = bundle;
        super(iAccountManagerResponse, string, false, false, string2, false, false);
    }

    @Override
    public final void \u5bf9\u9f50() {
        Iterator iterator = \u683c\u5c40.\u4e2d\u53f0.\u8d4b\u80fd.iterator();
        while (iterator.hasNext()) {
            if (!Intrinsics.areEqual((Object)((\u8d4b\u80fd)iterator.next()).\u8d4b\u80fd, (Object)this.\u540c\u6b65)) continue;
            IAccountAuthenticator iAccountAuthenticator = this.\u7ed9\u5230;
            if (iAccountAuthenticator == null) break;
            iAccountAuthenticator.addAccountFromCredentials((IAccountAuthenticatorResponse)this, this.\u540c\u6b65, this.\u5bf9\u9f50);
            break;
        }
    }
}

