/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.AttributionSource
 *  android.content.ComponentName
 *  android.content.Context
 *  android.os.Parcelable
 *  android.os.WorkSource
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  top.bienvenido.date_24323.\u516c\u57df
 *  top.bienvenido.date_24323.\u53d8\u8fc1
 *  top.bienvenido.date_24323.\u79c1\u57df
 *  top.bienvenido.date_24323.\u89e6\u53d1
 */
package top.bienvenido.date_24323;

import android.content.AttributionSource;
import android.content.ComponentName;
import android.content.Context;
import android.os.Parcelable;
import android.os.WorkSource;
import top.bienvenido.date_24323.\u516c\u57df;
import top.bienvenido.date_24323.\u53d8\u8fc1;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u98ce\u53e3;

public abstract class \u672c\u6211 {
    public static final \u89e6\u53d1 \u4e2d\u53f0;
    public static final \u516c\u57df \u54cd\u5e94;
    public static final \u516c\u57df \u5e73\u53f0;
    public static final \u53d8\u8fc1 \u6293\u624b;
    public static final \u79c1\u57df \u6c89\u6dc0;
    public static final \u79c1\u57df \u6f0f\u6597;
    public static final \u79c1\u57df \u7ed9\u5230;
    public static final \u79c1\u57df \u843d\u5730;
    public static final \u89e6\u8fbe \u8d4b\u80fd;
    public static final \u79c1\u57df \u95ed\u73af;

    static {
        \u89e6\u53d1 \u89e6\u53d12;
        \u8d4b\u80fd = new \u89e6\u8fbe();
        \u6293\u624b = new \u53d8\u8fc1();
        \u4e2d\u53f0 = \u89e6\u53d12 = new \u89e6\u53d1();
        \u95ed\u73af = new \u79c1\u57df((Object)0);
        \u843d\u5730 = new \u79c1\u57df((Object)1);
        \u6f0f\u6597 = new \u79c1\u57df((Object)Boolean.TRUE);
        \u6c89\u6dc0 = new \u79c1\u57df((Object)Boolean.FALSE);
        \u7ed9\u5230 = new \u79c1\u57df(null);
        String string2 = \u98ce\u53e3.\u6293\u624b;
        \u5e73\u53f0 = new \u516c\u57df((\u89e6\u8fbe)\u89e6\u53d12, ComponentName.class, (Parcelable)new ComponentName(string2, string2));
        \u54cd\u5e94 = new \u516c\u57df((\u89e6\u8fbe)\u89e6\u53d12, WorkSource.class, null);
    }

    public static \u89e6\u8fbe \u8d4b\u80fd(\u53d8\u8fc1 \u53d8\u8fc12) {
        if (\u62bd\u8c61.\u5e73\u53f0) {
            return new \u516c\u57df((\u89e6\u8fbe)\u53d8\u8fc12, AttributionSource.class, (Parcelable)\u98ce\u53e3.\u8d4b\u80fd.getAttributionSource());
        }
        return \u53d8\u8fc12;
    }
}

