/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.android.internal.net.VpnConfig
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u5236\u9ad8\u70b9
 *  top.bienvenido.date_24323.\u53ef\u7528\u6027
 *  top.bienvenido.date_24323.\u56de\u8df3
 *  top.bienvenido.date_24323.\u7eb5\u5411
 */
package top.bienvenido.date_24323;

import com.android.internal.net.VpnConfig;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5206\u5c42;
import top.bienvenido.date_24323.\u5236\u9ad8\u70b9;
import top.bienvenido.date_24323.\u53ef\u7528\u6027;
import top.bienvenido.date_24323.\u56de\u8df3;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u6d1e\u81ea\u8eab;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u8fc1\u79fb;
import top.bienvenido.date_24323.\u9020\u5e02;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u901a\u6652
extends \u96c6\u6210 {
    public static final \u901a\u6652 \u6293\u624b = new \u901a\u6652();

    @Override
    public final void \u8d4b\u80fd() {
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        boolean bl = \u62bd\u8c61.\u5e73\u53f0;
        if (bl) {
            \u51fa\u51fb \u51fa\u51fb2;
            this.\u8d4b\u80fd("people", "vibrator_manager", "game");
            \u51fa\u51fb \u51fa\u51fb3 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("domain_verification", this.\u8d4b\u80fd, null);
            if (\u51fa\u51fb3 != null) {
                \u79c1\u57df \u79c1\u57df2 = \u672c\u6211.\u7ed9\u5230;
                \u51fa\u51fb3.\u8d4b\u80fd.\u8d4b\u80fd(-692070383, \u79c1\u57df2);
            }
            if ((\u51fa\u51fb2 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("permission_checker", this.\u8d4b\u80fd, null)) != null) {
                \u51fa\u51fb2.\u8d4b\u80fd(new int[]{686218487, 742313225}, \u672c\u6211.\u95ed\u73af);
            }
        } else {
            \u6d1e\u81ea\u8eab.\u8d4b\u80fd("vibrator", \u89e6\u53d12, null);
        }
        if (\u62bd\u8c61.\u8d4b\u80fd) {
            this.\u8d4b\u80fd("graphicsstats", "usagestats");
            if (\u62bd\u8c61.\u6293\u624b) {
                this.\u8d4b\u80fd("fingerprint", "netstats");
                if (\u62bd\u8c61.\u4e2d\u53f0) {
                    \u6d1e\u81ea\u8eab.\u8d4b\u80fd("hardware_properties", this.\u8d4b\u80fd, null);
                    if (\u62bd\u8c61.\u843d\u5730) {
                        \u51fa\u51fb \u51fa\u51fb4;
                        \u6d1e\u81ea\u8eab.\u8d4b\u80fd("companiondevice", this.\u8d4b\u80fd, null);
                        \u51fa\u51fb \u51fa\u51fb5 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("device_identifiers", this.\u8d4b\u80fd, null);
                        if (\u51fa\u51fb5 != null) {
                            \u51fa\u51fb5.\u8d4b\u80fd(new int[]{509696967, 790175978, -75128768}, new \u79c1\u57df(\u9020\u5e02.\u8d4b\u80fd));
                        }
                        if ((\u51fa\u51fb4 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("storagestats", this.\u8d4b\u80fd, null)) != null) {
                            \u56de\u8df3 \u56de\u8df32 = new \u56de\u8df3();
                            \u51fa\u51fb4.\u8d4b\u80fd.\u8d4b\u80fd(421238612, (Object)\u56de\u8df32);
                        }
                        if (\u62bd\u8c61.\u6f0f\u6597) {
                            this.\u8d4b\u80fd("slice", "crossprofileapps");
                            if (\u62bd\u8c61.\u6c89\u6dc0) {
                                this.\u8d4b\u80fd("role", "face", "uri_grants");
                                if (\u62bd\u8c61.\u7ed9\u5230) {
                                    \u51fa\u51fb \u51fa\u51fb6;
                                    \u6d1e\u81ea\u8eab.\u8d4b\u80fd("auth", this.\u8d4b\u80fd, null);
                                    \u51fa\u51fb \u51fa\u51fb7 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("permissionmgr", this.\u8d4b\u80fd, null);
                                    if (\u51fa\u51fb7 != null) {
                                        if (\u62bd\u8c61.\u5bf9\u6807) {
                                            \u5206\u5c42 \u5206\u5c422 = new \u5206\u5c42();
                                            \u51fa\u51fb7.\u8d4b\u80fd.\u8d4b\u80fd(-1036552793, \u5206\u5c422);
                                        }
                                        \u8fc1\u79fb \u8fc1\u79fb2 = \u8fc1\u79fb.\u8d4b\u80fd;
                                        \u51fa\u51fb7.\u8d4b\u80fd.\u8d4b\u80fd(686218487, \u8fc1\u79fb2);
                                    }
                                    if ((\u51fa\u51fb6 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("vpn_management", this.\u8d4b\u80fd, null)) != null) {
                                        try {
                                            \u7eb5\u5411 \u7eb5\u54112 = new \u7eb5\u5411(VpnConfig.class, (Function2)new \u5236\u9ad8\u70b9((Object)\u53ef\u7528\u6027.\u8d4b\u80fd), "top.bienvenido.mundo.manifest.MundoService$Companion$STUB");
                                            \u51fa\u51fb6.\u8d4b\u80fd.\u8d4b\u80fd(-1710356229, (Object)\u7eb5\u54112);
                                        }
                                        catch (Throwable throwable) {
                                            // empty catch block
                                        }
                                    }
                                    if (bl) {
                                        \u6d1e\u81ea\u8eab.\u8d4b\u80fd("legacy_permission", this.\u8d4b\u80fd, null);
                                        if (\u62bd\u8c61.\u54cd\u5e94) {
                                            \u6d1e\u81ea\u8eab.\u8d4b\u80fd("locale", this.\u8d4b\u80fd, null);
                                            \u51fa\u51fb \u51fa\u51fb8 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd("safety_center", this.\u8d4b\u80fd, null);
                                            if (\u51fa\u51fb8 != null) {
                                                \u79c1\u57df \u79c1\u57df3 = \u672c\u6211.\u6c89\u6dc0;
                                                \u51fa\u51fb8.\u8d4b\u80fd.\u8d4b\u80fd(-487933456, \u79c1\u57df3);
                                            }
                                            if (\u62bd\u8c61.\u540c\u6b65) {
                                                this.\u8d4b\u80fd("grammatical_inflection", "credential");
                                                if (\u62bd\u8c61.\u5bf9\u6807) {
                                                    \u6d1e\u81ea\u8eab.\u8d4b\u80fd("advanced_protection", this.\u8d4b\u80fd, null);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (\u62bd\u8c61.\u5347\u7ea7) {
            String string = \u62bd\u8c61.\u8ddf\u8fdb && bl ? "phone_honor" : "phone_huawei";
            \u51fa\u51fb \u51fa\u51fb9 = \u6d1e\u81ea\u8eab.\u8d4b\u80fd(string, this.\u8d4b\u80fd, null);
            if (\u51fa\u51fb9 != null) {
                \u79c1\u57df \u79c1\u57df4 = new \u79c1\u57df(\u9020\u5e02.\u6293\u624b);
                \u51fa\u51fb9.\u8d4b\u80fd.\u8d4b\u80fd(-258390536, \u79c1\u57df4);
            }
            if (bl) {
                \u6d1e\u81ea\u8eab.\u8d4b\u80fd("HwMagicWindowService", this.\u8d4b\u80fd, null);
            }
        }
    }
}

