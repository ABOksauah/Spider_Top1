/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.ComponentInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ServiceInfo
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u6269\u5c55;

public final class \u7c98\u6027
extends FunctionReferenceImpl
implements Function1 {
    public \u7c98\u6027() {
        super(1, (Object)\u6269\u5c55.\u8d4b\u80fd, \u6269\u5c55.class, "modifyPackageInfo", "modifyPackageInfo(Landroid/content/pm/PackageInfo;)V", 0);
    }

    public final Object invoke(Object object) {
        PackageInfo packageInfo = (PackageInfo)object;
        ((\u6269\u5c55)this.receiver).getClass();
        ApplicationInfo applicationInfo = packageInfo.applicationInfo;
        if (applicationInfo != null && \u6269\u5c55.\u8d4b\u80fd(applicationInfo)) {
            \u6269\u5c55.\u8d4b\u80fd((ComponentInfo[])packageInfo.activities, applicationInfo);
            \u6269\u5c55.\u8d4b\u80fd((ComponentInfo[])packageInfo.receivers, applicationInfo);
            \u6269\u5c55.\u8d4b\u80fd((ComponentInfo[])packageInfo.services, applicationInfo);
            \u6269\u5c55.\u8d4b\u80fd((ComponentInfo[])packageInfo.providers, applicationInfo);
        }
        return Unit.INSTANCE;
    }
}

