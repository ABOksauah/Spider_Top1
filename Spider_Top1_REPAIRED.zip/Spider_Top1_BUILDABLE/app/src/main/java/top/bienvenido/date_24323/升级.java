/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.IBinder
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.os.IBinder;
import android.os.IInterface;
import java.lang.reflect.Method;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5347\u7ea7$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u589e\u957f;
import top.bienvenido.date_24323.\u751f\u6001;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u5347\u7ea7
extends \u89e6\u8fbe {
    public static final Unit \u8d4b\u80fd(Object[] arrobject, \u589e\u957f \u589e\u957f2) {
        IInterface iInterface = (IInterface)arrobject[0];
        IBinder iBinder = iInterface != null ? iInterface.asBinder() : null;
        Account account = (Account)arrobject[1];
        Object object = arrobject[2];
        String string = null;
        if (object != null) {
            string = object.toString();
        }
        \u589e\u957f2.\u8d4b\u80fd(iBinder, account, string);
        return Unit.INSTANCE;
    }

    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        return \u751f\u6001.\u843d\u5730.\u8d4b\u80fd(new \u5347\u7ea7$$ExternalSyntheticLambda0(arrobject));
    }
}

