/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u5916\u5305;

public final class \u5916\u5305$$ExternalSyntheticLambda0
implements Runnable {
    public final void run() {
        \u5916\u5305.\u6293\u624b();
    }
}

