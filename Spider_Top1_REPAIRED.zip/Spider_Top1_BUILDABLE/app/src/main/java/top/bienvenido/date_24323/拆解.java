/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageInstaller
 *  android.content.pm.PackageInstaller$SessionParams
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.pm.PackageInstaller;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;

public final class \u62c6\u89e3
extends FunctionReferenceImpl
implements Function2 {
    public static final \u62c6\u89e3 \u8d4b\u80fd = new \u62c6\u89e3();

    public \u62c6\u89e3() {
        super(2, PackageInstaller.SessionParams.class, "setInstallerPackageName", "setInstallerPackageName(Ljava/lang/String;)V", 0);
    }

    public final Object invoke(Object object, Object object2) {
        ((PackageInstaller.SessionParams)object).setInstallerPackageName((String)object2);
        return Unit.INSTANCE;
    }
}

