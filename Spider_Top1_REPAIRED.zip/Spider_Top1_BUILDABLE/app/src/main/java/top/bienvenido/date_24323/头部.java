/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import top.bienvenido.date_24323.\u5dee\u5f02\u5316;

public class \u5934\u90e8 {
    public final \u5dee\u5f02\u5316 \u6293\u624b;
    public final String \u8d4b\u80fd;

    public \u5934\u90e8(String string2, \u5dee\u5f02\u5316 \u5dee\u5f02\u53162) {
        this.\u8d4b\u80fd = string2;
        this.\u6293\u624b = \u5dee\u5f02\u53162;
    }
}

