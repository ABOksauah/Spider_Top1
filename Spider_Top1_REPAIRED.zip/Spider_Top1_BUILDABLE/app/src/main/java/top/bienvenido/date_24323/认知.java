/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.Triple
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  top.bienvenido.date_24323.\u6587\u6848
 *  top.bienvenido.date_24323.\u8ba4\u77e5$
 *  top.bienvenido.date_24323.\u8ba4\u77e5$$ExternalSyntheticLambda0
 */
package top.bienvenido.date_24323;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5e03\u5c40;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u6587\u6848;
import top.bienvenido.date_24323.\u6d1e\u5bdf;
import top.bienvenido.date_24323.\u805a\u5408;
import top.bienvenido.date_24323.\u8ba4\u77e5$;

public abstract class \u8ba4\u77e5
extends Activity {
    public static final Unit \u8d4b\u80fd(Intent intent, String string2, \u5e03\u5c40 \u5e03\u5c402) {
        \u5e03\u5c402.\u8d4b\u80fd(intent, string2);
        return Unit.INSTANCE;
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(null);
        this.finishAndRemoveTask();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void onDestroy() {
        String string2;
        Intent intent;
        block8 : {
            super.onDestroy();
            intent = this.getIntent();
            if (\u62bd\u8c61.\u5e73\u53f0) {
                \u6d1e\u5bdf.\u8d4b\u80fd();
            }
            try {
                string2 = intent.getStringExtra("user");
            }
            catch (Exception exception) {
                return;
            }
            if (string2 != null) break block8;
            return;
        }
        Triple triple = \u805a\u5408.\u8d4b\u80fd(intent);
        if (triple == null) return;
        Intent intent2 = (Intent)triple.getFirst();
        if (intent2 == null) return;
        try {
            (Unit)\u6587\u6848.\u843d\u5730.\u8d4b\u80fd((Function1)new $ExternalSyntheticLambda0(intent2, string2));
            return;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

