/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import android.content.ComponentName;
import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u7b14\u82af;
import top.bienvenido.date_24323.\u9769\u547d;

public final class \u9769\u547d$$ExternalSyntheticLambda0
implements Function1 {
    public final /* synthetic */ ComponentName f$0;

    public /* synthetic */ \u9769\u547d$$ExternalSyntheticLambda0(ComponentName componentName) {
        this.f$0 = componentName;
    }

    public final Object invoke(Object object) {
        return \u9769\u547d.\u8d4b\u80fd(this.f$0, (\u7b14\u82af)object);
    }
}

