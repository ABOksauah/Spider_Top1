/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package top.bienvenido.date_24323;

public abstract class \u753b\u997c {
    public static int \u8d4b\u80fd(int[] arrn, int n, int n2) {
        int n3 = n - 1;
        int n4 = 0;
        while (n4 <= n3) {
            int n5 = n4 + n3 >>> 1;
            int n6 = arrn[n5];
            if (n6 < n2) {
                n4 = n5 + 1;
                continue;
            }
            if (n6 > n2) {
                n3 = n5 - 1;
                continue;
            }
            return n5;
        }
        return n4;
    }
}

