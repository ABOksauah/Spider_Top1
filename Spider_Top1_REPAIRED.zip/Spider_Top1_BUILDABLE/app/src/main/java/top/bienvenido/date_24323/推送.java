/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Class
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.jvm.functions.Function4
 *  kotlin.jvm.internal.FunctionReferenceImpl
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import java.util.List;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.FunctionReferenceImpl;
import top.bienvenido.date_24323.\u94f8\u9020;

public final class \u63a8\u9001
extends FunctionReferenceImpl
implements Function4 {
    public static final \u63a8\u9001 \u8d4b\u80fd = new \u63a8\u9001();

    public \u63a8\u9001() {
        super(4, \u94f8\u9020.class, "queryIntentServices", "queryIntentServices(Landroid/content/Intent;Ljava/lang/String;I)Ljava/util/List;", 0);
    }

    public final Object invoke(Object object, Object object2, Object object3, Object object4) {
        return ((\u94f8\u9020)object).\u6293\u624b((Intent)object2, (String)object3, ((Number)object4).intValue());
    }
}

