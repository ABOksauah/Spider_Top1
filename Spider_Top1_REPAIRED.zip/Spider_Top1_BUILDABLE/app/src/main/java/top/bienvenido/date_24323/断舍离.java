/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  com.android.internal.infra.AndroidFuture
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 */
package top.bienvenido.date_24323;

import android.content.Intent;
import com.android.internal.infra.AndroidFuture;
import java.lang.reflect.Method;
import top.bienvenido.date_24323.\u89e6\u8fbe;

public final class \u65ad\u820d\u79bb
extends \u89e6\u8fbe {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final Object \u8d4b\u80fd(Object object, Method method, Object[] arrobject) {
        AndroidFuture androidFuture = (AndroidFuture)\u89e6\u8fbe.\u8d4b\u80fd(arrobject, AndroidFuture.class);
        if (androidFuture == null) return null;
        try {
            androidFuture.complete((Object)new Intent("android.intent.action.MAIN"));
            return null;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

