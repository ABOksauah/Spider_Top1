/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  top.bienvenido.date_24323.\u4fbf\u6377\u6027
 *  top.bienvenido.date_24323.\u7a33\u5b9a\u6027
 *  top.bienvenido.date_24323.\u7eb5\u5411
 */
package top.bienvenido.date_24323;

import android.view.WindowManager;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import top.bienvenido.date_24323.\u4fbf\u6377\u6027;
import top.bienvenido.date_24323.\u51fa\u51fb;
import top.bienvenido.date_24323.\u5e73\u53f0\u5316;
import top.bienvenido.date_24323.\u6241\u5e73\u5316;
import top.bienvenido.date_24323.\u62bd\u8c61;
import top.bienvenido.date_24323.\u672c\u6211;
import top.bienvenido.date_24323.\u753b\u997c;
import top.bienvenido.date_24323.\u771f\u9999;
import top.bienvenido.date_24323.\u79c1\u57df;
import top.bienvenido.date_24323.\u7a33\u5b9a\u6027;
import top.bienvenido.date_24323.\u7eb5\u5411;
import top.bienvenido.date_24323.\u8026\u5408\u6027$$ExternalSyntheticLambda0;
import top.bienvenido.date_24323.\u89e6\u53d1;
import top.bienvenido.date_24323.\u89e6\u8fbe;
import top.bienvenido.date_24323.\u96c6\u6210;

public final class \u8026\u5408\u6027
extends \u96c6\u6210 {
    public static final \u8026\u5408\u6027 \u6293\u624b = new \u8026\u5408\u6027();

    public static final Unit \u8d4b\u80fd(\u5e73\u53f0\u5316 \u5e73\u53f0\u53162, WindowManager.LayoutParams layoutParams, String string) {
        layoutParams.packageName = string;
        int n = layoutParams.type;
        if (\u753b\u997c.\u8d4b\u80fd(\u5e73\u53f0\u53162.\u8d4b\u80fd, \u5e73\u53f0\u53162.\u6293\u624b, n) >= 0) {
            layoutParams.type = 2038;
        }
        return Unit.INSTANCE;
    }

    @Override
    public final void \u8d4b\u80fd() {
        Object object;
        \u89e6\u53d1 \u89e6\u53d12 = \u672c\u6211.\u4e2d\u53f0;
        this.\u8d4b\u80fd = \u89e6\u53d12;
        Class class_ = Class.forName((String)"android.view.WindowManagerGlobal");
        Object object2 = \u771f\u9999.\u6293\u624b(class_, "getWindowSession").\u8d4b\u80fd((Object)null, new Object[0]);
        if (object2 != null) {
            Object object3;
            \u51fa\u51fb \u51fa\u51fb2 = new \u51fa\u51fb(object2, \u89e6\u53d12);
            \u771f\u9999.\u8d4b\u80fd(class_, "sWindowSession", \u51fa\u51fb2.\u95ed\u73af);
            int[] arrn = new int[]{96417, -52475205, -920924064, -554281187, -1246845601, -129352154, 716732643};
            if (\u62bd\u8c61.\u843d\u5730) {
                \u5e73\u53f0\u5316 \u5e73\u53f0\u53162 = new \u5e73\u53f0\u5316(0);
                \u5e73\u53f0\u53162.\u6293\u624b = 5;
                \u5e73\u53f0\u53162.\u8d4b\u80fd = new int[]{2002, 2003, 2006, 2007, 2010};
                object3 = new \u8026\u5408\u6027$$ExternalSyntheticLambda0(\u5e73\u53f0\u53162);
            } else {
                object3 = new \u7a33\u5b9a\u6027((Object)\u4fbf\u6377\u6027.\u8d4b\u80fd);
            }
            \u51fa\u51fb2.\u8d4b\u80fd(arrn, (\u89e6\u8fbe)new \u7eb5\u5411(WindowManager.LayoutParams.class, (Function2)object3));
            object = \u51fa\u51fb2.\u95ed\u73af;
        } else {
            object = null;
        }
        Object object4 = \u771f\u9999.\u6293\u624b(class_, "getWindowManagerService").\u8d4b\u80fd((Object)null, new Object[0]);
        if (object4 == null) {
            return;
        }
        \u51fa\u51fb \u51fa\u51fb3 = this.\u8d4b\u80fd("window", object4);
        if (\u51fa\u51fb3 == null) {
            return;
        }
        \u771f\u9999.\u8d4b\u80fd(class_, "sWindowManagerService", \u51fa\u51fb3.\u95ed\u73af);
        String string = "com.android.internal.policy.";
        if (!\u62bd\u8c61.\u6293\u624b) {
            string = string + "impl.";
        }
        \u771f\u9999.\u8d4b\u80fd(string + "PhoneWindow$WindowManagerHolder", "sWindowManager").\u8d4b\u80fd((Object)null, \u51fa\u51fb3.\u95ed\u73af);
        if (object != null) {
            \u79c1\u57df \u79c1\u57df2 = new \u79c1\u57df(object);
            \u51fa\u51fb3.\u8d4b\u80fd.\u8d4b\u80fd(1788161260, \u79c1\u57df2);
        }
    }
}

