/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.IBinder
 *  android.os.Parcel
 *  java.lang.Object
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.net.Uri;
import android.os.IBinder;
import android.os.Parcel;
import top.bienvenido.date_24323.\u8ba2\u9605;

public final class \u4e0b\u8dea
implements \u8ba2\u9605 {
    public final IBinder \u8d4b\u80fd;

    public \u4e0b\u8dea(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    public final IBinder asBinder() {
        return this.\u8d4b\u80fd;
    }

    @Override
    public final void \u6293\u624b(Uri uri, IBinder iBinder, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoContentService");
            if (uri != null) {
                parcel.writeInt(1);
                uri.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            parcel.writeInt((int)bl);
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(1, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u843d\u5730(IBinder iBinder) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoContentService");
            parcel.writeStrongBinder(iBinder);
            this.\u8d4b\u80fd.transact(2, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }

    @Override
    public final void \u8d4b\u80fd(Uri uri, IBinder iBinder, boolean bl) {
        Parcel parcel = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
            parcel.writeInterfaceToken("MundoContentService");
            if (uri != null) {
                parcel.writeInt(1);
                uri.writeToParcel(parcel, 0);
            } else {
                parcel.writeInt(0);
            }
            parcel.writeStrongBinder(iBinder);
            parcel.writeInt((int)bl);
            this.\u8d4b\u80fd.transact(3, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel2.recycle();
            parcel.recycle();
        }
    }
}

