/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.jvm.functions.Function1
 */
package top.bienvenido.date_24323;

import kotlin.jvm.functions.Function1;
import top.bienvenido.date_24323.\u5012\u903c;
import top.bienvenido.date_24323.\u589e\u957f;

public final class \u5012\u903c$$ExternalSyntheticLambda0
implements Function1 {
    public final Object invoke(Object object) {
        return \u5012\u903c.\u8d4b\u80fd((\u589e\u957f)object);
    }
}

