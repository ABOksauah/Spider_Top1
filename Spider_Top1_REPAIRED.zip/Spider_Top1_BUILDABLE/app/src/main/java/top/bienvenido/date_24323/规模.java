/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  java.lang.Class
 *  java.lang.String
 */
package top.bienvenido.date_24323;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import top.bienvenido.date_24323.\u683c\u5c40;
import top.bienvenido.mundo.common.ext.MundoAccountResponse;

public final class \u89c4\u6a21
extends MundoAccountResponse {
    public final /* synthetic */ IBinder \u8d4b\u80fd;

    public \u89c4\u6a21(IBinder iBinder) {
        this.\u8d4b\u80fd = iBinder;
    }

    @Override
    public final void onError(int n, String string) {
    }

    @Override
    public final void onResult(Bundle bundle) {
        Parcelable[] arrparcelable = bundle.getParcelableArray("accounts");
        if (arrparcelable == null) {
            return;
        }
        int n = arrparcelable.length;
        Account[] arraccount = new Account[n];
        for (int i = 0; i < n; ++i) {
            arraccount[i] = arrparcelable[i];
        }
        \u683c\u5c40 \u683c\u5c402 = \u683c\u5c40.\u6293\u624b;
        IBinder iBinder = this.\u8d4b\u80fd;
        \u683c\u5c402.getClass();
        \u683c\u5c40.\u8d4b\u80fd(iBinder, arraccount);
    }
}

